---
name: Exception request
about: Request time-limited relief from a MUST requirement
labels: exception
---

Complete [docs/05-templates/exception-request.md](../../docs/05-templates/exception-request.md) and paste it here.

Do not include vulnerability details that would help an attacker. If the detail is sensitive, record only the reference to the risk register entry.
