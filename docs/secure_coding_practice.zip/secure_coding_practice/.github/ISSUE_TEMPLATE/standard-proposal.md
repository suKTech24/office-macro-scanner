---
name: Standard proposal
about: Propose a new requirement or a change to an existing one
labels: standard-proposal
---

**Standard affected** (for example SDS-03, or "new")

**Proposed requirement** (MUST / SHOULD wording)

**Problem it solves** (incident, audit finding, policy obligation, recurring defect)

**Which team archetypes and tiers does it affect?**

**How would a team verify compliance?**

**What paved road exists or is needed?** (tool, template, pipeline step)

**Cost to teams** (effort, tooling, licence)
