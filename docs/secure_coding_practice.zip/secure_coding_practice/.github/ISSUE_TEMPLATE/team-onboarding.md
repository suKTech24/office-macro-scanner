---
name: Team onboarding
about: Register a team for discovery and onboarding
labels: onboarding
---

**Team name and organisation** (for example eHealth NSW / an LHD / a pillar)

**Contact**

**What does the team build or maintain?**

**Main languages and tools**

**Where does the code live?** (GitHub, Azure DevOps, file share, vendor-hosted, none)

**Nominated security champion** (if any)

**Preferred time for a 60-minute discovery session**
