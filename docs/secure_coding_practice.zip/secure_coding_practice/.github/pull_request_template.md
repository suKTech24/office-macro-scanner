## What this changes

<!-- One or two sentences. -->

## Type of change

- [ ] Editorial (typo, link, clarity)
- [ ] Guide / template / example
- [ ] New or changed SHOULD
- [ ] New or changed MUST (link the proposal issue: #)
- [ ] Team onboarding (`teams/`)

## Checklist

- [ ] No secrets, real hostnames, or patient/staff data in examples
- [ ] Every new MUST has a reason, a verification method, and a paved road
- [ ] Tier applicability is stated
- [ ] `docs/00-program/policy-alignment.md` updated if a requirement was added or removed
