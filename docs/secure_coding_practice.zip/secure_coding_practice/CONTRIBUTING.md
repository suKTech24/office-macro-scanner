# Contributing

Anyone in NSW Health who writes or operates code can propose a change. Standards that nobody can challenge get ignored.

## Ways to contribute

| You want to | Do this |
|---|---|
| Fix a typo, broken link, clearer example | Open a pull request directly |
| Add or change a language guide or template | Open a pull request; a security champion for that technology reviews |
| Add or change a **MUST** requirement in a standard | Open a "Standard proposal" issue first, then a pull request once there is rough agreement |
| Say a requirement is unworkable for your team | Open an issue, or raise an [exception request](docs/05-templates/exception-request.md) if you need relief now |
| Onboard your team | Copy [teams/_template](teams/_template/) and open a pull request |

## Writing rules

- **Requirement language.** `MUST` / `MUST NOT` = mandatory, auditable. `SHOULD` = expected, deviation needs a recorded reason. `MAY` = optional. One requirement per bullet, each with an ID (for example `SDS-02-R3`).
- **Every MUST needs three things:** a reason, a way to verify it, and a paved road (a tool, template or example that makes it easy). If you cannot supply all three, write it as a SHOULD.
- **State the tier.** Say whether a requirement applies to Tier 1, 2, 3 or all.
- **No secrets, no real hostnames, no patient or staff data** in examples. Use `example.health.nsw.gov.au` and synthetic data.
- **Plain language.** Write for an engineer on an endpoint team at an LHD, not for an auditor.

## Review and approval

| Change type | Approver |
|---|---|
| Guides, templates, examples | One code owner |
| New or changed SHOULD | Code owner + one security champion from an affected archetype |
| New or changed MUST | Secure Development Working Group (two-week comment period) |
| Risk tiers, exception process, governance | Program owner + cyber governance |

Standards are versioned in their front matter. A changed MUST gets a transition period stated in the standard (default 90 days).
