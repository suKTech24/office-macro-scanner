# NSW Health Secure Development and AI Security Practices

> **Status: DRAFT v0.2 — starter repository for review.** Nothing here is endorsed NSW Health policy until it has been ratified through the governance path in [docs/00-program/operating-model.md](docs/00-program/operating-model.md). Items marked **[ASSUMPTION]** or **[VERIFY]** need confirming against internal eHealth NSW sources.

The single source of truth for how software, scripts, automation, infrastructure code and AI-enabled systems are built securely across NSW Health: eHealth NSW, the local health districts (LHDs), specialty networks, pillars and statewide services.

AI security is part of secure development here, not a separate rulebook. Developers use AI to write code, and increasingly build AI into what they ship, in the same editor and the same pipeline. Two standards carry it: [SDS-13](docs/02-standards/SDS-13-ai-assisted-development.md) (AI in how we build) and [SDS-17](docs/02-standards/SDS-17-ai-enabled-systems.md) (AI in what we build), with design-stage guidance based on [MITRE ATLAS](docs/03-guides/ai-security-with-atlas.md).

| You are | Start here |
|---|---|
| **Running the program** (security engineering, architecture, governance) | [Program plan](docs/00-program/program-plan.md) → [Discovery playbook](docs/01-discovery/README.md) |
| **A developer or DevSecOps engineer** who wants to know what to do | [Standards index](docs/02-standards/README.md) → your [team archetype](docs/04-team-archetypes/README.md) → your [language guide](docs/03-guides/README.md) |
| **Starting a repository, or using GitHub Copilot** | [Repository setup and GitHub Copilot](docs/03-guides/repository-setup.md) and the [template repository](template-repo/README.md) |
| **Designing or reviewing anything that uses AI** | [AI security with MITRE ATLAS](docs/03-guides/ai-security-with-atlas.md) |
| **Finding unapproved AI use** | [AI usage discovery](docs/01-discovery/ai-usage-discovery.md) |

## How this repository is organised

```text
.
├── README.md                    You are here
├── CONTRIBUTING.md              How to propose or change a standard
├── SECURITY.md                  How to report a vulnerability or a leaked secret
├── CODEOWNERS                   Who approves changes to what
├── .github/                     PR + issue templates for this repository, docs lint workflow
├── docs/
│   ├── 00-program/              WHY and HOW the program runs
│   │   ├── program-plan.md          Step-by-step plan, phases, deliverables
│   │   ├── operating-model.md       Federated model, RACI, risk tiers, exceptions
│   │   ├── nsw-health-context.md    Organisation map and what it means for rollout
│   │   ├── policy-alignment.md      Mapping to PD2026_001, NSW CSP, ISM, Essential Eight, SSDF, ATLAS
│   │   ├── industry-research.md     How Microsoft, Google, NHS, UK Home Office etc. do this
│   │   └── project-portfolio.md     Candidate DevSecOps projects, incl. secure MCP and RAG reference
│   ├── 01-discovery/            Phase 1 — understand the teams before writing rules
│   │   ├── README.md                Discovery playbook
│   │   ├── stakeholder-map.md       Who to talk to and what to ask each
│   │   ├── interview-guides/        Question sets per stakeholder type
│   │   ├── change-walkthrough.md    Worksheet: follow one real change to production
│   │   ├── ai-usage-discovery.md    Finding AI tools and agents, including shadow AI
│   │   ├── team-profile-template.md One per team discovered
│   │   ├── tech-stack-inventory.md  How to discover languages, tools, pipelines
│   │   ├── *-template.csv           Inventory, components, gap backlog, AI register
│   │   ├── maturity-assessment.md   Lightweight OWASP SAMM-based scoring
│   │   └── findings-report-template.md
│   ├── 02-standards/            WHAT is required (SDS-01 … SDS-17, MUST/SHOULD, tiered)
│   ├── 03-guides/               HOW: per language, AI security with ATLAS, repository setup
│   ├── 04-team-archetypes/      Which standards apply to which kind of team
│   ├── 05-templates/            Threat model (with AI section), exception, release checklist …
│   ├── 06-training/             Security champions program and learning paths
│   └── 07-metrics/              What we measure and report
├── template-repo/               Contents of the GitHub template repository new repositories start from
├── examples/                    Small runnable examples with tests; synthetic service walkthroughs
├── scripts/                     validate_repo.py and tests for the AI configuration check
├── pipelines/                   Reference CI/CD security pipelines (GitHub Actions, Azure DevOps)
├── teams/                       Completed team profiles (one folder per onboarded team)
└── decisions/                   Decision records for the program itself
```

## Design principles of this repository

1. **Discover before prescribing.** An endpoint team writing PowerShell and a clinical application team writing .NET need different guidance. Standards are written after the team archetypes are known.
2. **One baseline, tiered by risk.** Every standard states what applies at Tier 1 (clinical / crown jewel / health information), Tier 2 and Tier 3. See [operating model](docs/00-program/operating-model.md#risk-tiers).
3. **Paved roads over policy PDFs.** Each requirement should have a template, pipeline or library that makes compliance the easiest path.
4. **Traceable.** Every requirement maps to an obligation NSW Health already has (the Digital Health Cyber Security policy directive PD2026_001, NSW Cyber Security Policy, ISM, Essential Eight, NIST SSDF), and every AI requirement to the MITRE ATLAS technique it addresses, in [policy-alignment.md](docs/00-program/policy-alignment.md).
5. **Docs as code.** Changes go through pull request, are reviewed by code owners, and are versioned.

## Check the repository

```sh
python scripts/validate_repo.py
python -m unittest discover -s examples/python -p "test_*.py" -v
python -m unittest discover -s scripts -p "test_*.py" -v
python template-repo/scripts/check_ai_config.py --root .
```

## Quick links

- [Step-by-step program plan](docs/00-program/program-plan.md)
- [Minimum baseline every repository must meet](docs/02-standards/README.md#the-minimum-baseline)
- [Request an exception](docs/05-templates/exception-request.md)
- [Onboard your team](teams/README.md)
