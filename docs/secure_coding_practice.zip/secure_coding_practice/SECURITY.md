# Security

## Reporting a security incident or vulnerability in an NSW Health system

Do **not** open a public issue. Report to the Health Security Operations Centre (HSOC) using the channels in the Digital Health Cyber Security policy directive (PD2026_001, section 5):

- the **Search and Request Anything (SARA)** portal
- email **ehnsw-is-security-incidents@health.nsw.gov.au** (business hours)
- the **State Wide Service Desk on 1300 28 55 33** (24 hours)

Confirm these are current against the directive before publishing this repository.

## If you have committed a secret

Treat it as compromised from the moment it was pushed.

1. **Revoke or rotate** the credential first. Removing it from git history does not un-leak it.
2. Report it through the channels above.
3. Then clean the history, following [the secrets standard](docs/02-standards/SDS-02-secrets-management.md#if-a-secret-leaks).

## Reporting a problem with this repository

Open an issue. If the problem is that a published example is itself insecure, label it `security-defect`; it is triaged ahead of everything else.
