# 0001 — Repository structure and approach

| Status | Date | Deciders |
|---|---|---|
| Proposed | 2026-11-13 | Program owner (to be ratified by the working group) |

## Context

NSW Health needs secure development practices that work for very different teams (application engineering, integration, platform, endpoint and digital workspace, data, low-code, vendor-managed systems) across eHealth NSW, 15 local health districts, specialty networks, pillars and statewide services. Authority over those entities varies, team sizes vary widely, and existing obligations come from the NSW Cyber Security Policy, the ASD ISM and Essential Eight, and health privacy law.

## Options considered

1. **A single secure coding policy document.** Simple to publish. Tends to be written for web application teams, is hard to keep current, and gives teams nothing to adopt.
2. **Adopt an external framework as is** (for example NIST SSDF or Microsoft SDL). Credible, but not specific to NSW Health's obligations, archetypes or tooling, and not directly actionable by an engineer.
3. **A docs-as-code repository: tiered standards, archetype profiles, language guides, templates and reference pipelines, mapped to external frameworks.** More to build and maintain. Matches how the UK Home Office and NHS England publish engineering standards, and how Microsoft and Google scale security through defaults and paved roads.

## Decision

Option 3. Specifically:

- Discovery precedes standards; archetypes and language guides are confirmed by discovery.
- Short numbered standards (SDS-NN) with MUST/SHOULD requirements, each with tier applicability, a verification method and a paved road.
- One baseline for all entities; local profiles may tighten but not relax.
- NIST SSDF as the structural backbone; explicit mapping to the NSW Cyber Security Policy and ISM.
- Changes by pull request, with a working group approving mandatory requirements.

## Consequences

- Needs ongoing ownership: a program owner, a working group and platform team capacity for paved roads.
- Standards without a paved road will be visible as such, which creates pressure to fund the platform work.
- Draft content was produced from public sources and must be validated against internal NSW Health policy before ratification.
- Revisit after the pilot (Phase 4).
