# 0002 — Merge of a second draft, and delivery through GitHub Copilot

| Status | Date | Deciders |
|---|---|---|
| Proposed | 2026-11-13 | Program owner (to be ratified by the working group) |

## Context

Two drafts of this repository existed: this one, and a smaller second draft (about 500 lines) with a different structure. Separately, the program needed to decide how AI should deliver the standards to developers, given that NSW Health developers have GitHub Copilot in VS Code with a choice of models.

## Decision 1 — one repository, this structure

Keep this repository's structure and standards (SDS-01 to SDS-16). Take from the second draft the things this one lacked:

| Taken | Where it went |
|---|---|
| NSW Health policy directive PD2026_001 (Digital Health Cyber Security) as the primary obligation, with section references read from the directive | [policy-alignment.md](../docs/00-program/policy-alignment.md), exception process, `SECURITY.md`, SDS-13, SDS-14, training |
| Recording who provides each control: team, inherited, shared or not applicable | [operating-model.md](../docs/00-program/operating-model.md), team profile |
| Change walkthrough worksheet, with observed / reported / unknown confidence labels | [change-walkthrough.md](../docs/01-discovery/change-walkthrough.md) |
| Component-level stack inventory (declared against deployed version) and a gap backlog | `docs/01-discovery/` CSV templates |
| A legacy and manual delivery profile | [team archetypes](../docs/04-team-archetypes/README.md) |
| Clinical tests for integrations (duplicate, delayed, misrouted messages) | [integration archetype](../docs/04-team-archetypes/integration.md) |
| "Ask the supplier / verify locally" split | [SDS-14](../docs/02-standards/SDS-14-vendor-and-third-party-software.md) |
| Triage detail for dismissed findings; tool failures reported separately | [SDS-06](../docs/02-standards/SDS-06-security-testing.md) |
| Metrics for artefact traceability, recovery evidence and delivery friction | [metrics](../docs/07-metrics/README.md) |
| Runnable authorisation example with tests; repository validation script; synthetic walkthroughs | `examples/`, `scripts/` |
| Research on Google Binary Authorization for Borg, NHS DCB0129/DCB0160, GOV.UK developer docs | [industry-research.md](../docs/00-program/industry-research.md) |

Not taken: its ten-control baseline (SD-01 to SD-10) and crosswalk CSV, because SDS-01 to SDS-16 cover the same outcomes in more specific, testable requirements, and two control sets would confuse teams. Its pipeline samples only ran the repository's own checks.

## Decision 2 — deliver through Copilot customisation, not a separate agent

Publish instruction files and skills that teams copy into their repositories, instead of building a standalone agent. (Since moved into the [template repository](../template-repo/README.md); see [decision 0003](0003-repository-layers-and-ai-security-track.md).)

Reasons: developers already work in an agent (Copilot in their editor); the files are plain Markdown and independent of the model chosen; they cost little to maintain; and they sit beside the code where the work happens. A chat agent for people who do not work in an editor (low-code makers, managers, LHD leads) is deferred until discovery shows the demand.

## Consequences

- The Copilot files guide the assistant but enforce nothing. Pipeline checks and human review remain the control.
- Skills are self-contained copies of standards content, so a change to a standard must update the matching skill in the same pull request.
- Skill loading depends on the VS Code and Copilot version in use and must be tested in the NSW Health environment.
- PD2026_001 section references were read from the published directive on 13 November 2026 and should be re-checked when the directive is revised (review date 20 January 2030).
