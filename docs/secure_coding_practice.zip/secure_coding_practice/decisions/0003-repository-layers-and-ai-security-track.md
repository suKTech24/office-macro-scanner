# 0003 — Repository layers, and AI security inside secure development

| Status | Date | Deciders |
|---|---|---|
| Proposed | 2026-11-13 | Program owner (to be ratified by the working group) |

## Decision 1 — three layers for getting standards into repositories

**Context.** The organisation already has a `.github` repository with health files, templates and workflow templates. Copying the handbook into it would overload a repository meant for getting started, and GitHub does not share Copilot instructions, skills, `CODEOWNERS`, `dependabot.yml` or `.gitignore` from it anyway.

**Decision.**

- **This handbook** stays the source of truth and is linked, not copied.
- **The `.github` repository** holds only organisation defaults: `SECURITY.md`, pull request and issue templates, workflow templates and the profile. Two workflow templates were added there: IaC scan and PowerShell lint.
- **A template repository**, published from [template-repo/](../template-repo/README.md), holds what each repository needs its own copy of: owner and tier `README`, `CODEOWNERS`, `dependabot.yml`, `.gitignore`, the Copilot instructions and skills, and the AI configuration check.

SDS-01 R7 changed accordingly. Each repository states its owner and tier in its `README`. Its vulnerability reporting route can come from the organisation default `SECURITY.md` (new R7a), because a repository copy would stop inheriting the default.

## Decision 2 — AI security is part of secure development, in its own standards

**Context.** The program was planned as two projects: secure development, and AI security based on MITRE ATLAS. But developers meet AI risk in the same place they meet every other risk: in VS Code with Copilot and a choice of models, in their repositories, and in their pipelines. Discovery has also found shadow AI, including agents with no owner and tools from many providers on staff machines.

**Options.**

1. **Separate AI practice repository.** Clear ownership, but developers would have two places to look for overlapping rules (secrets, supply chain, threat modelling, review). AI rules would also miss the paved roads (template, pipeline, Copilot files) that make them stick.
2. **AI folded invisibly into existing standards.** One place, but AI risks would be diluted and hard to own.
3. **One handbook, with AI as a distinct track.** Two dedicated standards, one guide and one discovery method, all sharing the same baseline, templates and pipeline.

**Decision.** Option 3.

- [SDS-13](../docs/02-standards/SDS-13-ai-assisted-development.md) covers AI in **how we build**: approved tools, the AI register, local agents, agent configuration as code, and shadow AI response.
- [SDS-17](../docs/02-standards/SDS-17-ai-enabled-systems.md) covers AI in **what we build**: assessment at concept stage, an ATLAS-based threat model, AI bill of materials, prompt injection and agent controls, adversarial testing, and an off switch.
- The [ATLAS guide](../docs/03-guides/ai-security-with-atlas.md) is the shift-left method; every AI requirement cites the ATLAS technique or mitigation it addresses.
- [AI usage discovery](../docs/01-discovery/ai-usage-discovery.md) and the AI register handle shadow AI.

The AI security program still owns what is not developer practice: enterprise AI governance, the approved AI tools list, detection engineering with HSOC, and red teaming. Its developer-facing output is published here.

## Decision 3 — be honest about what scanning can do for AI risk

The pipeline gains one deterministic check, `check_ai_config.py`.

- It fails on hidden characters in agent instruction files and on plain-text credentials in MCP configuration.
- It inventories AI SDKs, endpoints, model files and MCP servers.

Prompt injection exposure, excessive agency and poisoned data are design properties that no scanner can see. They are handled by threat modelling at concept stage and by adversarial testing before release. MITRE ATLAS is used as a threat catalogue, not as a scanner.

## Consequences

- One place for developers; AI rules ride on the same template, Copilot files and pipeline.
- The AI security program must co-own SDS-13, SDS-17 and the ATLAS guide (`CODEOWNERS` updated).
- ATLAS releases monthly. The guide cites release 2026.10 and must be re-checked when the threat-model starter sets are reviewed, at least every six months.
- Sample pipelines now pin every action by commit SHA and every image by digest, after the March 2026 compromise of a scanner's GitHub Action tags (CVE-2026-33634).
