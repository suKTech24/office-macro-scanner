# Decision records

Significant decisions about the program itself: structure, tooling choices, tiering, governance. Use the [decision record template](../docs/05-templates/decision-record-template.md). Number sequentially. Never edit an accepted record; supersede it with a new one.

| # | Title | Status |
|---|---|---|
| [0001](0001-repository-structure-and-approach.md) | Repository structure and approach | Proposed |
| [0002](0002-merge-of-second-draft-and-copilot-kit.md) | Merge of a second draft, and delivery through GitHub Copilot | Proposed |
| [0003](0003-repository-layers-and-ai-security-track.md) | Repository layers, and AI security inside secure development | Proposed |

## Decisions expected next

- Approved source control platform(s) and organisation structure
- Supported security toolchain per check (secret scanning, SCA, SAST, IaC, SBOM)
- Risk tier definitions aligned to the NSW Health classification scheme
- Vulnerability remediation timeframes
- Whether this repository is internal only or partly public
