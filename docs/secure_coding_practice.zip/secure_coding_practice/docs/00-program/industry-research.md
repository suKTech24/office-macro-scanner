# Industry research — how large organisations do this

Research conducted November 2026 from public sources. Where a claim comes from a vendor or secondary source it is marked. The purpose is to borrow what works, not to copy.

## Summary: seven patterns that recur

| # | Pattern | Seen at | What we take |
|---|---|---|---|
| 1 | **A small set of named practices** covering the whole lifecycle, not a long policy | Microsoft SDL (10 practices), NIST SSDF (4 groups) | 16 short standards, grouped by lifecycle |
| 2 | **Make the secure way the default way** — put safety in languages, libraries, frameworks and platforms instead of relying on each developer | Google "safe coding"; Netflix "paved road"; Spotify "golden paths" | Repo templates, reference pipelines, org-level controls. Every MUST needs a paved road |
| 3 | **Principles → standards → patterns**, published openly as docs-as-code with MUST language and IDs | UK Home Office Engineering Guidance and Standards; NHS England Software Engineering Quality Framework | Repository layout, requirement IDs, pull-request governance |
| 4 | **Risk-tiered requirements** | SLSA levels, Essential Eight maturity levels, ASVS levels | Tier 1–3 applicability on every requirement |
| 5 | **Federated ownership with security champions** | OWASP SAMM guidance; widely adopted | Champion per team, community of practice, with protected time |
| 6 | **Measure maturity, then improve iteratively** | OWASP SAMM, OWASP DSOMM, NHS quality review tool | Lightweight SAMM-based self-assessment, repeated yearly |
| 7 | **Supply chain integrity as a first-class concern** | SLSA, SBOM guidance from ASD and CISA, OpenSSF | SDS-03 and SDS-07 |

## Microsoft — Security Development Lifecycle (SDL)

The current SDL is ten practices: establish security standards, metrics and governance; require proven security features, languages and frameworks; perform security design review and threat modelling; define and use cryptography standards; secure the software supply chain; secure the engineering environment; perform security testing; ensure operational platform security; implement security monitoring and response; provide security training.

**Lessons:** governance and metrics are practice number one, not an afterthought. Threat modelling is a design activity owned by engineers. The engineering environment (developer machines, pipelines, identities) is in scope, which matters for an organisation where pipelines can push to tens of thousands of endpoints.

## Google — safe coding, secure by design, SLSA

Google's published position is that vulnerability classes are eliminated by building invariants into the developer ecosystem (languages, libraries, frameworks) so that responsibility shifts from individual developers to the platform. Google reports near-zero residual rates of some common defect classes across hundreds of applications; this is self-reported. For legacy code, the approach pairs safe defaults for new work with gradual modernisation of old code. SLSA (Supply-chain Levels for Software Artifacts), which Google initiated, provides incrementally adoptable levels for build integrity and provenance.

Google also publishes how it gates deployment: Binary Authorization for Borg checks verifiable build provenance against a service-specific policy before code may run in production.

**Lessons:** prefer "you cannot write the bug" over "please do not write the bug": parameterised data access, auto-escaping templates, vetted auth libraries. Accept that legacy code needs a separate, slower track. Promote one immutable artefact through environments and tie build evidence to it; a manually signed package can carry the same integrity and promotion evidence while automation matures.

## Netflix and Spotify — paved roads and golden paths

The paved road idea: a supported, opinionated, self-service route for common tasks, with security built in, adopted because it is easier than the alternative, not because it is mandated. Adoption figures quoted in vendor blogs could not be verified against primary sources. Known failure modes: quietly bypassed defaults, and stale paved roads that push teams back to ad hoc workarounds.

**Lessons:** fund the platform team to maintain the paved road, and measure adoption as the leading indicator.

## UK Home Office — Engineering Guidance and Standards

A public site, managed on GitHub, organised as principles, standards and patterns. Standards carry IDs (SEGAS-00006 Managing secrets, SEGAS-00007 Managing the security of software dependencies, SEGAS-00009 Signing code commits, SEGAS-00010 Encrypting data at rest and in transit, SEGAS-00020 Use AI, and others). Each standard is a list of single-statement MUST requirements. Changes are raised by pull request and approved by engineering leadership. There is a standard for writing a standard.

**Lessons:** the closest structural model for this repository. Short standards, one statement per requirement, machine-readable IDs.

## NHS England — Software Engineering Quality Framework

A public GitHub repository of principles, practices, patterns, blueprints and an engineering quality review tool that teams use to assess their own maturity and technical debt. Its repository-security practice sets minimum requirements for all repositories, recommends team-based access with a separate admins team, a repository template, and requires an SBOM for repository content and build artefacts. Parts of the content date from around 2022; check the current main branch before citing specifics.

**Lessons:** the closest sector model: a federated public health system publishing engineering guidance that many organisations adopt voluntarily. The self-review tool is what drives adoption.

## NHS England — clinical risk management standards

NHS England separates clinical safety responsibility in two: DCB0129 applies to manufacturers of health IT, and DCB0160 applies to the health organisations that deploy and use it.

**Lessons:** supplier assurance of a product does not cover how it is configured, integrated and used locally. The deploying team assesses integration, workflow hazards, downtime and recovery. Applied in [SDS-14](../02-standards/SDS-14-vendor-and-third-party-software.md). These are English requirements used as a comparator; the applicable NSW Health clinical safety pathway must be confirmed internally.

## GOV.UK — open developer documentation

The Government Digital Service publishes its developer handbook openly, including the rules for obtaining production access.

**Lessons:** publish short operational rules (who gets production access, how, and how it is removed) beside the pipeline templates, not only coding guidance.

## MITRE ATLAS — AI threat knowledge base

ATLAS (Adversarial Threat Landscape for AI Systems) catalogues how attackers target AI systems, in the style of MITRE ATT&CK. Release 2026.10 has 16 tactics, over 200 techniques and sub-techniques, and 44 mitigations. It now releases monthly, and much of its 2026 growth covers agents: tool poisoning, agent configuration tampering, credentials taken from agent configuration, and local agents as a route to full machine compromise.

**Lessons:** use ATLAS as the shared language for AI threat modelling, red teaming and detection. It is a catalogue, not a scanner. Applied in [SDS-13](../02-standards/SDS-13-ai-assisted-development.md), [SDS-17](../02-standards/SDS-17-ai-enabled-systems.md) and the [ATLAS guide](../03-guides/ai-security-with-atlas.md).

## Recent incidents that shaped the AI and supply-chain standards

- **Scanner GitHub Action compromised (March 2026).** Attackers force-pushed nearly all version tags of `aquasecurity/trivy-action` to a credential stealer (CVE-2026-33634); pipelines pinned to tags ran it. Lesson: pin by commit SHA and digest, and treat security tools as dependencies too ([SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md), [SDS-07](../02-standards/SDS-07-build-and-deployment-pipelines.md)).
- **Malicious agent skills on a public registry (February 2026).** Researchers found hundreds of malicious skills on ClawHub, the skill marketplace for the OpenClaw local agent, most from one coordinated campaign distributing an infostealer. Skills ran with the agent's full authority. Lesson: skills, prompts and MCP servers are code from strangers, and autonomous local agents need isolation ([SDS-13](../02-standards/SDS-13-ai-assisted-development.md) R13, R17).

## Frameworks and regulators

| Source | Use it for |
|---|---|
| **NIST SSDF SP 800-218** (v1.1 final; v1.2 draft adds continuous improvement and robust updates) | Backbone structure; common language with vendors |
| **ASD ISM — Guidelines for software development** | Australian control baseline; secure by design, developer skills, AI-assisted development |
| **ASD/ACSC SBOM guidance** (minimum elements updated 2026) | What an SBOM must contain |
| **CISA Secure by Design** | Language for vendor conversations |
| **OWASP SAMM** | Program maturity model; basis of the self-assessment |
| **OWASP DSOMM** | Pipeline-level maturity detail for platform teams |
| **OWASP ASVS** | Verification requirements for applications, by level |
| **OWASP Cheat Sheet Series** | Language-agnostic implementation guidance to link from guides |
| **SLSA** | Build integrity levels |
| **OpenSSF Scorecard / OSPS Baseline** | Automated repo hygiene checks |

## What tends to fail

From a published case study of security champions in a large e-commerce enterprise (Gutfleisch and Sasse, UCL) and practitioner reports:

- Champions appointed without time, training or a route to escalate.
- Teams following no common strategy because the central team published documents and stopped.
- Tooling switched on everywhere at once, producing noise that teams learn to ignore.
- Standards written for web application teams and imposed on everyone else.
- Central security as a gate at the end instead of a service at the start.

## Sources

- [MITRE ATLAS](https://atlas.mitre.org/) and [ATLAS data releases](https://github.com/mitre-atlas/atlas-data)
- [Aqua Security — Trivy supply chain attack](https://www.aquasec.com/blog/trivy-supply-chain-attack/) and [Snyk analysis](https://snyk.io/articles/trivy-github-actions-supply-chain-compromise/)
- [eSecurity Planet — malicious skills found in OpenClaw's ClawHub](https://esecurityplanet.com/threats/hundreds-of-malicious-skills-found-in-openclaws-clawhub) and [The Hacker News — OpenClaw integrates VirusTotal scanning](https://thehackernews.com/2026/02/openclaw-integrates-virustotal-scanning.html)
- [NSW Health Digital Health Cyber Security policy directive PD2026_001](https://www1.health.nsw.gov.au/pds/ActivePDSDocuments/PD2026_001.pdf)
- [NSW Health Enterprise-wide Risk Management PD2022_023](https://www1.health.nsw.gov.au/pds/ActivePDSDocuments/PD2022_023.pdf)
- [NSW Cyber Security Policy — detailed requirements](https://www.nsw.gov.au/nsw-government/digital-nsw/resource-library/cyber-security-policy-resource/detailed-requirements)
- [eHealth NSW Supplier Hub](https://www.ehealth.nsw.gov.au/supplier-hub)
- [Google — Binary Authorization for Borg](https://docs.cloud.google.com/docs/security/binary-authorization-for-borg)
- [NHS England — clinical risk management standards](https://digital.nhs.uk/services/clinical-safety/clinical-risk-management-standards)
- [GOV.UK developer docs — rules for getting production access](https://github.com/alphagov/govuk-developer-docs/blob/main/source/manual/rules-for-getting-production-access.html.md)
- [NSW Cyber Security Policy — mandatory requirements](https://www.digital.nsw.gov.au/delivery/cyber-security/policies/mandatory-requirements)
- [NSW Cyber Security Policy 2026–2027 (PDF)](https://www.digital.nsw.gov.au/sites/default/files/2026-06/nsw-cyber-security-policy-2026-2027.pdf)
- [ASD ISM — Guidelines for software development](https://www.cyber.gov.au/ism/guidelines-for-software-development)
- [iTnews — ASD on developers lacking security skills](https://www.itnews.com.au/news/asd-draws-a-hard-line-on-developers-lacking-security-skills-626728)
- [ASD SBOM guidance update](https://www.techpartner.news/news/asd-updates-guidance-around-software-bill-of-materials-627844)
- [NIST SSDF project](https://csrc.nist.gov/projects/ssdf/publications) and [SSDF v1.2 draft](https://csrc.nist.gov/pubs/sp/800/218/r1/ipd)
- [Microsoft SDL practices](https://www.microsoft.com/en-us/securityengineering/sdl/practices)
- [Google — Developer Ecosystems for Software Safety](https://research.google/pubs/developer-ecosystems-for-software-safety/)
- [Google — A recipe for scaling security](https://bughunters.google.com/blog/5896512897417216/a-recipe-for-scaling-security)
- [Google — Secure by Design](https://blog.google/technology/safety-security/tackling-cybersecurity-vulnerabilities-through-secure-by-design/)
- [UK Home Office Engineering Guidance and Standards](https://engineering.homeoffice.gov.uk/standards-requirements)
- [NHS England Software Engineering Quality Framework](https://github.com/NHSDigital/software-engineering-quality-framework)
- [OWASP SAMM](https://owaspsamm.org/) and [Fortune 500 SAMM lessons learned](https://owaspsamm.org/user-day/2023/introducing-owasp-samm-at-a-fortune-500-company-lessons-learned/)
- [Security Champions Without Support — case study (UCL)](https://discovery.ucl.ac.uk/10181281/1/Sasse_Security%20Champions%20Without%20Support-%20Results%20from%20a%20Case%20Study%20with%20OWASP%20SAMM%20in%20a%20Large-Scale%20E-Commerce%20Enterprise_VoR.pdf)
- [NSW Health structure](https://www.health.nsw.gov.au/about/nswhealth/Pages/structure.aspx) and [local health districts and specialty networks](https://www.health.nsw.gov.au/lhd)
