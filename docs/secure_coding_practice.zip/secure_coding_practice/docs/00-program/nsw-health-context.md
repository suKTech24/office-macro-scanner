# NSW Health context

Source for the organisation list: NSW Health structure and LHD pages (see [industry-research.md](industry-research.md#sources)), checked November 2026. **[VERIFY]** against the current organisation chart before publishing.

## Organisation map

| Group | Entities | Likely development profile **[ASSUMPTION — confirm in discovery]** |
|---|---|---|
| **Ministry** | NSW Ministry of Health | Analytics, reporting, policy systems |
| **Statewide and specialist services** | eHealth NSW; NSW Health Pathology; NSW Ambulance; Health Infrastructure; Health Protection NSW; Single Digital Patient Record Implementation Authority | eHealth NSW: the largest and most varied engineering footprint. Pathology and Ambulance: specialised operational systems |
| **Shared services** | HealthShare NSW | Corporate, payroll, procurement and logistics systems |
| **Pillars** | Agency for Clinical Innovation; Bureau of Health Information; Cancer Institute NSW; Clinical Excellence Commission; Health Education and Training Institute | Data, registries, analytics, public-facing web, learning platforms |
| **Metropolitan LHDs (6)** | Nepean Blue Mountains; Northern Sydney; South Eastern Sydney; South Western Sydney; Sydney; Western Sydney | Local ICT teams: integration, reporting, local apps, scripts, low-code; some research-adjacent development |
| **Rural and regional LHDs (9)** | Central Coast; Far West; Hunter New England; Illawarra Shoalhaven; Mid North Coast; Murrumbidgee; Northern NSW; Southern NSW; Western NSW | Smaller teams, often generalists; heavier reliance on statewide services and vendors |
| **Specialty networks (2)** | Sydney Children's Hospitals Network (The Children's Hospital at Westmead and Sydney Children's Hospital, Randwick); Justice Health and Forensic Mental Health Network | Specialised clinical systems; paediatric and custodial data sensitivities |
| **Affiliated health organisations** | St Vincent's Health Network and others | Separate legal entities; influence is through agreements, not mandate |

## What this means for the program

1. **Authority differs by entity.** eHealth NSW can mandate for its own teams. For LHDs, networks and pillars, the lever is the NSW Cyber Security Policy obligations each entity already carries, plus shared platforms and service agreements. Position the standards as "the way to meet obligations you already have".
2. **Team size varies by two orders of magnitude.** A requirement that assumes a dedicated DevSecOps engineer fails in a three-person LHD team. Every MUST needs a path a small team can follow, usually an org-level control or a shared pipeline.
3. **Much risky code is not called software.** Endpoint and digital workspace teams, integration analysts and report writers produce privileged scripts and data flows without thinking of themselves as developers. Discovery has to reach them, and the guidance has to use their words.
4. **Shared platforms are the scaling mechanism.** If source control, pipelines, identity and cloud landing zones are shared statewide, controls placed there reach every entity without negotiation.
5. **Vendors write a large share of the code.** Clinical systems are largely vendor products. The contract clause and assurance path ([SDS-14](../02-standards/SDS-14-vendor-and-third-party-software.md)) matters as much as internal coding guidance.
6. **Health data raises the floor.** Health information is covered by the Health Records and Information Privacy Act 2002 (NSW), personal information by the Privacy and Personal Information Protection Act 1998 (NSW) including the NSW Mandatory Notification of Data Breach scheme. Software that meets the definition of a medical device is regulated by the TGA. See [SDS-12](../02-standards/SDS-12-health-data-and-privacy.md).
7. **Specialty contexts need a local profile.** Paediatric data (SCHN), custodial health (Justice Health), cancer registries (Cancer Institute NSW) and pathology each add sensitivities. Capture them as a short local profile in `teams/<entity>/` instead of forking the standards.

## Engagement order

Start where sponsorship and concentration of Tier 1 systems are highest (eHealth NSW), prove the model, then invite two or three LHDs or networks with different profiles (one metropolitan, one rural, one specialty network) to pilot the local-profile approach before a general rollout.
