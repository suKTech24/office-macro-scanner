# Operating model

## Scope

"Code" means anything executable that NSW Health staff or contractors write, configure or commission:

- application and API source code
- scripts and automation (PowerShell, Bash, Python, scheduled tasks, runbooks)
- infrastructure as code, pipeline definitions, container images
- integration mappings and interface code
- low-code apps and flows
- analytics notebooks, models and queries
- software developed for NSW Health by vendors

Commercial off-the-shelf products are out of scope except for the custom code and configuration NSW Health adds to them.

## Federated model

NSW Health is too varied for a central team to review everything, and too connected for each entity to set its own rules. The model is **centrally defined baseline, locally owned implementation**.

| Layer | Who | Owns |
|---|---|---|
| **Set** | Secure Development Program (eHealth NSW security engineering) | Standards, risk tiers, paved roads, metrics, exception register |
| **Agree** | Secure Development Working Group (cross-entity) | Approves MUST requirements, prioritises paved roads |
| **Enable** | Platform / DevOps teams | Reference pipelines, repo templates, shared tooling |
| **Apply** | Each engineering team, with a security champion | Meeting the standards for their systems; raising exceptions |
| **Assure** | Cyber governance, risk and audit | Policy mapping, exception approval above threshold, independent verification |
| **Local adaptation** | LHD / network / pillar digital leads | Local profile: which archetypes exist locally, local tooling, local approver for exceptions |

An entity may add stricter local requirements. It may not weaken a MUST without an exception.

## RACI

| Activity | Program | Working group | Platform | Team | Champion | Governance | Sponsor |
|---|---|---|---|---|---|---|---|
| Define standards | R | A | C | C | C | C | I |
| Assign system risk tier | C | I | I | R | C | A | I |
| Provide paved roads | A | C | R | C | C | I | I |
| Meet requirements | C | I | C | A/R | R | I | I |
| Approve exceptions (Tier 2–3) | A | I | C | R | C | C | I |
| Approve exceptions (Tier 1) | C | I | C | R | C | A | I |
| Report metrics | R | C | C | C | C | C | A |

## Risk tiers

Requirements scale with what could go wrong. Tier is assigned per system, not per team.

| Tier | Typical systems | Assign if any of these is true |
|---|---|---|
| **Tier 1 — Critical** | Clinical systems, statewide platforms, identity, systems holding health information at scale | Classified as a Crown Jewel under the NSW Cyber Security Policy; failure could affect patient safety; holds identifiable health information; internet-facing with authentication; code runs with privilege across many endpoints or servers |
| **Tier 2 — Important** | Corporate and operational systems, internal tools with personal or sensitive data | Holds personal information or official-sensitive data; supports a business-critical process; integrates with a Tier 1 system |
| **Tier 3 — Standard** | Low-impact tools, prototypes with synthetic data, single-team utilities | None of the above |

Two rules that surprise people:

- **Privilege drives tier.** An endpoint-management script deployed to tens of thousands of devices is Tier 1 even if it is 30 lines long.
- **A prototype with real patient data is not a prototype.** It takes the tier of its data.

**Tiers are not a risk rating.** They decide how much assurance a system gets. Formal risk ratings use the NSW Health Risk Matrix (PD2022_023), and PD2026_001 §3.2 requires any cyber risk assessment method to be approved by the NSW Health CISO before use, so the tier scheme needs that approval. Use the NSW Health Crown Jewel Assessment Framework (requested through SARA) as the input for Tier 1, so teams do not classify twice.

## Who provides each control

In a federated organisation many controls are provided by a shared platform, not by the team. For every standard, each team records one of:

| Value | Meaning | Evidence the team keeps |
|---|---|---|
| **Team** | The team implements and operates it | Its own configuration and results |
| **Inherited** | A shared platform provides it fully (for example org-wide push protection) | Provider, version, proof it is enforced on this repository, tenant or pipeline |
| **Shared** | The platform provides part; the team must do the rest (for example a central runner with short-lived identity, where the team still scopes deployment permissions) | Both of the above, and the split of duties |
| **Not applicable** | With a reason and approver | The reason |

An inherited control only counts if it is enforced on the specific repository, tenant, runner and deployment route in question. When a shared control changes, the provider notifies consuming teams with migration and support dates. The record lives in the [team profile](../01-discovery/team-profile-template.md).

## Exceptions

A requirement that cannot be met is recorded, time-limited and owned. It is not ignored.

NSW Health already has a mandatory mechanism: PD2026_001 §3.2.6 requires an **eHealth Information Security Exemption** requested through the SARA portal, recorded in a risk register with compensating controls, valid for no more than one year. The steps below prepare and track that request; they do not replace it.

1. Team completes the [exception request](../05-templates/exception-request.md).
2. Champion reviews compensating controls.
3. Where the gap means a policy or security standard is not met, the team lodges the SARA exemption and records its reference. Engineering-only deviations (a SHOULD, or a Tier 3 paved-road preference) are approved by the team lead and recorded here.
4. Maximum duration 6 months (Tier 1) or 12 months (Tier 2–3). Nothing exceeds the directive's one-year limit. Renew or close before expiry.
5. Recorded in the exception register and counted in metrics.

An engineering exception cannot waive a legal or policy obligation. Emergency changes use the existing emergency change path, with a linked record, a post-change review and time-bound follow-up.

Many exceptions against one requirement means the requirement or its paved road is wrong. Review it.

## Governance cadence

| Forum | Frequency | Purpose |
|---|---|---|
| Working group | Fortnightly during Phases 1–4, then monthly | Standards decisions, paved road priorities |
| Champions community | Monthly | Share practice, surface friction |
| Executive cyber governance committee | Quarterly | Metrics, exceptions over threshold, funding |
| Standards review | Annual | Re-validate each standard |
