# Policy alignment

Why each standard exists, traced to obligations NSW Health already has. Use this page when someone asks "who says we have to?".

> **[VERIFY]** This mapping was drafted from public sources in November 2026. Cyber governance must check it against the current NSW Cyber Security Policy detailed requirements, the current ISM release and internal NSW Health policy directives before it is relied on for audit.

## The obligation stack

| Layer | Source | Relevance |
|---|---|---|
| NSW Health | **Digital Health Cyber Security, PD2026_001** (published 20 January 2026, replaces PD2020_046). Applies to the Ministry, LHDs, statutory health corporations, specialty networks, affiliated health organisations, NSW Health Pathology, Cancer Institute and NSW Ambulance | The directive every NSW Health organisation already answers to, and therefore the main lever for entities eHealth NSW cannot mandate. See the mapping below |
| NSW Government | **NSW Cyber Security Policy 2026–2027** — mandatory requirements for NSW Government agencies; annual attestation to Cyber Security NSW | The primary obligation. No requirement is titled "secure development"; it is reached through 1.5, 1.10, 1.11, 1.12, 3.3 and 3.11 below |
| Commonwealth guidance | **ASD Information Security Manual (ISM)**, *Guidelines for software development* | The detailed control set. Includes ISM-0401 (secure-by-design principles followed throughout the software development life cycle) and ISM-2121 (developers without sufficient cyber security knowledge and skills for their tasks are not used). 2026 updates extend "developer" to include AI agents |
| Commonwealth guidance | **ASD Essential Eight** | Embedded in NSW CSP requirements 3.3–3.10. Patch applications, application control and restrict admin privileges directly affect how code is built and deployed |
| Legislation | HRIP Act 2002 (NSW), PPIP Act 1998 (NSW) incl. MNDB scheme, State Records Act 1998 (NSW), SOCI Act 2018 (Cth) for hospitals as critical infrastructure, Therapeutic Goods Act for software as a medical device | Data handling, breach notification, safety |
| International frameworks | **NIST SSDF (SP 800-218)** v1.1 final; v1.2 in draft (adds PO.6 continuous improvement and PW.10 robust updates) | The structure the standards follow: Prepare, Protect, Produce, Respond |
| Community frameworks | OWASP SAMM, OWASP ASVS, OWASP Top 10, SLSA, OpenSSF Scorecard, CISA Secure by Design | Maturity measurement, verification requirements, supply chain integrity |
| AI security | **MITRE ATLAS** (release 2026.10), OWASP Top 10 for LLM Applications, NIST AI RMF | Threat catalogue for AI systems and AI tools; every SDS-13 and SDS-17 requirement cites the ATLAS technique or mitigation it addresses |

## NSW Health PD2026_001 mapping

Section references were read from the published directive.

| PD2026_001 | What it says | What it means for this program |
|---|---|---|
| §2.3 | The CIO must ensure a Secure-by-Design approach is in place and resourced for new statewide initiatives and upgrades, and that staff and third-party providers understand their role in building secure systems | The mandate for this program. Quote it in the sponsor's one-page charter |
| §2.6 | IT support staff and system developers are responsible for delivering reliable software and must understand the business use and risks of the technologies used | Basis for role-based developer training and for the standards applying to "anyone who writes code" |
| §2.9 | Maintain an inventory of third-party providers; contractually oblige them to notify incidents and breaches; monitor their adherence | [SDS-14](../02-standards/SDS-14-vendor-and-third-party-software.md) |
| §3.1 | Each organisation has an executive-level governance committee and implements controls locally for assets under its control | The federated model: central baseline, local implementation |
| §3.1.1 | eHealth NSW provides statewide security services and platforms (see also PD2021_043, Foundation ICT Services and Platforms) | Shared platforms are where paved-road controls live; record what each team inherits |
| §3.2 | Cyber risk assessment methods must be approved by the NSW Health CISO before use | Risk tiers in this repository select control depth. They are not a risk rating method and need CISO approval before use |
| §3.2.1–3.2.2 | Use Enterprise-wide Risk Management (PD2022_023) and the NSW Health Risk Matrix; clinical safety is a priority when assessing cyber risk | Threat models and exceptions reference the Risk Matrix for ratings |
| §3.2.6 | Exemptions are requested with the eHealth Information Security Exemption form on the SARA portal, recorded in a risk register with compensating controls, and are valid for no more than one year | The [exception process](operating-model.md#exceptions) feeds this form; it does not replace it |
| §3.3.1 | Use the NSW Health Crown Jewel Assessment Framework for local assets | Input to Tier 1 assignment |
| §3.3.2 | SOCI Act obligations apply in addition | Tier 1 criteria |
| §3.4 | Annual mandatory cyber training on My Health Learning; continuing education | [Training](../06-training/README.md) delivery channel |
| §3.5–3.6 | Collect and evaluate security metrics; continual improvement | [Metrics](../07-metrics/README.md), annual standards review |
| §4 | Classification, retention, disposal | [SDS-12](../02-standards/SDS-12-health-data-and-privacy.md) |
| §4.4 | Health, personal or operational data must not be contributed to publicly available generative AI; AI solutions follow the Digital NSW AI Assessment Framework; see also IB2024_059 | [SDS-13](../02-standards/SDS-13-ai-assisted-development.md) (AI tools and agents), [SDS-17](../02-standards/SDS-17-ai-enabled-systems.md) (AI-enabled systems, assessment at concept stage) |
| §5 | Report incidents to the Health Security Operations Centre (HSOC) through SARA, email or the State Wide Service Desk | [SECURITY.md](../../SECURITY.md), SDS-02, SDS-11 |

## NSW Cyber Security Policy mapping

Requirement text is from the Digital NSW mandatory requirements page. The detailed requirements sit beneath these; the ones most relevant to development are 1.6.1–1.6.3 (asset and software inventories and lifecycle, including end-of-support), 1.10.1–1.10.4 (third-party inventory, notification, monitoring, contract clauses), 1.11.1 (vulnerability identification and triage) and 1.12.1–1.12.3 (security assessed in change management; controls tested after significant change). None of them mentions secure development by name.

| NSW CSP requirement | How this program contributes | Standards |
|---|---|---|
| 1.1 Allocate roles and responsibilities | RACI, security champions | [Operating model](operating-model.md) |
| 1.5 Formalised plans, policies and processes | This repository is the formalised secure development process | All |
| 1.6 Asset inventory and dependencies | Repo inventory, SBOMs, system-to-repo mapping | SDS-01, SDS-03 |
| 1.7 Crown Jewels and system classification | Risk tiers drive control strength | [Risk tiers](operating-model.md#risk-tiers) |
| 1.8 Data identification, retention, disposal | No production data in non-production; data minimisation | SDS-12 |
| 1.10 Third-party service provider risk | Vendor-developed software clauses, dependency risk | SDS-03, SDS-14 |
| 1.11 Vulnerability management | Finding triage, remediation timeframes, disclosure | SDS-11 |
| 1.12 Security in change management | Pull request review, pipeline gates, release checklist | SDS-01, SDS-06, SDS-07 |
| 2.1 Event logging and monitoring | Application security logging requirements | SDS-10 |
| 2.2 Incident response | Leaked secret and vulnerable release procedures | SDS-02, SDS-11 |
| 3.1 Awareness and training | Role-based developer training, champions | [Training](../06-training/README.md) |
| 3.2 Access controls | Repo and pipeline access, application authN/authZ | SDS-01, SDS-07, SDS-09 |
| 3.3 Patch applications | Dependency updates, base image refresh | SDS-03, SDS-11 |
| 3.6 Restrict administrative privileges | Least-privilege pipelines and service identities | SDS-07, SDS-08, SDS-15 |
| 3.7 Application control | Code signing so scripts and binaries can be allow-listed | SDS-07, SDS-15 |
| 3.11 Secure configurations | IaC baselines, secure defaults | SDS-08 |
| 3.12 Data security controls | Encryption, secrets, data handling | SDS-02, SDS-09, SDS-12 |

## NIST SSDF mapping

| SSDF group | Meaning | Standards |
|---|---|---|
| **PO** Prepare the Organization | Roles, training, toolchains, secure environments | Operating model, SDS-01, SDS-07, Training |
| **PS** Protect the Software | Protect code, verify integrity, archive releases | SDS-01, SDS-02, SDS-03, SDS-07 |
| **PW** Produce Well-Secured Software | Design, reuse, coding, review, testing, secure defaults | SDS-04, SDS-05, SDS-06, SDS-08, SDS-09, SDS-13 |
| **RV** Respond to Vulnerabilities | Identify, assess, remediate, root cause | SDS-10, SDS-11 |

## Microsoft SDL mapping

| SDL practice | Standards |
|---|---|
| 1 Establish security standards, metrics, and governance | Operating model, Metrics |
| 2 Require use of proven security features, languages, and frameworks | SDS-04, SDS-09, Guides |
| 3 Perform security design review and threat modeling | SDS-05 |
| 4 Define and use cryptography standards | SDS-09 |
| 5 Secure the software supply chain | SDS-03 |
| 6 Secure the engineering environment | SDS-01, SDS-07 |
| 7 Perform security testing | SDS-06 |
| 8 Ensure operational platform security | SDS-08 |
| 9 Implement security monitoring and response | SDS-10, SDS-11 |
| 10 Provide security training | Training |
