# Program plan — step by step

Durations are planning estimates for a small core team (2–4 people). Adjust once Phase 0 confirms sponsorship and capacity.

```text
Phase 0  Mobilise            2–3 wks   Sponsor, scope, working group
Phase 1  Discover            6–8 wks   Teams, tech stacks, maturity, pain points
Phase 2  Define              6–8 wks   Baseline standards, tiers, archetype profiles
Phase 3  Pave                8–12 wks  Templates, pipelines, tooling (overlaps Phase 2)
Phase 4  Pilot               8 wks     3–5 teams across different archetypes
Phase 5  Scale               ongoing   Wave rollout to eHealth, then LHDs/networks/pillars
Phase 6  Sustain             ongoing   Metrics, champions, annual review
```

## Phase 0 — Mobilise

| Step | Output |
|---|---|
| 0.1 Confirm executive sponsor (CISO or delegate) and program owner. Anchor the mandate in PD2026_001 §2.3, which requires a resourced Secure-by-Design approach for statewide initiatives | Named sponsor, one-page mandate |
| 0.2 Agree scope: "all code" includes applications, scripts, IaC, integration, low-code, vendor-developed | Scope statement in [operating-model.md](operating-model.md) |
| 0.3 Collect existing material: current policies, architecture standards, past pen-test and audit findings, incident post-mortems involving code | Evidence folder (not in this repo) |
| 0.4 Form a Secure Development Working Group: security engineering, architecture, platform/DevOps, 3–4 engineering leads from different archetypes, one LHD representative | Terms of reference |
| 0.5 Stand up this repository in the organisation's source control | Repo live, CODEOWNERS populated |

**Exit test:** a sponsor has signed the mandate and the working group has met once.

## Phase 1 — Discover

Full method in the [discovery playbook](../01-discovery/README.md).

| Step | Output |
|---|---|
| 1.1 Build the team census: every team that writes or maintains code, including scripts | Team list with archetype guess |
| 1.2 Automated inventory from source control, CI/CD and cloud platforms | [Tech stack inventory](../01-discovery/tech-stack-inventory.md) |
| 1.3 Stakeholder interviews using the [interview guides](../01-discovery/interview-guides/) | Notes per interview |
| 1.4 One [team profile](../01-discovery/team-profile-template.md) per team; sample at least two teams per archetype | Profiles in `teams/` |
| 1.5 [Maturity self-assessment](../01-discovery/maturity-assessment.md) with each sampled team | Scores per team |
| 1.6 Synthesize: confirm archetypes, top risks, top friction points, tooling gaps | [Findings report](../01-discovery/findings-report-template.md) |

**Exit test:** the working group accepts the findings report and the archetype list. You can name the five highest-risk practices observed and the three most common tech stacks.

## Phase 2 — Define

| Step | Output |
|---|---|
| 2.1 Ratify risk tiers and how a system is assigned one | [Risk tiers](operating-model.md#risk-tiers) |
| 2.2 Review the draft standards in [02-standards](../02-standards/README.md) against discovery findings; cut what does not apply, add what is missing | Standards v1.0 candidates |
| 2.3 For each archetype, state which standards apply and how | [Archetype profiles](../04-team-archetypes/README.md) |
| 2.4 Write language guides only for stacks found in discovery, most common first | [Guides](../03-guides/README.md) |
| 2.5 Complete the [policy alignment](policy-alignment.md) mapping and have cyber governance check it | Signed-off mapping |
| 2.6 Two-week open comment period for all engineers | Comment log, changes made |

**Exit test:** every MUST has a reason, a verification method and an owner for its paved road.

## Phase 3 — Pave

| Step | Output |
|---|---|
| 3.1 Choose the supported toolchain per control (secret scanning, SCA, SAST, IaC scanning, SBOM). Prefer what teams already license | Tooling decision record in `decisions/` |
| 3.2 Publish reference pipelines | [pipelines/](../../pipelines/) |
| 3.3 Publish the organisation `.github` repository (default `SECURITY.md`, PR template, workflow templates) and a template repository built from [template-repo/](../../template-repo/README.md) (owner and tier `README`, `CODEOWNERS`, Copilot files, AI configuration check). Apply branch protection and required checks with organisation rulesets | `.github` repo, template repo, rulesets |
| 3.4 Org-level controls that need no team effort: push protection for secrets, default branch rules, dependency alerts | Enabled org-wide |
| 3.5 Build the exception register and a simple compliance view | Register + dashboard |

**Exit test:** a new repository created from the template meets the minimum baseline with zero manual steps.

## Phase 4 — Pilot

Pick 3–5 teams that differ: for example one application team, one endpoint/digital workspace team, one integration team, one LHD-based team. Include at least one sceptical team.

| Step | Output |
|---|---|
| 4.1 Baseline measurement before change | Metrics snapshot |
| 4.2 Onboard using the [onboarding checklist](../../teams/README.md) | Completed checklists |
| 4.3 Run checks in report-only mode. Push one routine release through, then rehearse a failed check, a rollback or recovery, and a tool outage | Evidence that one release is traceable end to end |
| 4.4 Weekly 30-minute friction review; fix the paved road, not the team | Change log |
| 4.5 Trial each common pattern on a second team or platform; agree who supports it and how fixes reach consumers | Named pattern owner |
| 4.6 Retrospective and standards revision. Propose enforcement only for controls with clear criteria, an owner, evidence and an approved exception path | Standards v1.0 |

**Exit test:** pilot teams meet the minimum baseline and would recommend the approach; false-positive rate from tooling is tolerable (target under 20% of findings dismissed as noise).

## Phase 5 — Scale

Roll out in waves ordered by risk and readiness, not by org chart.

1. **Wave 1:** eHealth NSW teams owning Tier 1 systems.
2. **Wave 2:** remaining eHealth NSW teams; statewide services with their own development (for example NSW Health Pathology).
3. **Wave 3:** LHDs and specialty networks with in-house development, starting with those who volunteer.
4. **Wave 4:** pillars, smaller entities, and vendor-developed software via contract clauses ([SDS-14](../02-standards/SDS-14-vendor-and-third-party-software.md)).

Each wave: announce → nominate champion → self-assess → onboard → verify → report.

## Phase 6 — Sustain

- Quarterly metrics to the governance committee ([metrics](../07-metrics/README.md)).
- Monthly champions community of practice ([training](../06-training/security-champions.md)).
- Annual review of every standard; re-run maturity assessment yearly.
- Feed incident and pen-test root causes back into standards within one month of the review.

## Beyond the standards

Candidate projects that build the shared paved roads (supply chain, secrets and non-human identity, synthetic test data, an AI gateway, a secure MCP and RAG reference, and others) are in the [DevSecOps project portfolio](project-portfolio.md).

## First 30 days checklist

- [ ] Sponsor and program owner named
- [ ] Working group invited
- [ ] Access to source control and CI/CD admin reporting arranged
- [ ] Team census started (ask the service desk, IAM group lists and cloud subscription owners, not just the org chart)
- [ ] First five discovery interviews booked across at least three archetypes
- [ ] This repository reviewed and placeholders marked **[VERIFY]** resolved
