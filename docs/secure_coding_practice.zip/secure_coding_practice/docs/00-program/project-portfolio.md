# DevSecOps project portfolio

> **Status: ideas for discussion, not approved projects.** Each entry is a starting point for a project brief. Scope, owners and funding are decided by the sponsor and the working group.

The secure development standards (SDS-01 to SDS-17) say what teams must do. Most of the projects below build the **paved roads** that make those standards easy to meet: shared services, templates and platform controls that reach every team without each team building them.

## Candidate projects

| # | Project | Why it matters at NSW Health | First deliverable | Standards it enables |
|---|---|---|---|---|
| 1 | **Supply chain hardening** | In March 2026 a widely used security scanner's GitHub Action tags were turned into a credential stealer (CVE-2026-33634); pipelines pinned to tags ran it | Internal package proxy; organisation ruleset enforcing SHA pinning; central SBOM store answering "where do we use X?" in minutes | SDS-03, SDS-07 |
| 2 | **CI/CD and GitHub organisation baseline as code** | Pipelines hold production credentials | Organisation rulesets, workload identity federation, isolated runners, organisation settings managed as code | SDS-01, SDS-07 |
| 3 | **Secrets and non-human identity** | Service accounts, pipeline identities and AI agents act without people; discovery has found agents with no owner | Inventory of non-human identities with owners; vault migration; rotation; agent identities in the AI register | SDS-02, SDS-13 |
| 4 | **Synthetic health test data service** | Real patient data in test is a breach waiting to happen, and teams use it because nothing better exists | Shared synthetic data generator (for example Synthea, which produces FHIR patient records) plus HL7 v2 message sets | SDS-12 |
| 5 | **Endpoint release pipeline** | Endpoint scripts and packages run as SYSTEM on every device | Central code-signing service; ring-based release pipeline; packaging checklist | SDS-15, SDS-07 |
| 6 | **Central AI gateway** | Without one, every AI application handles keys, logging, rate limits and data loss prevention itself | One gateway for model access, with logging to Sentinel and per-application limits | SDS-17 |
| 7 | **Secure AI reference stack (MCP and RAG)** | Teams are starting to build MCP servers and retrieval over documents; both carry new risks (see below) | MCP server template and a permission-aware RAG sample on synthetic data, with threat model and tests | SDS-13, SDS-17 |
| 8 | **Application security telemetry into Sentinel** | Security issues that slip past development have to be caught in production | Standard security event schema for applications, feeding the detection-as-code work in Sentinel | SDS-10 |
| 9 | **Secure FHIR and integration gateway reference** | Integration carries most health information and holds credentials to many systems | Reference API gateway with SMART on FHIR scopes, mutual TLS and message-level logging rules | SDS-09, SDS-10 |
| 10 | **One vulnerability backlog** | Findings scattered across tools get ignored | Findings from all scanners merged into team backlogs, with SLA dashboards by tier | SDS-11 |
| 11 | **Cloud guardrails and IaC module registry** | Misconfiguration is the main cloud risk | Policy-as-code in the landing zones; hardened, versioned IaC modules | SDS-08 |
| 12 | **Low-code and Copilot Studio governance** | Unowned agents have been found on low-code platforms | Environment strategy, connector policies, agent ownership checks | SDS-16, SDS-13 |
| 13 | **Supplier SBOM intake** | Vendors write most clinical code | Process to receive, store and query vendor SBOMs and vulnerability statements | SDS-14, SDS-03 |
| 14 | **Development incident playbooks and tabletops** | The first leaked secret or malicious package should not be the rehearsal | Playbooks, and a tabletop exercise built on a compromised-pipeline-tool scenario | SDS-02, SDS-11 |
| 15 | **End-of-life runtime remediation** | Unsupported runtimes cannot be patched | End-of-life list from discovery, then a funded migration plan | SDS-03, SDS-11 |

## Project 7 in more detail: secure AI reference stack

The recommendation is one reference project: a RAG service exposed through an MCP server, built on the central AI gateway (project 6) and synthetic data (project 4). MCP and RAG share most of their risks, so one project demonstrates the controls for both.

### MCP: consuming matters more than building

Most MCP risk will come from people plugging in third-party servers, not from servers NSW Health builds. Public agent-skill registries have already been used to spread malware: in February 2026 hundreds of malicious skills were found on ClawHub, the marketplace for the OpenClaw local agent.

**Consuming MCP servers.** These requirements already exist in [SDS-13](../02-standards/SDS-13-ai-assisted-development.md) R15 and R17:

- an approved server list
- pinned versions
- review before an update is accepted
- no credentials in configuration

The project adds the approved list and the Copilot MCP policy settings.

**Building MCP servers.** Publish a template repository that is secure by default:

- authentication on remote servers, with no forwarding of the user's token to downstream APIs
- each tool checks the end user's permissions itself, instead of relying on a broad service account
- schema-validated tool inputs
- tool descriptions that are code-reviewed and cannot change at run time
- read-only by default, with write tools behind an approval step
- rate limits, logging to Sentinel, and pinned dependencies

Check the template against the current MCP specification before publishing; its authentication guidance has changed between versions.

### RAG: the main risk is permissions

The most common RAG failure is an index that ignores document permissions, so anyone who can ask a question can retrieve anything indexed. With health records, that is a privacy breach. The reference shows:

- **Permission-aware retrieval:** results filtered by the user's access at query time, not when documents are indexed.
- **Controlled ingestion:** where each document came from is recorded, and who can add content is limited.
- **Indirect prompt injection tests:** a poisoned document placed in the index, not just a hostile question typed into the chat.
- **Data handling:** citations on every answer, PII handling, and logging the privacy office agrees to.
- **An evaluation harness:** run before every release.

Both halves map onto [SDS-17](../02-standards/SDS-17-ai-enabled-systems.md) and the starter technique sets in the [ATLAS guide](../03-guides/ai-security-with-atlas.md#starter-technique-sets-atlas-202610).

**Watch out:** demos get copied into production. Ship it as a template with tests and a threat model, never with real data, and state clearly which parts are production-grade.

## Suggested order

| Order | Projects | Reason |
|---|---|---|
| 1 | Supply chain hardening (1) and GitHub organisation baseline (2) | Fast and central; every team benefits without doing anything |
| 2 | Secrets and non-human identity (3) | Shadow AI and unowned agents make this urgent |
| 3 | Synthetic health test data (4) | Unblocks the AI reference stack and removes a major privacy risk |
| 4 | Central AI gateway (6), then the secure AI reference stack (7) | The reference stack is built on the gateway |
| 5 | Application telemetry into Sentinel (8) | Connects development to detection |

The remaining projects can be scheduled as discovery shows where each matters most.

## Next step

For each project the working group wants to pursue, write a one-page brief covering:

- problem and evidence
- scope
- owner
- first deliverable and its exit test
- dependencies
- cost
- the metric it moves ([metrics](../07-metrics/README.md))
