# Discovery playbook

**Goal:** know who writes code across NSW Health, what they write it in, how it reaches production, what it can touch, and what gets in their way — before writing a single mandatory requirement.

**Not the goal:** auditing teams. Say so at the start of every conversation. Discovery findings are not used for compliance action.

## The five questions discovery must answer

1. **Who?** Which teams produce code, including those who do not call it software.
2. **What?** Languages, frameworks, platforms, pipelines, hosting.
3. **How risky?** What data and privilege the code touches; which tier.
4. **How mature?** What security practices already happen, formally or informally.
5. **What hurts?** Where security currently slows teams down, and what they would want from a paved road.

## Method: three passes

### Pass 1 — Census (week 1–2): find the teams

The org chart undercounts. Combine:

- source control organisations and project lists (who has pushed in the last 12 months)
- CI/CD project and service connection owners
- cloud subscription and resource group owners
- owners of scheduled tasks, automation accounts, runbooks and endpoint-management script libraries
- integration engine interface owners
- low-code environment makers
- service desk categories and change records mentioning "script", "deploy", "release"
- a short open survey: "Does your team write or maintain any code, scripts, automations or reports? Tell us in two minutes."

Output: a list of teams, each with a contact and a first guess at [archetype](../04-team-archetypes/README.md).

### Pass 2 — Automated inventory (week 1–4): get facts without meetings

See [tech-stack-inventory.md](tech-stack-inventory.md). Pull language statistics, pipeline definitions, branch protection status, secret-scanning status and dependency manifests from the platforms. This tells you what is actually in use, which often differs from what people say.

### Pass 3 — Conversations (week 2–7): get context

- **Stakeholder interviews** using the [stakeholder map](stakeholder-map.md) and [interview guides](interview-guides/).
- **Team sessions** (60–90 minutes) with a sample of teams: at least two per archetype, mixing eHealth NSW and LHD/network/pillar teams, and mixing mature and struggling teams. Complete a [team profile](team-profile-template.md) and the [maturity self-assessment](maturity-assessment.md) in the session.
- **Walk a change to production.** Ask one engineer to show, on screen, how their last change went from idea to live, then describe the last emergency change. Record it on the [change walkthrough worksheet](change-walkthrough.md). This reveals more than any questionnaire.
- **Mark confidence.** Every answer is observed, reported or unknown.

### AI usage (alongside passes 1–3)

Find the AI tools, agents and integrations in use, including unapproved ones, following [AI usage discovery](ai-usage-discovery.md), and record them in the [AI register](ai-register-template.csv).

### Synthesis (week 7–8)

Complete the [findings report](findings-report-template.md):

- confirmed archetype list and how many teams sit in each
- technology heat map: languages × archetypes
- maturity by practice area
- top risks observed (for example long-lived credentials in scripts, unreviewed changes to privileged automation)
- top friction points
- recommended tooling decisions and the order of language guides
- which controls teams inherit from shared platforms, and whether that inheritance is actually enforced on their repositories and pipelines
- a [gap backlog](gap-backlog-template.csv): each gap with the observed behaviour, expected outcome, owner and an acceptance check

Group findings by delivery mechanism and risk first, organisation second. Prioritise by patient or service harm, privilege, exposure and sensitive data, then by how many teams one platform improvement would help. Offer a reusable pattern for repeated problems and a local fix for isolated ones.

## Sampling guide

| Population | Minimum sample |
|---|---|
| Each archetype | 2 teams |
| eHealth NSW | Every directorate that develops |
| LHDs | 1 metropolitan, 1 rural/regional |
| Specialty networks | 1 (for example Sydney Children's Hospitals Network) |
| Pillars / statewide services | 1–2 (for example Cancer Institute NSW, NSW Health Pathology) |
| Vendors | 2 major suppliers of developed software |

## Ground rules

- Send questions ahead. No surprises.
- Two people from the program in each session: one leads, one writes.
- Raw notes stay out of this repository. Only the team-reviewed profile is committed to `teams/`.
- If you see an urgent exposure (a live credential in a public place), handle it through the incident channel, separately, and tell the team you are doing so.
- Close the loop: every team gets its own profile back and the summary findings.

## Discovery deliverables checklist

- [ ] Team census
- [ ] Tech stack inventory (CSV) and heat map
- [ ] Stakeholder interview notes (private)
- [ ] Change walkthrough per sampled team (private)
- [ ] Team profiles for sampled teams
- [ ] Gap backlog
- [ ] AI register, with an owner or a decision for every agent found
- [ ] Maturity scores
- [ ] Findings report accepted by the working group
