# AI usage discovery

How to find the AI tools, agents and integrations in use, including the ones nobody approved, and what to do with each finding. Supports [SDS-13](../02-standards/SDS-13-ai-assisted-development.md).

Early assessment has already found agents with no owner, and AI tools from many providers on staff machines: model providers, data platforms, local model runtimes, developer tools with built-in AI, and autonomous local agents. Assume every team uses more AI than it reports.

## Where to look

| Source | What it shows | Owner to ask |
|---|---|---|
| Endpoint management and EDR inventory | Installed AI desktop apps, IDE extensions, command-line agents, local model runtimes, running processes | Endpoint / digital workspace |
| Browser extension inventory | AI assistants and agentic browser extensions | Endpoint / digital workspace |
| Listening ports on endpoints and servers | Local model runtimes and agent servers exposed to the network (SDS-13 R12) | Endpoint, security operations |
| Proxy, DNS and firewall logs | Traffic to AI service domains, by user and volume | Security operations |
| Identity provider: enterprise app consents and OAuth grants | AI apps and agents granted access to mail, files or calendars | Identity team |
| Low-code and Copilot Studio admin centres | Agents, their makers and owners, connectors, sharing | Low-code platform owner |
| GitHub organisation settings and audit log | Copilot seats, allowed models, MCP policy, AI apps installed on the organisation | Platform engineering |
| Repositories | AI SDKs, AI endpoints, model files, agent instruction files and MCP configuration: run [check_ai_config.py](../../template-repo/scripts/check_ai_config.py) across them | Platform engineering |
| Cloud subscriptions | AI services deployed (model endpoints, vector databases, notebooks with GPU) and who owns them | Cloud platform team |
| Procurement and expense records | AI subscriptions bought on cards or local purchase | Procurement |
| Interviews | What people actually use and why; see the AI questions in the [engineering team interview guide](interview-guides/04-engineering-team.md) | Teams |

Use only sources you are authorised to read, and tell teams you are doing this. The purpose is to understand use, not to catch people out.

## Record each finding

Add rows to the [AI register template](ai-register-template.csv). One row per tool, agent or integration, not per user.

## Triage

| Finding | Typical risk | First action |
|---|---|---|
| Agent or automation with no owner | Nobody accountable for what it can reach (AML.M0026) | Find an owner within a set period, or disable it (SDS-13 R11) |
| Autonomous local agent with shell, file or browser control | Full machine compromise through the agent; malicious skills from public registries (AML.T0112.000, AML.T0010.005) | Stop use on devices with production or health data access until assessed (SDS-13 R13) |
| Local model runtime listening on the network | Anyone on the network can use or tamper with it (AML.T0132) | Restrict to localhost or require authentication (SDS-13 R12) |
| Consumer AI service used with work data | Data leaves NSW Health control (PD2026_001 §4.4) | Assess what data was entered; report to HSOC if health, personal or operational data was involved |
| AI coding assistant not on the approved list | Code and secrets sent to an unassessed provider | Move to the approved assistant; rotate any secrets it may have seen |
| MCP server, skill or extension from a public registry | Tool poisoning, malicious updates (AML.T0110, AML.T0109) | Assess, pin, approve, or remove (SDS-13 R17) |
| AI app granted access to mail or files through OAuth consent | Standing access to large amounts of data | Review the consent with the identity team; revoke if not approved |

For each: decide approve and register, replace with an approved equivalent, or remove, and record the decision in the register.

## What the results feed

- The approved AI tools list (SDS-13 R1): if many people use one unapproved tool, assess it rather than banning it by default.
- The AI register (SDS-13 R11).
- The [findings report](findings-report-template.md): add an "AI use" section with counts by category and the top risks.
- The AI security program's detection work: domains, processes and ports to monitor.
