# Change walkthrough worksheet

Use in every team session. Ask the team to show one recent, approved, redacted change from request to production and support, then describe their most recent **emergency** change. Following one real change makes an endpoint packaging workflow, an LHD integration and a vendor release comparable without forcing them onto the same toolchain.

Keep completed worksheets in the restricted discovery location, not in this repository.

| Field | Value |
|---|---|
| Service ID, organisation, owner role | |
| Change type and redacted reference | |
| Participants, date, record location | |
| Business or clinical outcome affected | |
| Routine or emergency path | |

## The path

| Stage | Who does it, in which system | Who can change or bypass it? | Evidence reference | Confidence | Gap, owner, due date |
|---|---|---|---|---|---|
| Request, impact review and classification | | | | | |
| Source, configuration or vendor release | | | | | |
| Review and test | | | | | |
| Build, signing or export | | | | | |
| Approval and promotion | | | | | |
| Monitoring, stop and recovery | | | | | |

## Confidence

Mark every answer so the findings report does not present hearsay as fact.

| Label | Meaning |
|---|---|
| **Observed** | You saw it on screen or in a record |
| **Reported** | The team told you; not yet seen |
| **Unknown** | Nobody in the room knew. Record who can find out and by when |

Ask for one evidence reference per claimed control. If access is not available, record an owner and a verification date.

## Questions to ask at every stage

- Who can bypass this step, and where would a bypass show up?
- What is different for an emergency change?
- What is different for multiple tenants, external support staff, manual uploads or legacy tooling?
- Who can stop a rollout that is going wrong, and how is service restored when rollback cannot undo the effect on data?
- Is this control provided by the team, inherited from a shared platform, or shared? ([Who provides each control](../00-program/operating-model.md#who-provides-each-control))

## After the session

Draw the path from source or vendor through staging to production, marking identities and trust boundaries. Send the summary to the service owner and the platform owner to confirm. Turn each gap into a row in the [gap backlog](gap-backlog-template.csv).
