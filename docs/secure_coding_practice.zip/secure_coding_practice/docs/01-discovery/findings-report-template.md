# Discovery findings report — template

Audience: working group and sponsor. Keep to six pages. Aggregate only; no team is named against a weakness.

## 1. Summary

Three to five sentences: how many teams, the main archetypes, the biggest risk, the biggest opportunity, and what you recommend doing first.

## 2. Coverage

| | Number |
|---|---|
| Teams identified in census | |
| Teams profiled | |
| Stakeholder interviews | |
| Repositories / code assets inventoried | |
| Entities covered (eHealth NSW, LHDs, networks, pillars, statewide services) | |

## 3. Who writes code

| Archetype | Teams | People (approx.) | Entities | Typical tier |
|---|---|---|---|---|
| A Application and API | | | | |
| B Integration | | | | |
| C Platform, cloud and infrastructure | | | | |
| D Endpoint and digital workspace | | | | |
| E Data, analytics and AI | | | | |
| F Low-code | | | | |
| G Vendor-developed and configured | | | | |

Note any archetype that needs adding, splitting or removing.

## 4. Technology heat map

| | .NET | JS/TS | Python | Java | PowerShell | SQL | IaC | Low-code | Other |
|---|---|---|---|---|---|---|---|---|---|
| A | | | | | | | | | |
| B | | | | | | | | | |
| … | | | | | | | | | |

End-of-life technologies found:

## 5. Platform coverage

| Measure | % |
|---|---|
| Code assets in source control | |
| Repositories with branch protection | |
| Repositories with secret scanning | |
| Repositories with a CI pipeline | |
| Repositories with dependency scanning | |

## 6. Maturity

Average score per function by archetype, and the five lowest-scoring questions overall.

## 6a. AI use

| Category | Found | Approved | Owner assigned | Decision pending |
|---|---|---|---|---|
| Coding assistants and agents | | | | |
| Local model runtimes and autonomous local agents | | | | |
| Agents and automations acting on NSW Health systems | | | | |
| MCP servers, skills and extensions | | | | |
| AI services used with work data | | | | |
| Systems that call AI models | | | | |

Top AI risks and the approved tools teams are asking for.

## 7. Top risks observed

| # | Risk | Evidence (aggregate) | Affected archetypes | Proposed response |
|---|---|---|---|---|
| 1 | | | | |

## 8. Top friction points

What teams said slows them down, in their words.

## 9. Recommendations

- Changes to the draft standards (add, drop, re-tier)
- Tooling decisions needed
- Order of language guides
- Org-level controls to switch on now
- Proposed pilot teams

## 10. Decisions requested
