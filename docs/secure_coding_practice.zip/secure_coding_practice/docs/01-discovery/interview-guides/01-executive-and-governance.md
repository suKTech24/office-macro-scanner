# Interview guide — executive sponsor, governance, audit, learning

**Time:** 45 minutes. **Aim:** scope, authority, appetite, evidence expectations.

## Scope and authority

1. What outcome would make this program a success for you in 12 months?
2. Which entities can be mandated, and which must be persuaded? What is the mechanism for LHDs, specialty networks and pillars?
3. Is vendor-developed software in scope? Low-code? Scripts?
4. Which existing policy directives or standards touch software development today? Who owns them?

## Risk and obligations

5. How does NSW Health currently evidence the NSW Cyber Security Policy requirements that touch software (1.5, 1.10, 1.11, 1.12, 3.3, 3.11)?
6. What have audits (internal, Audit Office of NSW) or Cyber Security NSW reviews said about software, patching or third parties?
7. Which systems are on the Crown Jewel register, and how is a system classified? Can we reuse that scheme for risk tiers?
8. What is the appetite for blocking a release over a security finding? Who decides?
9. How are risk exceptions recorded today, and who can accept risk at each level?

## Resourcing

10. What funding or people exist for tooling, platform work and training?
11. Is there appetite for protected time for security champions (typically 10% of one engineer per team)?
12. Which tools are already licensed organisation-wide?

## Evidence and reporting

13. What would you want on a quarterly one-page report?
14. (Audit) What evidence would satisfy you that a standard is being followed?
15. (Learning) How is mandatory training assigned and tracked by role? Can it target "people who write code"?

## Close

16. Who else must we speak to? Who is likely to resist, and why?
