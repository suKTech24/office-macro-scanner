# Interview guide — security operations, testing, architecture, privacy

**Time:** 60 minutes. **Aim:** learn what actually goes wrong, so standards target real problems.

## Security operations and incident response

1. In the last two years, which incidents or near misses had a root cause in code, scripts, configuration-as-code, secrets or dependencies?
2. How often are credentials found in repositories, scripts, file shares or tickets? What happens next?
3. When a critical library vulnerability is announced, how do you find out which NSW Health systems use it? How long does that take?
4. Which application logs reach the SIEM? Which important systems are blind spots?
5. Which teams are easy to work with during an incident, and what makes them easy?

## Penetration testing and assurance

6. What are the five most common findings in internally developed systems? Do they recur after being fixed?
7. Which systems get tested, how often, and what triggers a test?
8. How are findings tracked to closure? What is the typical time to fix by severity?
9. Are vendor-developed systems tested the same way?

## Architecture

10. Is there a list of approved or preferred languages, frameworks and platforms? Is it followed?
11. Is there a design review or architecture board? At what point do projects reach it, and does it include threat modelling?
12. Which reference patterns exist for authentication, API exposure, secrets, logging?
13. Which shared platforms could host security controls for everyone?

## Privacy and data governance

14. What are the rules for using production health data in development and test? Are they followed?
15. When is a privacy impact assessment required for a software change?
16. What de-identification or synthetic data options exist?
17. How do the Mandatory Notification of Data Breach obligations affect how developers must report issues?

## Close

18. If you could make every development team do one thing differently tomorrow, what would it be?
