# Interview guide — platform, DevOps, cloud, change and release

**Time:** 60 minutes. **Aim:** learn what exists centrally, what can be enforced there, and what can be queried for the inventory.

## Source control

1. Which source control platforms are in use (GitHub, Azure DevOps, GitLab, Bitbucket, others)? How many organisations or collections, and who administers each?
2. Roughly how many repositories and active contributors? Can we get an export?
3. What is enforced at organisation level: SSO, MFA, branch protection, secret scanning with push protection, signed commits?
4. Where does code live that is **not** in source control (file shares, local machines, inside tools)?
5. How are contractors and vendors given access, and removed?

## Build and deployment

6. Which CI/CD systems are used? Are there shared templates, and what share of teams use them?
7. Are build agents shared or dedicated, hosted or self-hosted? Who patches them?
8. How do pipelines authenticate to cloud and on-premises targets (stored secrets, service principals, workload identity federation)?
9. Who can modify a pipeline that deploys to production? Is there separation between author and approver?
10. Are artefacts signed? Is there a central artefact or container registry? Are public registries reachable directly?

## Security tooling

11. Which tools are licensed and deployed: secret scanning, dependency scanning (SCA), SAST, DAST, IaC scanning, container scanning, SBOM generation?
12. For each: coverage, who sees results, false-positive experience, do findings block?
13. Where do findings end up (tool dashboard, backlog, nowhere)?

## Cloud and infrastructure

14. Which clouds and landing zones? Is infrastructure defined as code, and in what (Terraform, Bicep, ARM, CloudFormation)?
15. Which guardrails are applied by policy at platform level?
16. How are secrets stored and rotated (vault products, managed identities)?

## Change and release

17. How does a code change map to a change record? Is security assessed at that point?
18. What evidence is required for production release? Could pipeline output supply it automatically?
19. How do emergency changes bypass the normal path, and how often?

## Close

20. What data exports can you give us for the inventory, and what paved-road work is already planned?
