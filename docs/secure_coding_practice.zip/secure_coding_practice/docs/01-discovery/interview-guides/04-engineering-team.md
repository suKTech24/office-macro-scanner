# Interview guide — engineering team session

**Time:** 60–90 minutes with the lead and two or three engineers. **Aim:** complete the [team profile](../team-profile-template.md) and [maturity self-assessment](../maturity-assessment.md).

Works for any team that produces code. For endpoint, integration, data and low-code teams, swap "application" for "script", "interface", "notebook" or "flow" and use the extra questions at the end.

Open with: *"This is not an audit. We are trying to write guidance that fits how you work."*

## 1. What you build

1. What does the team build or maintain? Who uses it?
2. What data does it handle (health information, personal information, credentials)? What privilege does it run with?
3. What would happen if it failed or was tampered with? Any patient-safety pathway?
4. In-house, vendor, or mixed? Who else changes the code?

## 2. Technology

5. Languages, frameworks, runtimes and versions.
6. Where does it run (on-premises, which cloud, endpoints, SaaS)?
7. Where is the code stored? Is all of it in source control?
8. Which third-party libraries, modules or images do you depend on, and where do they come from?

## 3. Walk a change to production

Ask someone to share their screen and show the last change.

9. How was the work requested and designed? Was security considered at design?
10. Branching and review: who reviewed, and what do reviewers look for?
11. What runs automatically on commit or pull request?
12. How is it tested? Any security testing?
13. How is it deployed, by whom, with what credentials?
14. How would you roll it back?

## 4. Security practices today

15. Where do secrets live (connection strings, API keys, service account passwords)?
16. How do you learn about vulnerable dependencies, and how quickly are they updated?
17. Have you done threat modelling or a security design review? What triggered it?
18. What happened with the last pen-test or security finding?
19. What does the system log, and does anyone look?
20. Do you use AI coding assistants? Which, and with what rules?

## 5. People and friction

21. What security training have the team had? Was it useful?
22. Who do you ask when you have a security question? How long does an answer take?
23. Where does security slow you down most?
24. If we provided one thing — a template, pipeline, tool or person — what should it be?
25. Would someone on the team be willing to be a security champion?

## AI use (every team)

Ask without judgement; the aim is an accurate picture. Record answers in the [AI register](../ai-register-template.csv).

- Which AI tools do you use for this work: assistants, chat services, command-line or desktop agents, local models? Which models?
- Do any agents, bots or automations act on your behalf or on a schedule? Who owns each one?
- Have you added MCP servers, skills, extensions or prompt files? Where did they come from?
- What do you paste or send into AI tools: code, logs, tickets, data? Any patient or staff data?
- Do any AI tools hold credentials or tokens? Where are they stored?
- Does anything you build call an AI model or service? Which, and with what data?
- What would you want from an approved AI toolset that you do not have now?

## Extra questions by archetype

**Endpoint and digital workspace**

- How many devices can one script or package reach, and in what context does it run (SYSTEM, user)?
- Who can publish to the endpoint-management platform? Is there a second approver?
- Are scripts signed? Does execution policy or application control require it?
- How are packages from vendors verified before repackaging?
- Is there a test ring before broad deployment?

**Integration**

- Which engines and protocols (HL7 v2, FHIR, files, APIs)? How are interface credentials and certificates managed?
- How is message content protected in logs, queues and error stores?
- How are mapping changes tested and reviewed?

**Data, analytics and AI**

- Where do notebooks and queries run, and against which data? Are extracts stored locally?
- How are models and their training data versioned and reviewed?
- Which packages are installed, and from where?

**Low-code**

- Which environments exist, and who can create apps and flows?
- Which connectors are allowed? What data loss prevention policies apply?
- How does an app move from maker to production, and who owns it when the maker leaves?

**Vendor-configured systems**

- What custom code, scripts or extensions has NSW Health added?
- What does the vendor tell you about their secure development and vulnerability handling?
