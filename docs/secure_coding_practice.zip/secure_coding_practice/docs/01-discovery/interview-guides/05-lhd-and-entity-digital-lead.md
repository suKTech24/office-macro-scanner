# Interview guide — LHD, specialty network and pillar digital leads; clinical informatics

**Time:** 45–60 minutes. **Aim:** understand the local footprint and what a statewide baseline must allow for.

## Local footprint

1. Which teams or individuals locally write or maintain code, scripts, reports, integrations or low-code apps? Roughly how many people?
2. What do they build that statewide services do not provide? Why was it built locally?
3. Are there clinician- or researcher-built tools in use for patient care or operations? How did they come to be supported?
4. Which locally developed systems would you consider critical?

## Relationship to statewide services

5. Which eHealth NSW platforms do local teams use for source control, pipelines, hosting and identity? Which do they provide themselves?
6. What works well in dealing with statewide security and architecture? What does not?
7. Where local and statewide rules differ, which wins in practice?

## Capacity and governance

8. Who locally is accountable for cyber security, and how do they relate to development work?
9. Is there a local change advisory process? Does it look at security?
10. How much capacity is there to adopt new practices? What would have to stop to make room?
11. Who could act as a security champion locally?

## Local sensitivities

12. Are there data sets or patient groups with additional sensitivity (paediatric, custodial, mental health, cancer registry, genomics)?
13. Are there research or university partnerships that share code, data or infrastructure?
14. Any medical-device software or software that directly informs clinical decisions?

## Clinical safety (for clinical informatics)

15. How is clinical risk assessed for a software change? Who signs off?
16. Has a software defect or outage ever contributed to a clinical incident? What changed afterward?
17. Where should security and clinical safety reviews join up so teams are not asked twice?

## Close

18. What would make you adopt a statewide secure development baseline willingly? What would make you ignore it?
