# Interview guide — procurement, vendor management and vendors

**Time:** 45 minutes. **Aim:** understand how developed software is bought and what assurance is obtainable.

## Procurement and vendor management

1. Which standard contract clauses cover security of software developed for or supplied to NSW Health?
2. What security evidence is requested at tender and during the contract (certifications, test reports, SBOM)?
3. Who assesses that evidence? What happens when it is weak?
4. Who owns the source code and the right to audit or test it?
5. How are vendors required to notify vulnerabilities and breaches, and in what timeframe?
6. Which current contracts are up for renewal in the next 18 months (opportunities to add clauses)?
7. How are small local purchases (an LHD commissioning a small app) handled?

## Vendors and system integrators

8. Describe your secure development lifecycle. Which framework is it aligned to (SSDF, ISM, ISO 27001, SDL)?
9. How are your developers trained in secure coding?
10. What security testing runs before each release? Can you share results?
11. Can you supply an SBOM with each release? In which format?
12. How do you manage vulnerabilities in your dependencies, and what are your remediation timeframes?
13. How do you manage secrets and access to NSW Health environments?
14. Do your developers use AI coding tools on NSW Health work? Under what controls?
15. How do you notify customers of vulnerabilities, and do you have a disclosure policy?
16. Where is development done, and who has access to NSW Health code and data?
