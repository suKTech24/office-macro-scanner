# Maturity self-assessment

A 20-question assessment a team completes in about 30 minutes, with a facilitator. It is organised by the five OWASP SAMM business functions so results can later be compared with a full SAMM assessment, but it is deliberately lighter and worded for teams that do not build web applications.

## Scoring

| Score | Meaning |
|---|---|
| 0 | Does not happen |
| 1 | Happens sometimes, depends on the person |
| 2 | Happens consistently, is written down |
| 3 | Automated or enforced, and measured |

Score honestly. A low score earns help, not a finding. Record the average per function in the [team profile](team-profile-template.md).

## Governance

| # | Question | Score |
|---|---|---|
| G1 | The team knows which security standards apply to its work | |
| G2 | Each system has a known owner and risk tier | |
| G3 | Everyone who changes code has had role-relevant security training in the last 12 months | |
| G4 | Someone on the team is the named contact for security (champion) | |

## Design

| # | Question | Score |
|---|---|---|
| D1 | Security requirements are identified when work is planned | |
| D2 | Threat modelling or security design review happens for new systems and significant changes | |
| D3 | Third-party components, modules and images are chosen from known sources and assessed before use | |
| D4 | The team uses standard patterns for authentication, authorisation and secrets instead of inventing its own | |

## Implementation

| # | Question | Score |
|---|---|---|
| I1 | All code, including scripts and configuration, is in source control | |
| I2 | Every change is reviewed by a second person before reaching production | |
| I3 | No secrets are stored in code, scripts, pipeline variables in plain text, or shared files | |
| I4 | Builds and deployments are automated and repeatable; nobody deploys from a workstation | |
| I5 | Dependencies are inventoried and updated on a schedule | |

## Verification

| # | Question | Score |
|---|---|---|
| V1 | Automated security checks (secrets, dependencies, static analysis) run on every change | |
| V2 | Security findings are triaged and tracked to closure | |
| V3 | Higher-risk systems get security testing (for example penetration testing) before major releases | |
| V4 | Changes are tested in a non-production environment that contains no real patient data | |

## Operations

| # | Question | Score |
|---|---|---|
| O1 | Security-relevant events are logged and reach central monitoring | |
| O2 | The team can identify and patch a vulnerable component in production within the required timeframe | |
| O3 | The team knows what to do, and who to call, if a secret leaks or a vulnerability is reported | |

## Reading the results

| Average | Interpretation | Program response |
|---|---|---|
| Below 1.0 | Foundations missing | Onboard to the minimum baseline first; assign a coach |
| 1.0–1.9 | Practices exist but depend on individuals | Paved roads and templates |
| 2.0–2.6 | Consistent | Automate and measure; candidate to mentor others |
| Above 2.6 | Strong | Source of patterns and champions |

Aggregate across teams by archetype and by question. The lowest-scoring questions organisation-wide show where a paved road gives the most return.

## Later: full SAMM

Once the program is established, run a full OWASP SAMM assessment at program level annually. For pipeline-level detail with platform teams, use OWASP DSOMM.
