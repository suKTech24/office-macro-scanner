# Stakeholder map

Who to talk to, why, and what you need from each. Role titles are generic; replace with the actual NSW Health roles as you identify them.

| # | Stakeholder | Why they matter | What you need from them | Guide |
|---|---|---|---|---|
| 1 | **Executive sponsor** (CISO / CIO delegate) | Mandate, funding, escalation | Scope, authority over LHDs, risk appetite, success measures | [Executive](interview-guides/01-executive-and-governance.md) |
| 2 | **Cyber governance, risk and compliance** | Own NSW CSP attestation, risk register, exceptions | Current obligations, audit findings about software, classification scheme | [Executive](interview-guides/01-executive-and-governance.md) |
| 3 | **Security operations / incident response** (Health Security Operations Centre, HSOC) | Know what has actually gone wrong | Incidents and near misses rooted in code, scripts, secrets, dependencies | [Security teams](interview-guides/02-security-teams.md) |
| 4 | **Offensive security / pen-test coordinators** | Know recurring defect classes | Top recurring findings by system type | [Security teams](interview-guides/02-security-teams.md) |
| 5 | **Enterprise and security architecture** | Own patterns, technology standards | Approved tech list, reference architectures, design review process | [Security teams](interview-guides/02-security-teams.md) |
| 6 | **Platform / DevOps / cloud** | Own pipelines, source control, landing zones | What tooling exists, what is enforced centrally, what is licensed | [Platform](interview-guides/03-platform-and-devops.md) |
| 7 | **Engineering managers and tech leads** (per archetype) | Do the work | How change reaches production, pain points | [Engineering team](interview-guides/04-engineering-team.md) |
| 8 | **Endpoint and digital workspace leads** | Privileged automation at scale | Script lifecycle, signing, packaging, who can deploy to all devices | [Engineering team](interview-guides/04-engineering-team.md) + [archetype](../04-team-archetypes/endpoint-and-digital-workspace.md) |
| 9 | **Integration leads** | Move health information between systems | Interface development and testing practices | [Engineering team](interview-guides/04-engineering-team.md) |
| 10 | **Data, analytics and AI leads** | Notebooks, models, extracts of health data | Data access patterns, environments, model lifecycle | [Engineering team](interview-guides/04-engineering-team.md) |
| 11 | **LHD / network / pillar digital leads** (CIO, ICT director) | Local authority and local reality | Local development footprint, capacity, relationship to statewide services | [LHD and entity](interview-guides/05-lhd-and-entity-digital-lead.md) |
| 12 | **Clinical safety / clinical informatics** | Patient-safety view of software failure | How clinical risk is assessed for changes; medical-device software | [LHD and entity](interview-guides/05-lhd-and-entity-digital-lead.md) |
| 13 | **Privacy officers / data governance** | HRIP, PPIP, data breach scheme | Rules on test data, de-identification, privacy impact assessment triggers | [Security teams](interview-guides/02-security-teams.md) |
| 14 | **Procurement and vendor management** | Contract clauses for developed software | Standard clauses, assurance evidence requested today | [Vendor](interview-guides/06-procurement-and-vendors.md) |
| 15 | **Key vendors / system integrators** | Write a large share of the code | Their SDLC, evidence they can supply (SBOM, test reports) | [Vendor](interview-guides/06-procurement-and-vendors.md) |
| 16 | **Change and release management** | Existing control point | Where security fits into change approval today | [Platform](interview-guides/03-platform-and-devops.md) |
| 17 | **Learning and development** (incl. HETI where relevant) | Training delivery | Existing platforms, mandatory training mechanism | [Executive](interview-guides/01-executive-and-governance.md) |
| 18 | **Internal audit** | Will assess this later | What evidence they would expect | [Executive](interview-guides/01-executive-and-governance.md) |

## Order of conversations

1. Sponsor and governance (1, 2) — to fix scope and authority.
2. Security operations, pen-test, architecture (3–5) — to learn where the real problems are before meeting teams.
3. Platform (6, 16) — to learn what can be enforced centrally.
4. Engineering teams across archetypes (7–10) — the bulk of discovery.
5. LHD, network and pillar leads (11–12) — once you can describe the model.
6. Privacy, procurement, vendors, learning, audit (13–18) — in parallel from week 3.

## Influence and interest

| | Low interest | High interest |
|---|---|---|
| **High influence** | Keep satisfied: procurement, internal audit, change management | Manage closely: sponsor, governance, platform, engineering leads |
| **Low influence** | Inform: wider staff | Keep involved: security champions, individual engineers, clinical informatics |
