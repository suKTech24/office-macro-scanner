# Team profile — `<team name>`

Copy to `teams/<entity>/<team>/profile.md`. The team reviews it before it is committed. Do not record vulnerabilities, credentials or system weaknesses here.

| Field | Value |
|---|---|
| Entity | eHealth NSW / LHD / network / pillar / statewide service |
| Team | |
| Lead / contact | |
| Security champion | |
| Team size (people who change code) | |
| Archetype(s) | See [archetypes](../04-team-archetypes/README.md) |
| Profile date / reviewer | |

## What the team builds

| System / product | Purpose | Users | Risk tier | Data handled | Runs with what privilege | In-house / vendor |
|---|---|---|---|---|---|---|
| | | | | | | |

## Technology

| Area | Detail |
|---|---|
| Languages and versions | |
| Frameworks / runtimes | |
| Hosting (on-prem, cloud, endpoint, SaaS) | |
| Source control platform and location | |
| Code not in source control | |
| CI/CD tooling | |
| Package sources (registries, galleries) | |
| Infrastructure as code | |
| Secrets storage | |
| AI coding tools | |

## Path to production

Describe in five to ten lines how a change gets from idea to live, including who reviews and who deploys.

## Current security practices

| Practice | Status (none / ad hoc / consistent / automated) | Notes |
|---|---|---|
| Code in source control with review | | |
| Branch protection | | |
| Secrets kept out of code | | |
| Dependency scanning and updates | | |
| Static analysis | | |
| Threat modelling / design review | | |
| Security testing before release | | |
| Signed artefacts / scripts | | |
| Security logging | | |
| Vulnerability remediation tracking | | |
| Security training | | |

## Who provides each control

See [who provides each control](../00-program/operating-model.md#who-provides-each-control). An inherited control counts only if it is enforced on this team's repositories, tenants and pipelines.

| Standard | Team / inherited / shared / N/A | Provider | What is covered, and the team's remaining duties | Evidence or reason | Review date |
|---|---|---|---|---|---|
| SDS-01 | | | | | |
| SDS-02 | | | | | |
| … | | | | | |

## Maturity scores

From the [maturity self-assessment](maturity-assessment.md).

| Governance | Design | Implementation | Verification | Operations |
|---|---|---|---|---|
| | | | | |

## Friction and requests

- Biggest pain point with security today:
- What the team would most want from a paved road:
- Constraints (legacy platforms, vendor lock, staffing):

## Agreed next steps

| Action | Owner | Due |
|---|---|---|
| | | |
