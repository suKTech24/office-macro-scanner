# Tech stack inventory

How to find out what is actually in use: languages, frameworks, pipelines and hosting. Automated first, conversation second.

Record results in two files:

- [tech-stack-inventory-template.csv](tech-stack-inventory-template.csv): one row per repository or code asset.
- [stack-components-template.csv](stack-components-template.csv): one row per component of a service. A JavaScript front end, a .NET API and a Terraform deployment are three components of one service. Do not classify a team by whichever file type dominates its repository.

For each component record the **declared** version (what the manifest says) and the **deployed** version (what build output and the running environment show), plus the support end date. Differences between the two are findings. Mark each row observed, reported or unknown, as in the [change walkthrough](change-walkthrough.md#confidence).

Use only sources you are authorised to read. Start from the service catalogue or CMDB and ownership records, then ask platform administrators for scoped exports.

## Step 1 — Source control (covers most application code)

For each platform, pull for every repository: name, owner/team, last commit date, contributors in last 12 months, primary languages, default-branch protection, secret-scanning status, visibility.

| Platform | How |
|---|---|
| GitHub | REST/GraphQL API or `gh`: `gh repo list <org> --limit 1000 --json name,primaryLanguage,languages,pushedAt,visibility,isArchived` ; branch protection and security features via the repo API |
| Azure DevOps | REST API: projects → repositories → policy configurations; language breakdown per project via the project analytics endpoint |
| GitLab / Bitbucket | Projects API (`languages` endpoint in GitLab) |

Ignore repositories with no commits in 24 months for stack statistics, but list them: abandoned code that is still deployed is a risk finding.

## Step 2 — What the code declares

Language percentages mislead. Detect ecosystems from manifest files:

| File | Ecosystem |
|---|---|
| `*.csproj`, `packages.config`, `global.json` | .NET |
| `package.json` | Node.js / JavaScript / TypeScript |
| `requirements.txt`, `pyproject.toml`, `environment.yml` | Python |
| `pom.xml`, `build.gradle` | Java / Kotlin |
| `*.psd1`, `*.psm1`, `*.ps1` | PowerShell |
| `*.tf`, `*.bicep`, ARM `*.json`, CloudFormation | Infrastructure as code |
| `Dockerfile`, Helm charts, Kubernetes manifests | Containers |
| `azure-pipelines.yml`, `.github/workflows/`, `Jenkinsfile`, `.gitlab-ci.yml` | CI/CD |
| `*.sql`, `*.dacpac` | Database |
| `*.ipynb`, `*.R`, `*.Rmd` | Analytics |

An SBOM generator run across cloned repositories (for example Syft, or the platform's dependency graph export) gives the framework and library picture in one pass and seeds [SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md).

## Step 3 — Code that is not in source control

This is where endpoint, integration, data and low-code teams are found.

| Where to look | What you find |
|---|---|
| Endpoint-management platforms (script libraries, remediation scripts, packaged apps) | PowerShell, batch, installers |
| Automation accounts, runbooks, scheduled tasks, job schedulers | PowerShell, Python, shell |
| Group Policy logon/startup scripts | Batch, VBScript, PowerShell |
| Integration engines | Interfaces, mapping code, embedded scripts |
| Low-code admin centre | Apps, flows, makers, connectors |
| Analytics platforms and notebook workspaces | Notebooks, scheduled queries |
| Database servers | Stored procedures, agent jobs |
| ITSM / service portals | Workflow scripts, business rules |
| Shared drives | Everything else |

For each, record owner, count, language and whether it could move into source control.

## Step 4 — Hosting and runtime

From cloud inventory and the CMDB: subscriptions/accounts by owner, compute types (VMs, app services, containers, functions), public endpoints, and runtime versions. Flag end-of-life runtimes.

## Step 5 — Reconcile with what teams say

In each team session, show the team its inventory rows and ask what is missing or wrong. Differences are findings.

## Outputs

1. **Heat map** — archetypes down, technologies across, cell = number of teams. Decides which [language guides](../03-guides/README.md) to write first.
2. **Platform coverage** — share of code under source control, with branch protection, with secret scanning, with a pipeline.
3. **Long tail list** — technologies used by one or two teams. These get generic guidance, not a dedicated guide.
4. **End-of-life list** — unsupported languages, frameworks and runtimes.

## Data handling

The inventory reveals where weak points are. Store the full CSV in a restricted location; commit only aggregate results to this repository.
