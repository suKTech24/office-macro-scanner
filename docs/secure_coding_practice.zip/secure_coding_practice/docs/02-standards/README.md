# Secure development standards

> **DRAFT v0.1.** These are candidate standards to be tested against discovery findings (Phase 2) and ratified by the working group. Timeframes and thresholds are proposals.

## How to read a standard

- `MUST` / `MUST NOT` — mandatory. Deviation needs an approved [exception](../05-templates/exception-request.md).
- `SHOULD` — expected. Deviation needs a reason recorded by the team.
- **Tier** column — `All`, or the [risk tiers](../00-program/operating-model.md#risk-tiers) the requirement applies to. `T1` = Tier 1 only, `T1–2` = Tiers 1 and 2.
- **Verify** — how compliance is checked, ideally automatically.
- Each standard ends with its **paved road**: what the program provides so teams do not have to work it out alone.

## Index

| ID | Standard | Lifecycle stage | SSDF |
|---|---|---|---|
| [SDS-01](SDS-01-source-control-and-repository-security.md) | Source control and repository security | Protect | PS |
| [SDS-02](SDS-02-secrets-management.md) | Secrets management | Protect | PS |
| [SDS-03](SDS-03-dependencies-and-supply-chain.md) | Dependencies and software supply chain | Protect | PS, PW |
| [SDS-04](SDS-04-secure-coding.md) | Secure coding | Build | PW |
| [SDS-05](SDS-05-secure-design-and-threat-modelling.md) | Secure design and threat modelling | Design | PW |
| [SDS-06](SDS-06-security-testing.md) | Security testing | Verify | PW |
| [SDS-07](SDS-07-build-and-deployment-pipelines.md) | Build and deployment pipelines | Build, Release | PO, PS |
| [SDS-08](SDS-08-infrastructure-as-code-and-cloud.md) | Infrastructure as code and cloud configuration | Build | PW |
| [SDS-09](SDS-09-authentication-authorisation-cryptography.md) | Authentication, authorisation and cryptography | Design, Build | PW |
| [SDS-10](SDS-10-logging-and-monitoring.md) | Security logging and monitoring | Operate | RV |
| [SDS-11](SDS-11-vulnerability-management.md) | Vulnerability management | Operate | RV |
| [SDS-12](SDS-12-health-data-and-privacy.md) | Health data and privacy in development | All | PW |
| [SDS-13](SDS-13-ai-assisted-development.md) | AI tools, agents and AI-assisted development | Build | PO, PW |
| [SDS-14](SDS-14-vendor-and-third-party-software.md) | Vendor-developed and third-party software | Acquire | PO, PW |
| [SDS-15](SDS-15-scripts-and-automation.md) | Scripts and automation | Build | PW, PS |
| [SDS-16](SDS-16-low-code.md) | Low-code and citizen development | Build | PW |
| [SDS-17](SDS-17-ai-enabled-systems.md) | AI-enabled systems | Design, Build, Verify, Operate | PW, RV |

AI security runs through SDS-13 (AI in how we build) and SDS-17 (AI in what we build), with design-stage guidance in [AI security with MITRE ATLAS](../03-guides/ai-security-with-atlas.md).

Which standards apply to your team: see [team archetypes](../04-team-archetypes/README.md).

## The minimum baseline

If a team does nothing else, it does these ten. They apply to **every tier and every archetype**, and most can be enforced centrally.

| # | Requirement | Source |
|---|---|---|
| 1 | All code, scripts and configuration are in an approved source control platform | SDS-01-R1 |
| 2 | Access is through corporate identity with MFA; no shared accounts | SDS-01-R2 |
| 3 | The default branch is protected and every change is reviewed by a second person | SDS-01-R3, R4 |
| 4 | No secrets in code; secret scanning with push protection is on | SDS-02-R1, R2 |
| 5 | Dependencies come from approved sources and are scanned for known vulnerabilities | SDS-03-R1, R3 |
| 6 | Production deployment is done by a pipeline or controlled tool, not from a workstation | SDS-07-R1 |
| 7 | No real patient or staff data in development or test | SDS-12-R1 |
| 8 | Every repository names its owner and risk tier in its `README`, and has a vulnerability reporting route (the organisation default `SECURITY.md` counts) | SDS-01-R7, R7a |
| 9 | Critical and high vulnerabilities are fixed within the defined timeframes | SDS-11-R2 |
| 10 | Everyone who changes code completes role-relevant secure development training | [Training](../06-training/README.md) |

## Standard template

New standards follow [the standard template](../05-templates/standard-template.md).
