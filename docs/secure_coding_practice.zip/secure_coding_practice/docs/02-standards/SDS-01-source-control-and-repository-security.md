# SDS-01 Source control and repository security

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program | NSW CSP 1.6, 1.12, 3.2 · SSDF PS.1, PO.5 · SDL 6 |

**Why:** code that is not in source control cannot be reviewed, scanned, attributed or recovered. The repository is also a target: whoever can change it can change production.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | All code, scripts, IaC, pipeline definitions and configuration MUST be stored in an approved source control platform | All | Inventory reconciliation |
| R2 | Access MUST use corporate identity with single sign-on and MFA. Shared and personal accounts MUST NOT be used | All | Org settings |
| R3 | The default branch MUST be protected: no direct pushes, no force pushes, no deletion | All | Branch policy API |
| R4 | Every change MUST be reviewed and approved by someone other than the author before merge | All | Branch policy API |
| R5 | For Tier 1, review MUST include a designated code owner, and stale approvals MUST be dismissed when new commits are pushed | T1 | Branch policy API |
| R6 | Repository access MUST be granted to groups, not individuals, on a least-privilege basis and reviewed at least every 6 months. Admin rights MUST be limited to a separate small group | All | Access review record |
| R7 | Each repository MUST have a `README` that states its owner team, system owner, risk tier and data classification, and a `CODEOWNERS` file | All | Repo scan |
| R7a | Each repository MUST have a route for reporting vulnerabilities. The organisation default `SECURITY.md` in the `.github` repository provides it automatically. Add a repository `SECURITY.md` only for system-specific detail; because it replaces the default entirely, it MUST repeat the reporting channels | All | Repo scan |
| R8 | Repositories MUST be private/internal by default. Making a repository public requires approval and a secrets and data review of full history | All | Org settings |
| R9 | Commits SHOULD be signed; for Tier 1, commits to the default branch MUST be signed or made through a verified merge | T1 | Branch policy |
| R10 | Leavers' and contractors' access MUST be removed on the day their engagement ends | All | IAM lifecycle |
| R11 | Repositories no longer maintained MUST be archived (read-only), and the deployed system decommissioned or given a new owner | All | Activity report |

## Paved road

- Organisation-level rulesets applying R2–R4 and R8 automatically.
- Organisation `.github` repository supplying the default `SECURITY.md`, pull request template and workflow templates to every repository.
- [Template repository](../../template-repo/README.md) supplying what each repository needs its own copy of: `README` with owner and tier, `CODEOWNERS`, `.gitignore`, `dependabot.yml`, Copilot instructions and skills, and the AI configuration check. Use [`SECURITY-template.md`](../05-templates/SECURITY-template.md) only when a repository needs its own.
- A migration guide for teams moving scripts from file shares into source control ([scripts guide](../03-guides/powershell.md)).
