# SDS-02 Secrets management

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program | NSW CSP 3.2, 3.12 · SSDF PS.1, PW.1 · SDL 6 |

**Why:** leaked credentials are among the most common ways into an organisation, and scripts and pipelines are where they most often leak.

A **secret** is anything that grants access: passwords, API keys, tokens, connection strings with credentials, private keys, certificates with private keys, webhook URLs with embedded tokens.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Secrets MUST NOT be stored in source code, scripts, IaC, container images, pipeline YAML, wikis, tickets or chat | All | Secret scanning |
| R2 | Secret scanning with push protection MUST be enabled on every repository | All | Org settings |
| R3 | Secrets MUST be stored in an approved secrets manager and retrieved at run time | All | Design review, code scan |
| R4 | Workloads SHOULD authenticate with managed or federated identities instead of stored secrets wherever the platform supports it; for Tier 1 this is a MUST for new work | T1 (MUST), others (SHOULD) | Pipeline and IaC review |
| R5 | Each system, environment and pipeline MUST have its own credentials. Production secrets MUST NOT be usable from non-production | All | Vault access policy |
| R6 | Secrets MUST be rotatable without a code change, and rotated on staff departure, on suspected exposure, and at least annually for long-lived secrets (Tier 1: at least every 90 days unless short-lived by design) | All | Vault metadata |
| R7 | Secrets MUST NOT be written to logs, error messages or build output | All | Code review, log sampling |
| R8 | Service accounts used by code MUST have the least privilege needed and MUST NOT be interactive user accounts | All | Access review |

## If a secret leaks

1. **Revoke or rotate immediately.** Assume it has been copied.
2. Report it through the security incident channel ([SECURITY.md](../../SECURITY.md)).
3. Check access logs for use of the credential.
4. Remove it from history (history rewrite) only after rotation, and coordinate with the platform team.
5. Record the root cause; if a paved road would have prevented it, raise an issue here.

## Paved road

- Org-wide push protection.
- Code snippets per language for reading from the approved vault ([guides](../03-guides/README.md)).
- Pipeline templates using workload identity federation, so no deployment secret exists to leak.
- Pre-commit hook configuration for local secret scanning.
