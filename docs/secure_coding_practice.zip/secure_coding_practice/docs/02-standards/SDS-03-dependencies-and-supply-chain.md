# SDS-03 Dependencies and software supply chain

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program | NSW CSP 1.6, 1.10, 3.3 · SSDF PS.3, PW.4 · SDL 5 · SLSA · ASD SBOM guidance |

**Why:** most of the code in any system was written by someone else. When a widely used component is found vulnerable, the first question is "where do we use it?" and the answer has to take minutes.

Covers libraries and packages, PowerShell modules, container base images, IaC modules, pipeline actions/tasks, installers that are repackaged for deployment, and AI artefacts: models, datasets, MCP servers, agent skills and prompt packs ([SDS-13](SDS-13-ai-assisted-development.md) R17, [SDS-17](SDS-17-ai-enabled-systems.md) R5–R6).

Mutable version tags are not a pin. In March 2026 the release tags of a widely used security scanner's GitHub Action were force-pushed to a credential stealer (CVE-2026-33634), and every pipeline that referenced a tag ran it. Pin actions to a full commit SHA and images to a digest, and prefer releases that have been public for at least two weeks.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Dependencies MUST be obtained from approved sources: the organisation's package proxy/registry, or official public registries where no proxy exists | All | Build config |
| R2 | Dependencies MUST be declared in a manifest and pinned with a lock file or exact versions. Container base images and pipeline actions MUST be pinned by digest or commit for Tier 1 | All / T1 | Repo scan |
| R3 | Software composition analysis MUST run on every change and on a schedule against the default branch | All | Pipeline |
| R4 | A new dependency MUST be assessed before first use: maintained, appropriately licensed, no known critical vulnerabilities, name checked against typosquatting | All | PR review |
| R5 | Automated dependency update proposals MUST be enabled and reviewed at least monthly | All | Repo settings |
| R6 | Dependencies with known critical or high vulnerabilities MUST be remediated within the timeframes in [SDS-11](SDS-11-vulnerability-management.md) | All | SCA dashboard |
| R7 | An SBOM (SPDX or CycloneDX) MUST be generated for each release and stored with the artefact | T1–2 | Pipeline artefact |
| R8 | Components that are end-of-life or unmaintained MUST NOT be used in new work; existing use requires a plan or an exception | All | SCA policy |
| R9 | Build artefacts MUST be stored in an approved registry and, for Tier 1, have build provenance recorded (target: SLSA Build Level 2) | T1 | Registry |
| R10 | Third-party installers and binaries MUST be obtained from the vendor's official source and have their signature or hash verified before repackaging or deployment | All | Packaging record |

## Paved road

- Internal package proxy for the ecosystems found in discovery.
- SCA and SBOM steps in the [reference pipelines](../../pipelines/README.md).
- Dependency update bot configuration in the repo template.
- A central SBOM store so "where do we use X?" is one query.
