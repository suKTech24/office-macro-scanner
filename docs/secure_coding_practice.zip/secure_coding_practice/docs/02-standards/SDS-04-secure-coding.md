# SDS-04 Secure coding

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program | ISM Guidelines for software development (ISM-0401) · SSDF PW.5, PW.6 · SDL 2 · OWASP Top 10, ASVS |

**Why:** a small number of defect classes cause most exploitable vulnerabilities. Most can be removed by using the framework's safe mechanism instead of building one by hand.

Language-specific detail is in the [guides](../03-guides/README.md). This standard states what is true in every language.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | All input from outside the trust boundary (users, files, messages, APIs, other systems) MUST be validated against an allow-list of expected type, length, format and range, on the server side | All | Code review, SAST |
| R2 | Queries and commands MUST be built with parameterisation or safe APIs. String concatenation of untrusted data into SQL, shell, LDAP, XPath or dynamic code evaluation MUST NOT be used | All | SAST |
| R3 | Output MUST be encoded for its context (HTML, attribute, JavaScript, URL) using the framework's auto-escaping | All | SAST, DAST |
| R4 | Authentication, session management, cryptography and access control MUST use vetted framework or platform features, not custom implementations ([SDS-09](SDS-09-authentication-authorisation-cryptography.md)) | All | Design and code review |
| R5 | Access control MUST be enforced on the server for every request and deny by default | All | Code review, testing |
| R6 | Untrusted data MUST NOT be deserialised into arbitrary object types | All | SAST |
| R7 | Errors MUST fail closed and MUST NOT disclose stack traces, queries, secrets or internal paths to users | All | Testing |
| R8 | File handling MUST validate type and size, store uploads outside the web root, and prevent path traversal | All | Code review |
| R9 | Outbound requests to user-supplied destinations MUST be restricted to an allow-list | T1–2 | Code review |
| R10 | New systems SHOULD use memory-safe languages. New use of memory-unsafe languages requires justification in the design record | All | Design review |
| R11 | Code MUST be supported by linters and compiler warnings appropriate to the language, with security rules enabled | All | Pipeline |
| R12 | Debug features, test accounts and sample content MUST be removed or disabled in production builds | All | Release checklist |

## Paved road

- [Language guides](../03-guides/README.md) with safe and unsafe examples.
- Linter and SAST rule sets per language in the repo templates.
- [Secure code review checklist](../05-templates/secure-code-review-checklist.md).
- Links to the OWASP Cheat Sheet Series for depth.
