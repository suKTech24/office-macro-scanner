# SDS-05 Secure design and threat modelling

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program | ISM-0401 (secure by design) · NSW CSP 1.12 · SSDF PW.1, PW.2 · SDL 3 |

**Why:** design flaws cannot be scanned for and are the most expensive to fix later. A one-hour conversation at the whiteboard is the cheapest security control there is.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Security requirements MUST be identified at the start of new systems and significant changes, using the [security requirements checklist](../05-templates/security-requirements-checklist.md) | All | Design record |
| R2 | A threat model MUST be produced for new Tier 1 and Tier 2 systems and updated on significant change | T1–2 | Threat model in repo |
| R3 | For Tier 1, the threat model MUST be reviewed by security architecture before build begins | T1 | Review record |
| R4 | Identified threats MUST each have a decision: mitigate, accept (with owner), transfer or avoid, tracked in the backlog | T1–2 | Backlog links |
| R5 | Designs MUST apply least privilege, defence in depth, secure defaults and fail-safe behaviour | All | Design review |
| R6 | Designs MUST use approved reference patterns for identity, secrets, network exposure and logging where they exist | All | Design review |
| R7 | Where failure or tampering could affect patient care, the design review MUST include clinical safety | T1 | Review record |
| R8 | Significant security decisions MUST be recorded as decision records in the repository | T1–2 | Repo |

**Significant change** means: a new external interface or integration; a change to authentication or authorisation; a new category of data; a change of hosting or trust boundary; adding an AI component; a change in who can deploy.

## Method

Use the four questions: *What are we working on? What can go wrong? What are we going to do about it? Did we do a good job?* A data-flow diagram and STRIDE per element is enough for most systems. A lightweight version for scripts and automation is in the [threat model template](../05-templates/threat-model-template.md).

## Paved road

- [Threat model template](../05-templates/threat-model-template.md) kept as Markdown beside the code.
- Facilitated first session for each team, run by a champion or the program.
- Library of common threats per archetype, built up from completed models.
