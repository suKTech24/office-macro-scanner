# SDS-06 Security testing

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program | NSW CSP 1.11, 1.12 · SSDF PW.7, PW.8 · SDL 7 · OWASP ASVS |

**Why:** automated checks catch the common defects cheaply on every change; human testing finds what tools cannot.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Secret scanning, software composition analysis and static analysis (SAST or security linting) MUST run on every pull request | All | Pipeline |
| R2 | IaC and container image scanning MUST run where IaC or containers are used | All | Pipeline |
| R3 | New critical and high findings MUST block merge for Tier 1 and Tier 2. Tier 3 MUST at least report them | T1–2 / T3 | Branch policy |
| R4 | Findings MUST be triaged: fixed, or dismissed with a recorded reason. A dismissal MUST state the finding or scope it covers, the rationale, an owner and a revisit date. Suppressions MUST be in code or configuration, visible in review | All | Tool report |
| R4a | A check that failed to run (tool outage, timeout, misconfiguration) MUST be reported as a tool failure, not as a pass, and MUST have a named responder | All | Pipeline status |
| R5 | Web applications and APIs MUST have dynamic testing (DAST or API security testing) before major releases | T1–2 | Test record |
| R6 | Tier 1 systems MUST have an independent penetration test before first release, after significant change, and at least annually | T1 | Test report |
| R7 | Security-relevant behaviour (authentication, authorisation, input validation) MUST have automated tests, including negative cases | T1–2 | Test suite |
| R8 | Test results MUST be retained as release evidence | T1–2 | Pipeline artefacts |
| R9 | Penetration test findings MUST be tracked to closure under [SDS-11](SDS-11-vulnerability-management.md) and retested | All | Tracker |

## Rollout guidance

Turn tools on in **report-only** mode first, tune rules for a few weeks, then enforce blocking on new findings only. Existing findings become an owned baseline with its own plan; new or materially worse findings are triaged. Switching on blocking for everything on day one teaches teams to bypass the tool.

Before enforcing, agree what blocks, who responds when a tool is down, and how findings are validated. Good first blockers are confirmed exposed secrets, an artefact whose integrity cannot be verified, and a missing mandatory approval. Prove each check with a small synthetic case that has a known result before inviting more teams.

## Paved road

- [Reference pipelines](../../pipelines/README.md) with all R1–R2 checks.
- Tuned rule sets per language.
- A booking process and scope template for penetration tests.
