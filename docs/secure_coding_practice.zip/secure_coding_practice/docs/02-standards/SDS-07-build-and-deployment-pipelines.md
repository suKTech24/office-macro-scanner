# SDS-07 Build and deployment pipelines

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program + Platform | NSW CSP 1.12, 3.2, 3.6, 3.7 · SSDF PO.3, PO.5, PS.2 · SDL 6 · SLSA |

**Why:** a pipeline holds production credentials and runs whatever code it is given. Compromising it is equivalent to compromising production.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Production deployments MUST be performed by an approved pipeline or controlled deployment tool. Manual deployment from a workstation MUST NOT be used except under the emergency change process | All | Deployment logs |
| R2 | Pipeline definitions MUST be stored as code in source control and subject to the same review as application code | All | Repo |
| R3 | The person who writes a change MUST NOT be the only person who approves its deployment to production | T1–2 | Environment approvals |
| R4 | Pipelines MUST authenticate to targets with short-lived, federated credentials where supported. Long-lived deployment secrets require an exception for Tier 1 | All / T1 | Pipeline config |
| R5 | Pipeline identities MUST have least privilege, scoped per environment. A non-production pipeline MUST NOT be able to deploy to production | All | Access review |
| R6 | Third-party pipeline actions, tasks and plugins MUST come from an approved list and be pinned to a commit or digest | All | Pipeline lint |
| R7 | Pipelines triggered by untrusted input (forks, external contributors) MUST NOT have access to secrets | All | Pipeline config |
| R8 | Build agents MUST be patched and hardened; self-hosted agents for Tier 1 SHOULD be ephemeral | All / T1 | Agent inventory |
| R9 | Releases MUST be built once and the same artefact promoted through environments | T1–2 | Pipeline design |
| R10 | Release artefacts, executables and scripts deployed to endpoints or servers MUST be signed with an organisation-managed certificate where the target platform supports verification | T1–2 | Artefact check |
| R11 | Pipeline runs and deployment approvals MUST be logged and retained | All | Platform logs |
| R12 | Emergency ("break-glass") deployments MUST be logged, alerted and reviewed afterwards | All | Change records |

## Paved road

- [Reference pipelines](../../pipelines/README.md) for GitHub Actions and Azure DevOps.
- Federated identity setup guide per cloud.
- Central code-signing service so teams never hold signing keys.
- Approved actions/tasks list.
