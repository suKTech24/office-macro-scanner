# SDS-08 Infrastructure as code and cloud configuration

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program + Platform | NSW CSP 3.11, 3.6, 3.15 · SSDF PW.9 · SDL 8 |

**Why:** misconfiguration, not exotic exploitation, is behind most cloud exposure. Defining infrastructure in code makes configuration reviewable and repeatable.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Cloud and platform resources for Tier 1 and Tier 2 MUST be defined as code and deployed through a pipeline. Manual portal changes to production MUST NOT be made outside break-glass | T1–2 | Drift detection |
| R2 | IaC MUST be scanned for misconfiguration on every change | All | Pipeline |
| R3 | Resources MUST be deployed into approved landing zones and comply with platform policy guardrails | All | Policy compliance |
| R4 | Resources MUST NOT be publicly reachable unless the design explicitly requires it and it is recorded in the threat model | All | IaC scan, cloud posture |
| R5 | Data stores MUST encrypt at rest and require encryption in transit ([SDS-09](SDS-09-authentication-authorisation-cryptography.md)) | All | IaC scan |
| R6 | Identities and role assignments MUST follow least privilege. Wildcard permissions and standing owner-level rights MUST NOT be assigned to workloads | All | IaC scan, access review |
| R7 | IaC state files MUST be stored in a protected remote backend with access control and encryption, never in a repository | All | Repo scan |
| R8 | Shared IaC modules MUST be versioned and sourced from the approved module registry | All | IaC review |
| R9 | Container images MUST be built from approved base images, run as non-root, and be rebuilt at least monthly to pick up patches | All | Image scan |
| R10 | Diagnostic and audit logging MUST be enabled on all resources ([SDS-10](SDS-10-logging-and-monitoring.md)) | All | Policy compliance |
| R11 | Non-production environments MUST be isolated from production networks and identities | All | Architecture review |

## Paved road

- Approved, pre-hardened IaC modules for common resources.
- Policy-as-code guardrails in the landing zones, so many of these cannot be violated.
- [IaC guide](../03-guides/infrastructure-as-code.md).
