# SDS-09 Authentication, authorisation and cryptography

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program + Security Architecture | NSW CSP 3.2, 3.5, 3.12 · ISM Guidelines for cryptography · SSDF PW.1 · SDL 2, 4 |

**Why:** these are the areas where home-made solutions fail most often and most badly.

## Authentication

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Applications MUST authenticate staff through the organisation's identity provider using standard protocols (OpenID Connect, SAML). Applications MUST NOT keep their own staff password stores | All | Design review |
| R2 | MFA MUST be enforced for all staff access to Tier 1–2 systems and for all privileged access | T1–2 | IdP policy |
| R3 | Service-to-service calls MUST be authenticated with managed identities, mutual TLS or signed tokens, not shared static keys, for new work | All | Design review |
| R4 | Sessions and tokens MUST expire, be revocable, and be protected in transit and storage | All | Testing |

## Authorisation

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R5 | Access MUST be denied by default and enforced server-side on every request, including for individual records (object-level checks) | All | Testing |
| R6 | Roles MUST follow least privilege and separate administrative from ordinary functions | All | Design review |
| R7 | Access to health information MUST be attributable to an individual and logged ([SDS-10](SDS-10-logging-and-monitoring.md)) | T1–2 | Log review |

## Cryptography

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R8 | Only ASD-approved cryptographic algorithms and protocols, as listed in the current ISM, MUST be used. Teams MUST NOT design their own cryptography | All | SAST, design review |
| R9 | Data in transit MUST be protected with a current TLS version; certificate validation MUST NOT be disabled | All | Scan, code review |
| R10 | Sensitive data at rest MUST be encrypted using platform-managed encryption, with keys in an approved key management service | All | IaC scan |
| R11 | Passwords, where an application must store them (non-staff users), MUST be hashed with a current password-hashing algorithm with a per-user salt | All | Code review |
| R12 | Random values used for security MUST come from a cryptographically secure generator | All | SAST |
| R13 | Keys and certificates MUST have an owner, an expiry and a rotation process | All | Inventory |

**[VERIFY]** Insert the organisation's approved algorithm and TLS configuration list, derived from the current ISM cryptography guidelines, and consider post-quantum transition guidance.

## Paved road

- Reference integration for the identity provider per framework ([guides](../03-guides/README.md)).
- Approved crypto library list per language.
- Managed certificate and key services.
