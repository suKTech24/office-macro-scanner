# SDS-10 Security logging and monitoring

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program + Security Operations | NSW CSP 2.1 · ISM Guidelines for system monitoring · SSDF PW.9, RV.1 · SDL 9 |

**Why:** if an application does not record who did what, an incident cannot be detected, investigated or scoped, and a privacy breach cannot be assessed.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Applications MUST log security events: authentication success and failure, authorisation failure, privilege and configuration changes, administrative actions, input validation failures, and access to health information | T1–2 | Log review |
| R2 | Each event MUST record when (synchronised time, UTC or with offset), who (user or service identity), from where, what action, on what object, and the outcome | T1–2 | Log review |
| R3 | Logs MUST NOT contain secrets, full credentials, session tokens, or health information beyond the minimum identifiers needed to investigate | All | Code review, log sampling |
| R4 | Logs MUST be sent to the central logging platform / SIEM and protected from alteration by the application's own administrators | T1–2 | SIEM onboarding record |
| R5 | Log data MUST be neutralised against injection (newlines, control characters) and written in a structured format | All | SAST |
| R6 | Logs MUST be retained in line with NSW Health records requirements **[VERIFY retention periods]** | All | Platform config |
| R7 | Tier 1 systems MUST define, with security operations, the alerts that matter for that system | T1 | Alert catalogue |
| R8 | Scripts and automation that run with privilege MUST log their execution, target and result to a central location | T1–2 | Log review |

## Paved road

- Structured logging library configuration per language.
- A standard security event schema.
- SIEM onboarding checklist from security operations.
