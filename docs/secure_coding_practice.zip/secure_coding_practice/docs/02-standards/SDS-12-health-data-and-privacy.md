# SDS-12 Health data and privacy in development

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program + Privacy | HRIP Act 2002 (NSW) · PPIP Act 1998 (NSW) incl. MNDB scheme · NSW CSP 1.8, 3.12 |

**Why:** health information is the most sensitive data NSW Health holds. Development and test environments are less protected than production, so real data there is a breach waiting to happen.

> This standard states engineering practice. It does not replace legal or privacy advice. **[VERIFY]** with the privacy office and align with NSW Health privacy policy directives.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Identifiable patient or staff data MUST NOT be used in development, test, training or demonstration environments. Use synthetic or properly de-identified data | All | Environment review |
| R2 | Where production data is unavoidable for a specific defect investigation, it MUST be approved by the data custodian, time-limited, access-controlled to the same standard as production, and removed afterwards | All | Approval record |
| R3 | Health and personal information MUST NOT appear in source code, test fixtures, commit messages, tickets, screenshots, logs, error reports or chat | All | Scanning, review |
| R4 | Health and personal information MUST NOT be entered into AI tools, online utilities or any service not approved for that data ([SDS-13](SDS-13-ai-assisted-development.md)) | All | Policy, DLP |
| R5 | Systems MUST collect and retain only the data needed for their purpose, and support retention and disposal requirements | All | Design review |
| R6 | A privacy impact assessment MUST be considered at design for any new collection, use, disclosure or linkage of personal or health information, following the privacy office's process | T1–2 | Design record |
| R7 | Data extracts (files, notebook outputs, local databases) MUST be stored only in approved locations and deleted when no longer needed | All | Endpoint and storage controls |
| R8 | Where data is hosted or processed, including by vendors and cloud services, MUST comply with NSW Health data sovereignty requirements **[VERIFY]** | All | Design review |
| R9 | Any suspected exposure of personal or health information from a development activity MUST be reported immediately so that data breach notification obligations can be assessed | All | Incident records |
| R10 | Software that may meet the definition of a medical device (including clinical decision support and AI) MUST be referred for regulatory assessment before development proceeds | T1 | Design record |

## Local sensitivities

Entities add a short local profile where extra care applies, for example paediatric records (Sydney Children's Hospitals Network), custodial health (Justice Health and Forensic Mental Health Network), cancer registry data (Cancer Institute NSW), genomics, mental health and sexual health.

## Paved road

- A synthetic data set and generator for common health data shapes (patients, encounters, HL7 v2 and FHIR messages).
- Pattern-based scanning for identifiers in repositories.
- A simple "can I use this data here?" decision table agreed with the privacy office.
