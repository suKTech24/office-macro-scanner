# SDS-13 AI tools, agents and AI-assisted development

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.2 | Draft | Secure Development Program | PD2026_001 §4.4 (Generative AI and NSW Health) · NSW Health IB2024_059 (advice on generative AI) · Digital NSW AI Assessment Framework · ISM Guidelines for software development (2026 updates treat AI agents as developers) · MITRE ATLAS 2026.10 · SSDF PW |

**Why:** AI coding assistants, command-line agents, local model runtimes and autonomous desktop agents are already on staff machines. Discovery has found agents with no owner and tools from many providers, most never approved. Each one is software with access to code, credentials and data, and each takes instructions from files and content that someone else may have written. The rule is simple: an AI tool is held to the same standard as any other software, AI-written code to the same standard as human-written code, and a human is accountable for both.

**Scope:** the AI tools and agents that people use to build and operate software, including:

- IDE assistants such as GitHub Copilot
- command-line and autonomous agents
- local model runtimes
- computer-use agents
- MCP servers, skills, prompts and agent instruction files

Building AI into a product or service is [SDS-17](SDS-17-ai-enabled-systems.md). Enterprise-wide AI governance, detection and red teaming are owned by the AI security program; this standard covers what engineers do.

Requirement IDs are stable: R1–R10 are unchanged from version 0.1, and new requirements are added at the end. MITRE ATLAS identifiers show the attack each requirement addresses; see the [ATLAS guide](../03-guides/ai-security-with-atlas.md).

## Approved tools and the AI register

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R1 | Only organisation-approved AI tools, models and providers MUST be used for NSW Health work. The approved list states, for each, the data classification it is cleared for, where data is processed, and whether it can run commands or change files | All | Approved list, endpoint inventory | AML.T0112.000 |
| R2 | Health information, personal information, secrets and security-sensitive details MUST NOT be entered into AI tools unless the tool is approved for that data. Health, personal or operational data MUST NOT be contributed to any publicly available generative AI model (PD2026_001 §4.4) | All | Policy, DLP | AML.T0085 |
| R11 | Every AI agent, bot, scheduled automation or MCP server that acts on NSW Health systems or data MUST be registered with a named owner, its purpose, the identity it runs as, and the tools and data it can reach. An agent without an owner MUST be disabled until one is assigned | All | AI register | AML.M0026, AML.M0043 |
| R12 | Local model runtimes and agent servers MUST listen only on the local machine or require authentication, and MUST NOT be reachable from the network | All | Endpoint and network scan | AML.T0132 |
| R13 | Autonomous agents that can operate the desktop, browser or shell unattended MUST NOT run on devices with access to production systems or health information unless approved, isolated (for example in a dedicated virtual machine), and without stored privileged credentials | All | Endpoint inventory | AML.T0112.000, AML.T0105 |

## Agent configuration is code

Instruction files, prompts, skills, chat modes, agent definitions and MCP configuration decide what an AI tool does. Changing them is changing the tool.

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R14 | Agent configuration in a repository MUST be version-controlled, reviewed like code, and covered by `CODEOWNERS` | All | Repo scan | AML.T0081 |
| R15 | Agent configuration MUST NOT contain credentials. MCP configuration MUST reference secrets through input variables or environment references | All | [AI configuration check](../../template-repo/scripts/check_ai_config.py) | AML.T0083 |
| R16 | Agent configuration MUST NOT contain hidden or direction-changing characters, checked automatically on every pull request | All | AI configuration check | AML.T0068, AML.T0081 |
| R17 | Skills, prompts, MCP servers and agent tools from outside NSW Health are dependencies. They MUST be assessed before first use, obtained from an approved source, pinned to a version, and re-reviewed when updated, because a tool that was safe can turn malicious in an update ([SDS-03](SDS-03-dependencies-and-supply-chain.md)) | All | PR review, approved list | AML.T0010.005, AML.T0110, AML.T0109 |

## Working with AI-generated code

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R3 | The engineer who commits AI-generated code is accountable for it and MUST understand it. AI-generated changes MUST go through the same review, scanning and testing as any other change | All | Branch policy | |
| R4 | AI review MUST NOT replace the required human review ([SDS-01](SDS-01-source-control-and-repository-security.md) R4) | All | Branch policy | |
| R5 | Dependencies suggested by AI MUST be verified to exist, be the intended package, and be assessed under [SDS-03](SDS-03-dependencies-and-supply-chain.md) R4. Attackers register package names that models invent | All | PR review | AML.T0060 |
| R9 | Significant use of AI generation SHOULD be noted in the pull request so reviewers can calibrate | All | PR template | |
| R10 | Licensing and intellectual property implications of AI-generated code MUST follow NSW Health legal guidance **[VERIFY]** | All | Policy | |

## Agents that act

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R6 | AI agents that can run commands, change files or call tools MUST run with least privilege, without access to production credentials, and in an environment where their actions can be reviewed before they take effect | All | Environment config | AML.M0027 |
| R7 | AI agents MUST NOT be able to merge to protected branches or deploy to production without human approval | All | Branch and environment policy | AML.M0029 |
| R8 | Content an agent reads (issues, web pages, files, tool output) MUST be treated as untrusted input that may contain instructions. Agents working on untrusted content MUST NOT have access to secrets, and their tool use MUST be restricted | All | Design review | AML.T0051.001, AML.M0030 |
| R18 | Agent actions MUST be attributable: an agent uses its own identity or a clearly marked delegated identity, and its actions are logged | T1–2 | Log review | AML.M0024 |

## When shadow AI is found

Unapproved AI use is usually someone trying to get work done. Treat each finding as a discovery item, not a disciplinary matter, unless data has been exposed.

1. **Find the owner** and what the tool is used for.
2. **Assess exposure:** what data and credentials it could reach, whether it can run commands, and where its data goes.
3. **If health, personal or operational data may have left NSW Health control**, report it to HSOC ([SECURITY.md](../../SECURITY.md)). Notification obligations under the PPIP Act may apply.
4. **Decide** one of: approve and register (R1, R11); move to an approved equivalent; or remove.
5. **Record** the decision in the AI register, and rotate any credentials the tool held.
6. **Feed the pattern back.** If many people use the same unapproved tool, the approved list is missing something.

How to find shadow AI is in [AI usage discovery](../01-discovery/ai-usage-discovery.md).

## Paved road

- Approved AI tools list, with the data classification each is cleared for.
- AI register for agents and automations, with owners.
- [Template repository](../../template-repo/README.md) with Copilot instructions, skills and the AI configuration check pre-wired.
- Organisation-managed Copilot settings: allowed models, MCP server policy, content exclusions.
- Reviewer guidance on what AI-generated code tends to get wrong: missing authorisation checks, outdated APIs, invented packages, over-broad permissions.
