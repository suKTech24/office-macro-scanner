# SDS-14 Vendor-developed and third-party software

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program + Procurement | PD2026_001 §2.9 · NSW CSP 1.10 (detailed 1.10.1–1.10.4) · ISM Guidelines for procurement and outsourcing · SSDF PO.1, PW.4 · CISA Secure by Design |

**Why:** much of the software NSW Health runs is written by suppliers. The organisation remains accountable for it.

Applies to software developed for NSW Health under contract, and to custom code and configuration that NSW Health or an integrator adds to commercial products.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Contracts for developed software MUST require the supplier to follow a documented secure development lifecycle aligned to a recognised framework (NIST SSDF, ISM, Microsoft SDL or equivalent) | All | Contract clause |
| R2 | Suppliers developing in NSW Health repositories and pipelines MUST follow these standards in full | All | Same as internal |
| R3 | Suppliers developing in their own environment MUST provide evidence per release: security testing summary, SBOM, and a statement of known unresolved vulnerabilities | T1–2 | Release evidence |
| R4 | Contracts MUST require notification of vulnerabilities and security incidents affecting NSW Health within a defined period, and remediation within [SDS-11](SDS-11-vulnerability-management.md) timeframes | All | Contract clause |
| R5 | NSW Health MUST retain the right to security test delivered software and to receive or escrow source code for Tier 1 systems | T1 | Contract clause |
| R6 | Supplier access to NSW Health environments MUST use individually attributable identities with MFA, least privilege and time-bound access | All | Access review |
| R7 | Supplier use of NSW Health data for development and test MUST comply with [SDS-12](SDS-12-health-data-and-privacy.md) | All | Contract, audit |
| R8 | Supplier use of AI tools on NSW Health code and data MUST be disclosed and comply with [SDS-13](SDS-13-ai-assisted-development.md) | All | Supplier statement |
| R9 | Custom extensions to commercial products (scripts, plug-ins, reports, integrations) are in-house code and MUST meet the standards for their archetype | All | Inventory |
| R10 | At contract end, the supplier MUST return or destroy code, data and credentials, and access MUST be removed | All | Exit checklist |

## Supplier assurance is not local assurance

A supplier can assure its product. Only the deploying organisation can assure how the product is configured, integrated and used locally. This is the split NHS England makes between its manufacturer standard (DCB0129) and its deployment standard (DCB0160).

| Ask the supplier for | Verify locally |
|---|---|
| Product architecture, development assurance, patch process and support dates | Deployed architecture, that the running version is supported, and that it can be updated |
| SBOM or component evidence, vulnerability disclosure, remediation and incident notification terms | A named notification recipient, issue tracking, and a rehearsal of the response |
| Identity, logging, backup and recovery responsibilities | Tenant roles, local access review, audit log routing, fallback and recovery tests |
| Release notices and artefact integrity evidence, or the change controls of a managed service | Integration regression testing, local approval and downtime communication |
| Data return, export, deletion and exit provisions | Exit runbook, migration owner and records retention |

For changes affecting care, confirm the local clinical safety pathway even when the product already carries supplier assurance. Where the vendor cannot roll back, the product owner confirms an alternative workflow. Use the [eHealth NSW Supplier Hub](https://www.ehealth.nsw.gov.au/supplier-hub) and approved commercial channels for supplier requests.

## Proportionality

For a small local purchase, a one-page supplier questionnaire and R4, R6, R7 may be sufficient. For a statewide clinical platform, all requirements apply with evidence.

## Paved road

- Model contract clauses agreed with procurement and legal.
- [Supplier security questionnaire](../05-templates/supplier-security-questionnaire.md).
- An evidence checklist for accepting a release.
