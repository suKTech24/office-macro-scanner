# SDS-15 Scripts and automation

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program | NSW CSP 3.6, 3.7, 3.11 · Essential Eight (application control, restrict admin privileges) · SSDF PS.1, PW.5 |

**Why:** a script pushed through an endpoint-management or automation platform can run with the highest privilege on every device or server in the organisation. It deserves at least the care given to an application, and usually gets far less.

Applies to PowerShell, shell, batch, Python and similar scripts; scheduled tasks; runbooks; endpoint remediation and detection scripts; application packaging; logon scripts.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Scripts MUST be stored in source control and reviewed before deployment ([SDS-01](SDS-01-source-control-and-repository-security.md)). The copy in the deployment tool MUST come from the repository, not be edited in place | All | Repo vs platform comparison |
| R2 | Scripts MUST NOT contain credentials. Use the platform's managed identity, a vault, or credential-less design ([SDS-02](SDS-02-secrets-management.md)) | All | Secret scanning |
| R3 | Scripts deployed to endpoints or servers MUST be signed with the organisation's code-signing certificate where the platform supports enforcement | T1–2 | Signature check |
| R4 | Scripts MUST run with the least privilege that works. Running as SYSTEM/root MUST be a recorded decision | All | Review |
| R5 | Scripts MUST NOT download and execute content from the internet at run time. Dependencies are packaged or come from approved internal sources, with hash or signature verified | All | Code review |
| R6 | Scripts MUST NOT build commands from untrusted input using dynamic evaluation (for example `Invoke-Expression`, `eval`) | All | Linter |
| R7 | Scripts MUST NOT weaken security controls (disabling endpoint protection, certificate validation, execution policy, firewall) except as an approved, documented change | All | Linter, review |
| R8 | Broad deployments MUST be staged through rings (test → pilot → broad) with a defined rollback | T1–2 | Deployment record |
| R9 | Publishing a script or package to a broad device or server scope MUST require a second approver in the deployment platform | T1 | Platform RBAC |
| R10 | Scripts MUST handle errors explicitly, log what they did centrally, and clean up temporary files, especially any containing sensitive data | T1–2 | Review |
| R11 | Scripts MUST pass the language's static analyser (for example PSScriptAnalyzer, ShellCheck) | All | Pipeline |
| R12 | Each script MUST have a header stating purpose, owner, context it runs in, and risk tier | All | Linter |

## Paved road

- [PowerShell guide](../03-guides/powershell.md) and a script repository template with analyser, signing and release pipeline.
- Central signing service.
- [Lightweight threat model for automation](../05-templates/threat-model-template.md#lightweight-version-for-scripts-and-automation).
