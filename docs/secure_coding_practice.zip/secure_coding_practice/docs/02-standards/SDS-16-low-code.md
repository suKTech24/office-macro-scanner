# SDS-16 Low-code and citizen development

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program + Low-code Platform Owner | NSW CSP 1.6, 3.2, 3.12 · OWASP Low-Code/No-Code Top 10 |

**Why:** low-code platforms let anyone connect data sources and automate actions. That is their value and their risk: apps holding health information can be created and shared without any of the controls in the other standards.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | Apps and flows MUST be built only in approved, governed environments. The default/personal environment MUST NOT hold health or sensitive information | All | Platform admin report |
| R2 | Data loss prevention policies MUST restrict which connectors can be combined, separating business data from non-approved services | All | Platform policy |
| R3 | Every app and flow MUST have a named owner and a second owner, a stated purpose and a risk tier. Orphaned assets are reassigned or removed | All | Inventory |
| R4 | Apps and flows MUST run with the invoking user's permissions or a least-privilege service identity, not the maker's personal credentials | All | Review |
| R5 | Sharing MUST be to named groups. Sharing with "everyone" or externally requires approval | All | Platform report |
| R6 | Tier 1–2 apps MUST use separate development, test and production environments, with solutions promoted through a managed deployment process and kept in source control | T1–2 | Platform config |
| R7 | Tier 1–2 apps MUST be reviewed by the platform team or a champion before production | T1–2 | Review record |
| R8 | Custom connectors, embedded code and expressions that build queries MUST follow [SDS-04](SDS-04-secure-coding.md) | All | Review |
| R9 | [SDS-12](SDS-12-health-data-and-privacy.md) applies in full: no health information in test, minimise data, approved storage only | All | Review |
| R10 | Makers MUST complete low-code security awareness before building anything beyond personal productivity | All | Training record |

## Paved road

- Environment strategy and DLP policies set by the platform owner.
- Maker onboarding with a short [low-code guide](../03-guides/power-platform.md).
- Automated inventory with owner attestation twice a year.
