# SDS-17 AI-enabled systems

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft | Secure Development Program + AI security program | PD2026_001 §4.4 · Digital NSW AI Assessment Framework · MITRE ATLAS 2026.10 · OWASP Top 10 for LLM Applications · NIST AI RMF · SSDF PW |

**Why:** a system that uses an AI model has the usual software risks plus new ones. Its behaviour depends on instructions mixed with data, so anyone who can put text in front of the model can try to steer it. Its components (models, datasets, prompts, agent tools) form a supply chain of their own. When it can act through tools, a manipulated model becomes a manipulated user with that user's access. Most of these risks are cheapest to remove at the whiteboard, before anything is built.

**Scope:** any system NSW Health builds, configures or commissions that calls an AI model or runs an AI agent, for example:

- chat assistants
- document question-answering over retrieved content (RAG)
- summarisation of clinical or corporate records
- classification and prediction models
- agents with tools
- AI features configured in low-code platforms and commercial products

The tools engineers use to build software are [SDS-13](SDS-13-ai-assisted-development.md).

MITRE ATLAS identifiers show the attack or mitigation each requirement relates to; the [ATLAS guide](../03-guides/ai-security-with-atlas.md) explains how to use them.

## Risk tier

An AI-enabled system is at least **Tier 2**. It is **Tier 1** if any of these is true: its output may inform a clinical decision; it processes identifiable health information; or it has an agent that can change data or take actions in other systems.

## Concept and design

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R1 | The use case MUST be assessed under the Digital NSW AI Assessment Framework (required by PD2026_001 §4.4) at concept stage, before build, and the outcome recorded **[VERIFY current NSW Health process]** | All | Design record | |
| R2 | The threat model MUST include the AI section of the [threat model template](../05-templates/threat-model-template.md#ai-components), using ATLAS, at concept stage and on every significant change | All | Threat model | |
| R3 | If output could inform a clinical decision, clinical safety MUST be engaged, and the system referred for assessment as possible software as a medical device ([SDS-12](SDS-12-health-data-and-privacy.md) R10) | T1 | Design record | AML.T0048.003 |
| R4 | The design MUST state which actions need a human decision before they take effect, and the system MUST enforce it | All | Design review, testing | AML.M0029 |

## Models, data and tools as a supply chain

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R5 | An AI bill of materials MUST be maintained per release: models and versions, providers, datasets, embedding models, vector stores, system instructions and prompt templates, agent tools and MCP servers, and inference runtimes | All | Release evidence | AML.M0023 |
| R6 | Models, datasets and agent tools MUST come from approved sources and be verified before loading. Model files in formats that execute code on load (pickle based) MUST NOT be loaded from untrusted sources; prefer safetensors or ONNX | All | AI configuration check, review | AML.T0010.003, AML.T0011.000, AML.M0014 |
| R7 | Training, fine-tuning and retrieval data MUST have recorded provenance, and MUST be protected so that untrusted parties cannot add or change content that the model will learn from or retrieve | All | Design review | AML.T0020, AML.T0070, AML.M0025 |

## Prompts, context and tools

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R8 | Everything placed in the model's context from outside the system MUST be treated as untrusted, including retrieved documents, emails, web pages, files and tool results. Security MUST NOT depend on the model obeying its instructions | All | Design review, testing | AML.T0051.001, AML.T0066 |
| R9 | System instructions MUST NOT contain secrets, and MUST NOT be the only place an access rule is enforced. Assume they can be extracted | All | Code review | AML.T0069.002, AML.T0085.003 |
| R10 | Authorisation MUST be enforced outside the model, with the end user's permissions. Retrieval returns only content the user may see; tools act only with the access the user or task is entitled to | All | Testing | AML.M0027, AML.M0028 |
| R11 | Agent tools MUST be an explicit allow-list with least privilege. Agents MUST NOT be able to grant themselves extra access at run time. Tool use MUST be restricted while the agent is processing untrusted content | All | Design review | AML.T0053, AML.M0030, AML.M0037 |
| R12 | Model output MUST be treated as untrusted: encoded before display, validated before use, and never executed or placed into SQL, shell, file paths or code evaluation without validation. Tool-call arguments MUST be validated against a schema | All | SAST, testing | AML.T0077, AML.M0033 |
| R13 | Requests MUST be limited by rate, size, cost and time, and agents MUST have step limits, so the system cannot be run up or run away | All | Configuration | AML.T0034, AML.T0029, AML.M0004 |

## Data protection

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R14 | Health and personal information MUST be sent only to models and services approved for it, with data location and the provider's use of NSW Health data (including for training) settled in the contract ([SDS-14](SDS-14-vendor-and-third-party-software.md)) | All | Contract, design review | AML.T0085 |
| R15 | Prompts, responses and retrieved content that contain health information MUST be logged and retained only as the privacy office approves, and protected like the source data ([SDS-12](SDS-12-health-data-and-privacy.md)) | All | Configuration | |
| R16 | Outputs SHOULD be checked for disclosure of sensitive data the user is not entitled to, including data a model may have memorised | T1–2 | Testing | AML.T0137.003 |

## Verification and operation

| ID | Requirement | Tier | Verify | ATLAS |
|---|---|---|---|---|
| R17 | Before release, the system MUST be tested against prompt injection (direct and indirect), jailbreaks, data leakage and tool misuse, as well as for accuracy in its intended use. Tier 1 systems MUST also have an independent AI red team exercise | All / T1 | Test report | AML.T0051, AML.T0054, AML.M0035 |
| R18 | AI activity MUST be logged: model and version, prompts or their references, retrieved sources, tool calls and outcomes, with privacy controls. Abuse patterns MUST be visible to HSOC | T1–2 | SIEM onboarding | AML.M0024 |
| R19 | It MUST be possible to switch the AI feature or agent off quickly and fall back to a non-AI workflow | All | Runbook, exercise | |
| R20 | A change of model, provider, system instructions, tools or retrieval sources is a significant change: re-test, and update the AI bill of materials and the threat model | All | Change record | AML.T0109 |

## Paved road

- [AI security with ATLAS guide](../03-guides/ai-security-with-atlas.md): questions by lifecycle stage, starter technique sets, what can and cannot be automated.
- The [threat model template](../05-templates/threat-model-template.md#ai-components) AI section, and the Copilot threat-model skill in the template repository.
- [AI configuration check](../../template-repo/scripts/check_ai_config.py) for the automatable parts.
- Approved models and providers list, with the data classification each is cleared for.
- **[ASSUMPTION]** A central AI gateway, so that keys, logging, rate limits and content filtering are provided once instead of in every application.
