# Language and technology guides

Standards say **what**. Guides show **how** in a specific technology, with safe and unsafe examples.

> The list below is a starting assumption about what NSW Health teams use. **Discovery decides which guides are needed and in what order** ([tech stack inventory](../01-discovery/tech-stack-inventory.md)). Write a dedicated guide only for technologies used by several teams; the long tail follows [SDS-04](../02-standards/SDS-04-secure-coding.md) and the OWASP Cheat Sheet Series.

| Guide | Typical users | Status |
|---|---|---|
| [PowerShell](powershell.md) | Endpoint, digital workspace, infrastructure, automation | Draft |
| [.NET / C#](dotnet.md) | Application and API teams | Draft |
| [Python](python.md) | Data, analytics, automation, APIs | Draft |
| [JavaScript / TypeScript](javascript-typescript.md) | Web front ends, Node.js services | Draft |
| [SQL and databases](sql.md) | Everyone who queries data | Draft |
| [Infrastructure as code](infrastructure-as-code.md) | Platform, cloud | Draft |
| [Power Platform / low-code](power-platform.md) | Makers, low-code teams | Draft |
| [AI security with MITRE ATLAS](ai-security-with-atlas.md) | Everyone who builds with or uses AI; architects at design review | Draft |
| [Repository setup and GitHub Copilot](repository-setup.md) | Everyone starting or onboarding a repository | Draft |
| Java / Kotlin | Application teams | To write if discovery finds significant use |
| Integration (HL7 v2, FHIR, integration engines) | Integration teams | To write with integration champions |
| Containers and Kubernetes | Platform, application teams | To write if discovery finds significant use |
| Mobile (iOS / Android) | Application teams | To write if discovery finds significant use |

## Guide structure

Every guide follows the same headings so engineers can find things:

1. Tooling to switch on (linter, analyser, dependency scanner)
2. Secrets
3. Input, queries and commands
4. Authentication and authorisation
5. Dependencies
6. Logging and errors
7. Things that are banned or need justification
8. Review checklist

Examples use synthetic data and `example.health.nsw.gov.au` only.
