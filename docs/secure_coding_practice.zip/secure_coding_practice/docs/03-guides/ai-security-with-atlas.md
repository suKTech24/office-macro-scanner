# AI security with MITRE ATLAS

For developers, DevSecOps engineers, architects and anyone reviewing a design that involves AI. Implements [SDS-13](../02-standards/SDS-13-ai-assisted-development.md) and [SDS-17](../02-standards/SDS-17-ai-enabled-systems.md).

Technique and mitigation identifiers were checked against ATLAS release **2026.10** (October 2026). ATLAS now releases monthly and adds techniques often, especially for agents, so check [atlas.mitre.org](https://atlas.mitre.org/) when you threat-model.

## 1. What ATLAS is, and what it is not

MITRE ATLAS (Adversarial Threat Landscape for AI Systems) is a knowledge base of how attackers target AI systems. It follows the style of MITRE ATT&CK: tactics (the attacker's goal at each step), techniques (how they achieve it), mitigations, and real case studies. Release 2026.10 has 16 tactics, over 200 techniques and sub-techniques, and 44 mitigations.

| Use ATLAS to | Do not expect ATLAS to |
|---|---|
| Ask "what could an attacker do here?" during design and architecture review | Scan code. It is a catalogue, not a tool |
| Structure the AI part of a threat model | Tell you which risks apply. You choose the techniques relevant to your design |
| Plan AI red-team tests | Replace the NSW AI Assessment Framework, privacy or clinical safety review |
| Give security operations a shared language for detections and incidents | Cover non-adversarial failure such as model bias or drift |

## 2. Two kinds of AI risk for engineers

| | AI in **how we build** | AI in **what we build** |
|---|---|---|
| Examples | Copilot and other coding assistants, command-line agents, local model runtimes, MCP servers, skills and prompt files | Chat assistants, document Q&A, summarisation, prediction models, agents with tools |
| What is at risk | The developer's machine, credentials, source code and pipelines | The system's users, its data, and anything its agents can touch |
| Standard | [SDS-13](../02-standards/SDS-13-ai-assisted-development.md) | [SDS-17](../02-standards/SDS-17-ai-enabled-systems.md) |

Most teams are in the first column already, whether or not they build AI products.

## 3. Shifting left: questions at each stage

### Concept and architecture review

Ask these before anything is built. Most AI security problems are design decisions.

| Question | Why | ATLAS |
|---|---|---|
| What decision or action does the AI output feed? Could it affect patient care? | Sets the tier, clinical safety and regulatory path | AML.T0048.003 User Harm |
| Has the use case gone through the NSW AI Assessment Framework? | Required by PD2026_001 §4.4 | |
| Which model and provider, where is data processed, and may the provider use the data? | Data location, privacy and contract | AML.T0085 Data from AI Services |
| What text reaches the model that NSW Health did not write: documents, emails, web pages, patient-entered text, tool results? | Every one is a prompt injection path | AML.T0051.001 Indirect prompt injection |
| Can the system act (write data, send messages, call APIs, run code)? With whose permissions? | A manipulated model acts with those permissions | AML.T0053 AI Agent Tool Invocation, AML.T0086 Exfiltration via AI Agent Tool Invocation |
| Which actions are irreversible or consequential, and who approves them? | Human approval is the strongest control for agents | AML.M0029 Human In-the-Loop |
| Who can add or change the content it retrieves or learns from? | Poisoned content becomes trusted output | AML.T0070 RAG Poisoning, AML.T0020 Training Data Poisoning |
| How will we switch it off, and what is the fallback workflow? | Needed for incidents and clinical continuity | |

### Design

| Do | ATLAS |
|---|---|
| Enforce authorisation in the application and retrieval layer with the end user's permissions; never ask the model to enforce it | AML.M0027, AML.M0028 |
| Give agents an explicit, minimal tool list; no self-granted access at run time | AML.M0037 |
| Restrict tools while the agent is processing untrusted content (for example read-only, or approval required) | AML.M0030 |
| Keep secrets and the only copy of access rules out of system instructions; assume they leak | AML.T0069.002 System Prompt |
| Treat output as untrusted: encode for display, validate before use, schema-check tool arguments | AML.T0077 LLM Response Rendering, AML.M0033 |
| Separate components so a compromised agent cannot reach everything | AML.M0032 |
| Set rate, size, cost, time and step limits | AML.T0034 Cost Harvesting, AML.M0004 |

### Build

| Do | ATLAS |
|---|---|
| Use only approved models, providers and AI tools ([SDS-13](../02-standards/SDS-13-ai-assisted-development.md) R1) | AML.T0112.000 Local AI Agent |
| Load models only from verified sources, and avoid pickle-based formats from outside | AML.T0011.000 Unsafe AI Artifacts, AML.M0014 |
| Pin and review MCP servers, skills and agent tools like any dependency | AML.T0010.005, AML.T0110 AI Agent Tool Poisoning |
| Check every package an assistant suggests actually exists and is the intended one | AML.T0060 Publish Hallucinated Entities |
| Keep keys in the vault, never in code, notebooks or MCP configuration | AML.T0055 Unsecured Credentials, AML.T0083 |
| Record the AI bill of materials | AML.M0023 |

### Continuous integration (on every pull request)

See [section 4](#4-what-can-be-checked-automatically).

### Before release

- Test direct and indirect prompt injection with content placed where the system really reads it (a document in the index, an email in the mailbox), not only typed into the chat.
- Test jailbreaks (AML.T0054), data leakage across users, and tool misuse.
- Test accuracy and failure behaviour for the intended use, with clinical input where relevant.
- Tier 1: an independent AI red team exercise (AML.M0035), planned from the ATLAS techniques in the threat model.

Open-source tools exist for automated adversarial testing (for example garak, PyRIT and promptfoo), and for scanning model files (for example ModelScan). These are examples only; assess any tool under [SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md) before use.

### Operate

- Log model and version, prompts or their references, retrieved sources and tool calls, with privacy controls (AML.M0024), and agree with HSOC which patterns raise an alert.
- Treat a change of model, provider, instructions, tools or retrieval sources as a significant change (AML.T0109 AI Supply Chain Rug Pull).
- Keep the off switch tested.

## 4. What can be checked automatically

This is the honest answer to "can we scan code for AI security risks?" Some risks can be scanned for. Most AI-specific risks are design decisions that no scanner can see.

| Risk | Automatable? | How |
|---|---|---|
| AI provider keys committed to code | **Yes** | Secret scanning with push protection; most providers' key formats are recognised |
| Credentials in MCP configuration | **Yes** | [check_ai_config.py](../../template-repo/scripts/check_ai_config.py) |
| Hidden instructions in agent instruction files, skills and prompts | **Yes** | check_ai_config.py fails on invisible and direction-changing Unicode |
| Which AI SDKs, endpoints and model files a repository uses (shadow AI in code) | **Yes, as an inventory** | check_ai_config.py lists them so they can be matched to the AI register |
| Unsafe model files (pickle) | **Partly** | check_ai_config.py flags the formats; model scanners inspect contents |
| Known-vulnerable AI libraries | **Yes** | Ordinary dependency scanning ([SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md)) |
| Model output passed to `eval`, SQL or a shell | **Partly** | Static analysis catches some data flows; review catches the rest |
| Prompt injection exposure, excessive agency, missing authorisation in retrieval | **No** | Threat modelling, design review, code review, adversarial testing |
| Poisoned retrieval or training data | **No** | Design controls on who can write the data; provenance |
| Whether the system is safe for its clinical use | **No** | Clinical safety and evaluation |

So the pipeline answers "is anything obviously wrong, and what AI is in here?" The threat model and the pre-release tests answer "is this design safe?". Both are needed.

## 5. Using ATLAS in a threat model

1. Draw the data flow, marking every place untrusted text enters and every tool the system can call.
2. For each component, start from the matching starter set below and add techniques from [atlas.mitre.org](https://atlas.mitre.org/) that fit your design.
3. For each technique, record whether the design already prevents it, and if not, which control or ATLAS mitigation you will add.
4. Record the result in the [AI section of the threat model](../05-templates/threat-model-template.md#ai-components).

### Starter technique sets (ATLAS 2026.10)

| Component | Start with |
|---|---|
| **Chat assistant or LLM feature** | AML.T0051 LLM Prompt Injection (direct, indirect), AML.T0054 LLM Jailbreak, AML.T0069.002 System Prompt, AML.T0077 LLM Response Rendering, AML.T0034 Cost Harvesting, AML.T0029 Denial of AI Service |
| **Retrieval over documents (RAG)** | AML.T0070 RAG Poisoning, AML.T0066 Retrieval Content Crafting, AML.T0071 False RAG Entry Injection, AML.T0085.000 Data from AI Services: RAG Databases, AML.T0082 RAG Credential Harvesting |
| **Agent with tools** | AML.T0053 AI Agent Tool Invocation, AML.T0086 Exfiltration via AI Agent Tool Invocation, AML.T0101 Data Destruction via AI Agent Tool Invocation, AML.T0080 AI Agent Context Poisoning (memory, thread), AML.T0110 AI Agent Tool Poisoning, AML.T0098 AI Agent Tool Credential Harvesting |
| **Model files and training** | AML.T0010.003 Supply Chain Compromise: Model Repository, AML.T0011.000 Unsafe AI Artifacts, AML.T0018 Manipulate AI Model, AML.T0020 Training Data Poisoning, AML.T0137 Training Data Information from AI Models |
| **Developer machine and repository (coding agents)** | AML.T0112.000 Local AI Agent, AML.T0081 Modify AI Agent Configuration, AML.T0083 Credentials from AI Agent Configuration, AML.T0010.005 Supply Chain Compromise: AI Agent Tool, AML.T0109 AI Supply Chain Rug Pull, AML.T0060 Publish Hallucinated Entities, AML.T0132 Misconfigured or Publicly Exposed AI Services |
| **Low-code or product-embedded agent** | AML.T0051.001 Indirect prompt injection, AML.T0053, AML.T0086, AML.T0132, plus the platform's sharing and connector settings ([SDS-16](../02-standards/SDS-16-low-code.md)) |

### Mitigations most teams will use

AML.M0023 Maintain an AI Bill of Materials · AML.M0014 Verify AI Artifacts · AML.M0027 Manage User-Delegated AI Agent Access · AML.M0028 Enforce Access Controls for AI Agent Tools · AML.M0029 Human In-the-Loop for AI Agent Actions · AML.M0030 Restrict AI Agent Tool Invocation on Untrusted Data · AML.M0033 Input and Output Validation for AI Agent Components · AML.M0037 AI Agent Authority Expansion Controls · AML.M0024 AI Telemetry Logging and Monitoring · AML.M0035 AI Red Team

## 6. Related references

- [MITRE ATLAS](https://atlas.mitre.org/) and its [data repository](https://github.com/mitre-atlas/atlas-data)
- OWASP Top 10 for LLM Applications and the OWASP GenAI Security Project's agentic guidance: a shorter list of the most common risks, useful alongside ATLAS
- NIST AI Risk Management Framework and its Generative AI Profile (NIST AI 600-1)
- NSW Health: PD2026_001 §4.4, IB2024_059, and the Digital NSW AI Assessment Framework
