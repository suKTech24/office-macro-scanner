# .NET / C# secure coding guide

Implements [SDS-04](../02-standards/SDS-04-secure-coding.md), [SDS-02](../02-standards/SDS-02-secrets-management.md) and [SDS-09](../02-standards/SDS-09-authentication-authorisation-cryptography.md) for .NET.

## 1. Tooling to switch on

- Use a supported .NET version (current LTS). .NET Framework applications need a migration plan or an exception.
- In the project file: `<Nullable>enable</Nullable>`, `<TreatWarningsAsErrors>true</TreatWarningsAsErrors>`, `<AnalysisLevel>latest-recommended</AnalysisLevel>`, and enable NuGet auditing (`<NuGetAudit>true</NuGetAudit>`, `<NuGetAuditMode>all</NuGetAuditMode>`).
- Commit `packages.lock.json` (`<RestorePackagesWithLockFile>true</RestorePackagesWithLockFile>`).
- SAST in the pipeline (see [pipelines](../../pipelines/README.md)).

## 2. Secrets

- Never in `appsettings.json`, `web.config` or source. Local development: `dotnet user-secrets`. Deployed: a vault configuration provider with managed identity.

```csharp
builder.Configuration.AddAzureKeyVault(
    new Uri("https://kv-example-prod.vault.azure.net/"),
    new DefaultAzureCredential());
```

- Prefer identity-based connections (no password in the connection string).

## 3. Data access

Unsafe:

```csharp
var sql = "SELECT * FROM Patients WHERE Mrn = '" + mrn + "'";
```

Safe:

```csharp
// EF Core LINQ is parameterised
var patient = await db.Patients.SingleOrDefaultAsync(p => p.Mrn == mrn);

// Raw SQL: interpolated form is parameterised; FromSqlRaw with concatenation is not
var rows = await db.Patients.FromSqlInterpolated($"SELECT * FROM Patients WHERE Mrn = {mrn}").ToListAsync();
```

## 4. Input, output and web

- Use model binding with validation attributes or FluentValidation; reject on `!ModelState.IsValid` (automatic with `[ApiController]`).
- Bind to dedicated request models, not entities, to prevent over-posting.
- Razor encodes by default. Do not use `Html.Raw` on untrusted data.
- Keep antiforgery validation on for cookie-authenticated form posts.
- Enforce HTTPS and HSTS; set security headers (Content-Security-Policy, `X-Content-Type-Options`).
- Configure CORS with explicit origins. Never `AllowAnyOrigin` with credentials.
- For file paths from input, use `Path.GetFullPath` and verify the result starts with the intended base directory.

## 5. Authentication and authorisation

- Authenticate with the organisation's identity provider through `Microsoft.Identity.Web` / OpenID Connect. Do not implement password storage for staff.
- Require authorisation by default and opt out explicitly:

```csharp
builder.Services.AddAuthorizationBuilder()
    .SetFallbackPolicy(new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());
```

- Check access to the specific record, not just the role (resource-based authorisation with `IAuthorizationService`).

## 6. Dangerous APIs

| Avoid | Use |
|---|---|
| `BinaryFormatter`, `NetDataContractSerializer`, `LosFormatter` | `System.Text.Json` |
| Newtonsoft `TypeNameHandling` other than `None` | Default settings |
| `MD5`, `SHA1`, `DES`, custom crypto | Platform crypto with approved algorithms; ASP.NET Core Data Protection |
| `System.Random` for tokens | `RandomNumberGenerator` |
| `XmlDocument` / `XmlTextReader` with DTD processing | `XmlReaderSettings { DtdProcessing = Prohibit }` |
| `Process.Start` with concatenated arguments | `ProcessStartInfo.ArgumentList` |
| Disabling certificate validation in `HttpClientHandler` | Fix the certificate trust |

## 7. Logging and errors

- Use `ILogger` with structured templates (`logger.LogInformation("User {UserId} viewed record {RecordId}", ...)`), never string concatenation.
- No health information or secrets in logs. Use the developer exception page only in Development.
- Return problem details without stack traces.

## Review checklist

- [ ] No secrets in configuration files
- [ ] No concatenated SQL or `FromSqlRaw` with input
- [ ] Every endpoint has an authorisation decision; record-level checks present
- [ ] Request models validated; no entity binding
- [ ] No banned APIs
- [ ] NuGet audit clean; lock file committed
