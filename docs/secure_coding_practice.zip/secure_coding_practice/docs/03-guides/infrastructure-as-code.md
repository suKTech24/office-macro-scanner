# Infrastructure as code guide

Implements [SDS-08](../02-standards/SDS-08-infrastructure-as-code-and-cloud.md) and [SDS-07](../02-standards/SDS-07-build-and-deployment-pipelines.md). Examples use Terraform and Bicep; the principles apply to any IaC tool.

## 1. Tooling to switch on

- Formatter and validator (`terraform fmt` / `validate`, `bicep build` / linter) in the pipeline.
- An IaC misconfiguration scanner (for example Checkov or Trivy config) on every pull request.
- Plan on pull request, apply only from the protected branch through an environment with approval.
- Drift detection on a schedule for Tier 1–2.

## 2. State and secrets

- Terraform state contains secrets in plain text. Store it in a remote backend with encryption, access control and locking. Never commit `*.tfstate` or `*.tfvars` containing secrets.
- Do not pass secrets as plain variables or outputs. Reference the vault, mark values sensitive (`sensitive = true`, `@secure()`), and prefer managed identities so there is no secret.
- Pipelines authenticate with workload identity federation, not stored client secrets.

## 3. Secure defaults to encode

| Area | Default |
|---|---|
| Network exposure | No public access; private endpoints; explicit allow-lists where public is required |
| Storage | Public/anonymous access disabled; minimum TLS version set; shared-key access disabled where identity auth is available |
| Databases | Identity-based authentication; public network access off; auditing on |
| Compute | No public IP on VMs; managed identity; disk encryption; no open management ports |
| Identity | Role assignments scoped to the resource, not subscription; no wildcard actions; no owner for workloads |
| Logging | Diagnostic settings to the central workspace on every resource |
| Tags | Owner, system, risk tier, data classification, environment |

Example (Bicep):

```bicep
resource sa 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: name
  location: location
  sku: { name: 'Standard_ZRS' }
  kind: 'StorageV2'
  properties: {
    allowBlobPublicAccess: false
    allowSharedKeyAccess: false
    minimumTlsVersion: 'TLS1_2'
    publicNetworkAccess: 'Disabled'
    supportsHttpsTrafficOnly: true
  }
}
```

## 4. Modules and providers

- Use the organisation's approved modules; they carry the defaults above.
- Pin provider and module versions; commit `.terraform.lock.hcl`.
- Third-party modules are dependencies: assess before use ([SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md) R4).

## 5. Containers

- Approved base images, pinned by digest for Tier 1.
- Run as non-root, read-only root filesystem where possible, drop capabilities.
- No secrets in images or build arguments.
- Scan images in the pipeline and in the registry; rebuild at least monthly.

## 6. Environments

- Separate subscriptions/accounts or at least separate identities and networks for production and non-production.
- The same code deploys every environment; differences are parameters.
- Manual portal changes in production are break-glass only and are reconciled back into code.

## Review checklist

- [ ] No secrets in code, variables files or outputs; state is remote and protected
- [ ] Nothing public that is not justified in the threat model
- [ ] Least-privilege role assignments
- [ ] Logging enabled; tags present
- [ ] Versions pinned; scanner clean or findings triaged
