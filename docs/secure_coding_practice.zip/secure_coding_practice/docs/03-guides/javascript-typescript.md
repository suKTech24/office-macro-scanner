# JavaScript / TypeScript secure coding guide

Implements [SDS-04](../02-standards/SDS-04-secure-coding.md) for browser front ends and Node.js services.

## 1. Tooling to switch on

- TypeScript with `"strict": true` for new work.
- ESLint with `typescript-eslint` and a security plugin (for example `eslint-plugin-security`); for React, the hooks and JSX rules.
- Commit the lock file. Install in CI with `npm ci` (never `npm install`).
- `npm audit` / the platform's dependency scanner on every change.
- A supported Node.js LTS.

## 2. Dependencies

The npm ecosystem is the most frequent target of supply-chain attacks.

- Use the internal registry proxy.
- Disable install scripts by default (`ignore-scripts=true` in `.npmrc`) and allow them per package only where needed.
- Check a new package's name, maintainers, age and download history before adding it. Prefer the standard library or an existing dependency.
- Delay adoption of brand-new versions (a cooldown of several days) unless they fix a vulnerability.

## 3. Secrets

- Nothing secret can live in front-end code. Anything bundled for the browser is public, including variables prefixed for client exposure (`VITE_`, `NEXT_PUBLIC_`, `REACT_APP_`).
- Server side: read from the vault or environment injected at run time; never commit `.env`.

## 4. Cross-site scripting

- Let the framework escape. Avoid `innerHTML`, `outerHTML`, `document.write`, React `dangerouslySetInnerHTML`, Angular `bypassSecurityTrust*`, Vue `v-html`.
- If HTML must be rendered, sanitise with DOMPurify first.
- Validate URLs before putting them in `href`/`src` (allow `https:` only; block `javascript:`).
- Deploy a Content Security Policy without `unsafe-inline` for scripts.

## 5. Server side (Node.js)

Unsafe:

```ts
db.query(`SELECT * FROM patients WHERE mrn = '${req.query.mrn}'`);
exec(`convert ${req.body.file} out.png`);
```

Safe:

```ts
db.query("SELECT * FROM patients WHERE mrn = $1", [mrn]);
execFile("convert", [validatedPath, "out.png"]);
```

- Validate every request body, query and parameter with a schema (for example Zod) at the boundary.
- Do not use `eval`, `new Function`, or `vm` on untrusted input.
- Guard against prototype pollution: do not deep-merge untrusted objects into configuration.
- Restrict outbound requests to allow-listed hosts when the URL comes from input.
- Set security headers (for example with `helmet`), explicit CORS origins, and rate limiting on authentication endpoints.

## 6. Authentication and sessions

- Use the organisation's identity provider via a maintained OpenID Connect library (authorisation code flow with PKCE).
- Keep tokens out of `localStorage` where a backend-for-frontend with `HttpOnly`, `Secure`, `SameSite` cookies is possible.
- Verify JWT signature, issuer, audience and expiry with a library; pin accepted algorithms.
- The browser is not a security boundary: enforce every authorisation decision on the server.

## 7. Logging and errors

Structured logging (for example `pino`). No tokens, secrets or health information. Generic error messages to clients.

## Review checklist

- [ ] No secrets in client bundles or the repository
- [ ] No raw HTML injection without sanitising
- [ ] Parameterised queries; no shell strings
- [ ] Input validated by schema on the server
- [ ] Authorisation enforced server-side
- [ ] Lock file committed; `npm ci`; audit clean; install scripts controlled
