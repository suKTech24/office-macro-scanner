# Power Platform / low-code guide

Implements [SDS-16](../02-standards/SDS-16-low-code.md). Written for makers and for the platform team. **[ASSUMPTION]** Power Platform is the main low-code platform; adapt if discovery finds others.

## For makers

### Before you build

- Is it only for you, with no patient or sensitive data? Build in your personal productivity space.
- Will other people use it, or does it touch patient, staff or sensitive data? Request a governed environment and tell the platform team what data it will use.
- Could it influence clinical decisions? Stop and ask; it may need clinical safety and regulatory review.

### While you build

- **Connections:** use connections that run as the signed-in user where possible. If the app uses your own account behind the scenes, everyone using it acts with your access.
- **Data:** store data in the approved data store for the environment, not in personal files or lists shared widely. Bring in only the columns you need.
- **Sharing:** share with a named group, not everyone. Give a colleague co-owner rights so the app survives your leave or departure.
- **Flows:** an HTTP-triggered flow is a public door unless you restrict it. Require authentication or restrict callers. Do not put keys or passwords in flow steps; use environment variables linked to the vault. Turn on secure inputs/outputs for steps handling sensitive values so they are not shown in run history.
- **Formulas and queries:** do not build filter or query text by joining user input; use the built-in filter functions with parameters.
- **Test data:** use made-up data when building and testing.

### Before go-live (Tier 1–2)

- Package as a solution, keep it in source control, and promote through test to production with the platform team's pipeline.
- Ask a champion or the platform team for a review.

## For the platform team

- **Environment strategy:** default environment locked down for personal productivity; separate governed dev/test/prod environments per business area; environment creation restricted.
- **Data loss prevention policies:** classify connectors as business, non-business or blocked; block custom and HTTP connectors by default and allow by exception.
- **Tenant isolation** and restrictions on external sharing.
- **Inventory:** use the platform's admin tooling to list apps, flows, makers and connectors; attest owners twice a year; quarantine orphaned assets.
- **Service identities:** service principals for production connections, least privilege, secrets in the vault.
- **Monitoring:** send platform audit logs to the SIEM.

## Review checklist

- [ ] Built in a governed environment appropriate to the data
- [ ] Two owners; purpose and tier recorded
- [ ] Connections do not use a maker's personal privileged account
- [ ] Shared with named groups only
- [ ] No secrets in steps; sensitive inputs/outputs secured
- [ ] HTTP triggers authenticated or restricted
- [ ] No real patient data in dev/test
