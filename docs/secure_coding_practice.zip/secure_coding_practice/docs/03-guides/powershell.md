# PowerShell secure coding guide

Implements [SDS-15](../02-standards/SDS-15-scripts-and-automation.md), [SDS-02](../02-standards/SDS-02-secrets-management.md) and [SDS-04](../02-standards/SDS-04-secure-coding.md) for PowerShell. Written for endpoint, digital workspace, infrastructure and automation teams.

## 1. Tooling to switch on

- **PSScriptAnalyzer** in the editor and in the pipeline. Fail the build on `Error` and on the security rules, including `PSAvoidUsingInvokeExpression`, `PSAvoidUsingPlainTextForPassword`, `PSAvoidUsingConvertToSecureStringWithPlainText`, `PSAvoidUsingUsernameAndPasswordParams`, `PSUsePSCredentialType`.
- **Pester** tests for anything reused or deployed broadly.
- `Set-StrictMode -Version Latest` and `$ErrorActionPreference = 'Stop'` at the top of every script.
- Secret scanning on the repository.

## 2. Secrets

Unsafe:

```powershell
$password = 'P@ssw0rd123'   # hard-coded
$cred = New-Object PSCredential('svc-deploy', (ConvertTo-SecureString $password -AsPlainText -Force))
```

Safe — no secret at all (managed identity), or retrieve at run time:

```powershell
# In Azure Automation / a managed host: no stored credential
Connect-AzAccount -Identity | Out-Null

# Or read from the approved vault at run time
$secret = Get-AzKeyVaultSecret -VaultName 'kv-example-prod' -Name 'api-key'
```

- Take credentials as `[PSCredential]` parameters, never as `[string]` passwords.
- Never write secrets with `Write-Host`, `Write-Verbose`, transcripts or logs.
- `ConvertFrom-SecureString` without a key protects only for the same user on the same machine; it is not a secrets store.

## 3. Input and commands

Unsafe — builds and evaluates a command from input:

```powershell
Invoke-Expression "Get-Service $ServiceName"
```

Safe — validate, then call the cmdlet with parameters:

```powershell
param(
    [Parameter(Mandatory)]
    [ValidatePattern('^[A-Za-z0-9_\-]{1,64}$')]
    [string]$ServiceName
)
Get-Service -Name $ServiceName
```

- Use `[ValidateSet()]`, `[ValidatePattern()]`, `[ValidateRange()]` on parameters.
- Avoid `Invoke-Expression`, `iex`, `Add-Type` with dynamic source, and `Start-Process cmd /c "<string built from input>"`. Use splatting to pass arguments.
- For SQL, use parameters (`Invoke-Sqlcmd -Variable` is string substitution, not parameterisation; prefer `System.Data.SqlClient` parameters or a module that supports them).
- Use `-LiteralPath` for file paths that come from input, and resolve and check paths stay within the intended folder.

## 4. Do not fetch and run

Unsafe:

```powershell
iwr https://example.com/install.ps1 | iex
```

Safe: package the dependency, or download from an approved internal source and verify before use:

```powershell
$expected = 'A1B2...'   # published hash
if ((Get-FileHash -Path $installer -Algorithm SHA256).Hash -ne $expected) { throw 'Hash mismatch' }
$sig = Get-AuthenticodeSignature -FilePath $installer
if ($sig.Status -ne 'Valid') { throw 'Invalid signature' }
```

Install modules from the approved internal repository, with pinned versions (`-RequiredVersion`).

## 5. Do not weaken the platform

These need an approved change, never a quiet line in a script:

- `Set-ExecutionPolicy Bypass/Unrestricted`, `-ExecutionPolicy Bypass` in deployment command lines beyond what the platform requires
- disabling certificate checks (`-SkipCertificateCheck`, custom `ServerCertificateValidationCallback`)
- `Set-MpPreference -DisableRealtimeMonitoring`, adding broad antivirus exclusions
- disabling firewall profiles, UAC, or logging

## 6. Privilege and scope

- State in the header what context the script runs in (SYSTEM, user, service account) and why.
- Do the minimum as SYSTEM. If part of the task needs user context, split the script.
- Files written by a SYSTEM script into user-writable locations can be hijacked; write to protected paths and set ACLs.
- For remoting, use Just Enough Administration (JEA) endpoints instead of full admin sessions where possible.

## 7. Signing and release

- Sign scripts through the central signing service in the pipeline (`Set-AuthenticodeSignature` with a certificate the team never holds directly).
- Release from the repository tag to the deployment platform; do not edit in the console.
- Stage through rings with a rollback step.

## 8. Logging and errors

```powershell
try {
    # work
}
catch {
    Write-Error "Remediation failed: $($_.Exception.Message)"
    exit 1
}
finally {
    Remove-Item -LiteralPath $tempFile -ErrorAction SilentlyContinue
}
```

Log start, target, outcome. Ensure script block logging and transcription policy do not capture secrets by never having secrets in the script text.

## 9. Header template

```powershell
<#
.SYNOPSIS   One line
.OWNER      Team name / contact
.CONTEXT    Runs as SYSTEM via <platform> on <scope>
.TIER       1 | 2 | 3
.REPO       <repository URL>
#>
#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
```

## Review checklist

- [ ] No credentials, tokens or keys in the script or its parameters' defaults
- [ ] No `Invoke-Expression` or command strings built from input
- [ ] Parameters validated
- [ ] Nothing downloaded and executed at run time; hashes or signatures verified
- [ ] No security control disabled
- [ ] Privilege and scope stated and minimal
- [ ] PSScriptAnalyzer clean; signed; staged rollout and rollback defined
