# Python secure coding guide

Implements [SDS-04](../02-standards/SDS-04-secure-coding.md) for Python: services, automation, data and analytics work.

## 1. Tooling to switch on

- A supported Python version. One virtual environment per project.
- **Ruff** with the `S` (flake8-bandit) rules, or **Bandit**, in the editor and pipeline.
- **pip-audit** (or the platform's dependency scanner) on every change.
- Pin dependencies with hashes: `pip-compile --generate-hashes`, or a lock file from `uv` / Poetry; install with `--require-hashes`.
- Install only from the approved package index.

## 2. Secrets

Unsafe:

```python
API_KEY = "sk-live-abc123"
```

Safe:

```python
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

client = SecretClient("https://kv-example-prod.vault.azure.net/", DefaultAzureCredential())
api_key = client.get_secret("api-key").value
```

Never commit `.env` files. In notebooks, never paste a credential into a cell; outputs and history are saved.

## 3. Queries and commands

Unsafe:

```python
cur.execute(f"SELECT * FROM patients WHERE mrn = '{mrn}'")
subprocess.run(f"ping {host}", shell=True)
```

Safe:

```python
cur.execute("SELECT * FROM patients WHERE mrn = ?", (mrn,))   # placeholder style depends on the driver
subprocess.run(["ping", "-n", "1", host], check=True)         # list form, no shell
```

Validate `host` and similar values against an allow-list pattern before use.

## 4. Dangerous functions

| Avoid on untrusted data | Use |
|---|---|
| `pickle`, `marshal`, `shelve`, `joblib.load` | JSON, or formats with a schema; load models only from trusted, verified sources |
| `yaml.load` | `yaml.safe_load` |
| `eval`, `exec` | Explicit parsing; `ast.literal_eval` for literals |
| `xml.etree` / `lxml` on untrusted XML | `defusedxml` |
| `random` for tokens | `secrets` |
| `hashlib.md5` / `sha1` for security | SHA-256 or better; `argon2-cffi` for passwords |
| `requests.get(..., verify=False)` | Fix the certificate trust |
| `tempfile.mktemp` | `tempfile.NamedTemporaryFile` / `mkstemp` |
| `tarfile.extractall` on untrusted archives | `extractall(filter="data")` |

Always set a `timeout` on HTTP requests.

## 5. Web services

- Validate request bodies with Pydantic models (FastAPI) or serializers (Django REST Framework).
- Django: keep CSRF and auto-escaping on; never `mark_safe` on untrusted data; use the ORM, not `.raw()` with string formatting. `DEBUG = False` in production.
- Flask/Jinja: do not use `render_template_string` with user input.
- Authenticate through the organisation's identity provider (OpenID Connect library); authorise per object.

## 6. Data and analytics

- Work on data in the approved platform. Do not export health information to a laptop ([SDS-12](../02-standards/SDS-12-health-data-and-privacy.md)).
- Clear notebook outputs before commit (`nbstripout` as a pre-commit hook); outputs can contain patient rows.
- Model files are code: loading an untrusted pickle-based model executes it. Prefer safe formats (for example `safetensors`, ONNX) and record model provenance.

## 7. Logging and errors

Use the `logging` module with parameters (`log.info("user %s viewed %s", user_id, record_id)`). No health information or secrets. Do not return tracebacks to clients.

## Review checklist

- [ ] No secrets in code, notebooks or `.env` in the repository
- [ ] No f-string SQL, no `shell=True` with input
- [ ] No unsafe deserialisation
- [ ] Dependencies pinned with hashes; audit clean
- [ ] Notebook outputs stripped; no data extracts committed
