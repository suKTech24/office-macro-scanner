# Repository setup and GitHub Copilot

How the secure development standards reach a team's repository, and how to use the GitHub Copilot files that come with it.

## Three layers

| Layer | What it is | What it holds | How it reaches a repository |
|---|---|---|---|
| **This handbook** | The source of truth | Standards, guides, discovery, governance | Linked, never copied |
| **Organisation `.github` repository** | GitHub's special repository for organisation defaults | `SECURITY.md` and other health files, pull request and issue templates, workflow templates, the organisation profile | Automatically, for every repository that does not have its own copy |
| **Template repository**, published from [template-repo/](../../template-repo/README.md) | The starting point for new repositories ("Use this template") | `README` with owner and risk tier, `CODEOWNERS`, `dependabot.yml`, `.gitignore`, Copilot instructions and skills, the AI configuration check | Copied once, when a repository is created |

The split exists because GitHub only shares some files from the `.github` repository. Copilot instructions, skills, `CODEOWNERS`, `dependabot.yml` and `.gitignore` are never inherited; each repository needs its own copy. Branch protection and required checks are applied with organisation rulesets, which are platform settings rather than files.

## Publish the template repository

1. Create a new repository in the organisation, for example `secure-repo-template`, and push the contents of [template-repo/](../../template-repo/README.md) to it.
2. In its settings, tick **Template repository**.
3. Protect its default branch, and make the program team its code owner.
4. Change the template here first, then copy it across, so that this handbook stays the source of truth. A change to a standard that affects a Copilot skill or instruction updates both in the same release.

Existing repositories are not updated automatically. Teams adopt the template files during [onboarding](../../teams/README.md), using the `repo-security-setup` skill.

## The Copilot files

| File in the template | When Copilot uses it |
|---|---|
| `.github/copilot-instructions.md` | Every chat and agent request in the repository |
| `.github/instructions/*.instructions.md` | Only for files matching the `applyTo` pattern in each file (PowerShell, Python, .NET, infrastructure and pipelines) |
| `.github/skills/<name>/SKILL.md` | When the task matches the skill's description, or when the developer asks for it |

The files are plain Markdown, so they work with whichever model the developer selects in Copilot. The always-on file is short on purpose: everything in it is sent with every request. Language detail lives in the path-specific files, and multi-step procedures live in skills.

| Skill | Use it for |
|---|---|
| `secure-code-review` | Reviewing a change against the standards, including AI-specific checks, before opening a pull request |
| `threat-model` | Producing or updating a threat model, with an AI section based on MITRE ATLAS and a short form for scripts |
| `repo-security-setup` | Bringing a repository up to the minimum baseline |

To confirm the files load, open Copilot Chat in VS Code and ask which instructions it is using.

### Limits

- **These files guide the assistant. They enforce nothing.** Pipeline checks and human review decide what merges ([SDS-13](../02-standards/SDS-13-ai-assisted-development.md) R3, R4).
- **Skills support depends on the VS Code and Copilot version.** Skills are newer than instruction files and may need a setting enabled. If they do not load, the two instruction layers still work. Check the current VS Code Copilot customisation documentation.
- **Other AI tools** mostly read a root `AGENTS.md`. Teams approved to use them can copy `copilot-instructions.md` to `AGENTS.md`; `CODEOWNERS` in the template already covers it.
- **Organisation-level Copilot instructions** can be set in GitHub organisation settings on some plans. Check whether they apply in VS Code on NSW Health's plan; if so, the always-on rules could also be set there.

### What never goes in these files

Secrets, internal hostnames, or anything describing how a system could be attacked. Every contributor reads these files, and they are sent to the model on every request.

## The AI configuration check

`scripts/check_ai_config.py` and `.github/workflows/ai-config-check.yml` run on every pull request:

- they **fail** on hidden characters in agent instruction files, and on plain-text credentials in MCP configuration
- they **list** AI SDKs, AI endpoints, model files and MCP servers, so the repository's AI use can be matched to the AI register

See [section 4 of the ATLAS guide](ai-security-with-atlas.md#4-what-can-be-checked-automatically) for what this check can and cannot catch. Its tests are in [scripts/test_check_ai_config.py](../../scripts/test_check_ai_config.py).
