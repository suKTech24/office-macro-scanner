# SQL and database secure coding guide

For anyone who writes queries, stored procedures, reports or database jobs. Implements [SDS-04](../02-standards/SDS-04-secure-coding.md) R2 and [SDS-12](../02-standards/SDS-12-health-data-and-privacy.md).

## 1. Never build SQL from input

Unsafe — dynamic SQL by concatenation, even inside a stored procedure:

```sql
SET @sql = 'SELECT * FROM dbo.Patient WHERE Surname = ''' + @Surname + '''';
EXEC (@sql);
```

Safe — static SQL, or parameterised dynamic SQL:

```sql
SELECT PatientId, Surname FROM dbo.Patient WHERE Surname = @Surname;

-- When dynamic SQL is unavoidable
EXEC sp_executesql
     N'SELECT PatientId, Surname FROM dbo.Patient WHERE Surname = @s',
     N'@s nvarchar(100)', @s = @Surname;
```

Identifiers (table or column names) cannot be parameters: check them against an allow-list and wrap with `QUOTENAME()`.

## 2. Least privilege

- Applications connect with an identity that has only the permissions it needs (execute on specific procedures, or select/insert/update on specific tables). Never `sa`, `db_owner` or `sysadmin`.
- Prefer identity-based authentication (managed identity, integrated authentication) over SQL logins with passwords.
- Separate identities for application, reporting, migration and administration.
- Avoid `xp_cmdshell`, CLR with unsafe permission, and cross-database ownership chaining. Linked servers use least-privilege mappings.

## 3. Protect the data

- Encrypt in transit (`Encrypt=True`, and do not set `TrustServerCertificate=True` in production).
- Encryption at rest on by default; consider column-level protection for highly sensitive fields.
- Use row-level security or views to limit what reporting identities see; mask where full values are not needed.
- Enable auditing for access to tables holding health information.

## 4. Non-production data

- No copies of production databases in development or test ([SDS-12](../02-standards/SDS-12-health-data-and-privacy.md) R1). Use synthetic data or an approved de-identification process.
- No ad hoc exports of health information to spreadsheets or local files.

## 5. Change control

- Schema and procedures live in source control as migrations or a database project, and deploy through the pipeline.
- Migrations are reviewed like code, are reversible where possible, and are tested against a realistic volume.
- Scheduled jobs are code: stored in the repository, owned and reviewed.

## 6. Reports and BI

- Parameterise report queries; do not splice report parameters into SQL text.
- Apply the viewer's access rights, not a shared high-privilege account, where the platform supports it.
- Publish to governed workspaces; review who a report is shared with.

## Review checklist

- [ ] No string-built SQL
- [ ] Connection identity is least privilege; no passwords in connection strings
- [ ] Transport encryption enforced
- [ ] Sensitive access audited
- [ ] No production data outside production
- [ ] Schema changes in source control
