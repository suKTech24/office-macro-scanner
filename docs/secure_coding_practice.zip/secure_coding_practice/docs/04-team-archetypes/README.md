# Team archetypes

NSW Health teams differ too much for one set of instructions. An **archetype** is a kind of team defined by what it produces. Each archetype page says, in that team's own terms, which standards matter most and what "good" looks like.

> These seven archetypes are a hypothesis. **Discovery confirms, merges or splits them.** A team can belong to more than one.

| Code | Archetype | Produces | Typical technologies **[ASSUMPTION]** |
|---|---|---|---|
| A | [Application and API engineering](application-and-api.md) | Custom applications, portals, APIs, mobile apps | .NET, Java, JavaScript/TypeScript, SQL |
| B | [Integration and interoperability](integration.md) | Interfaces, message mappings, API mediation | Integration engines, HL7 v2, FHIR, scripting |
| C | [Platform, cloud and infrastructure](platform-cloud-infrastructure.md) | Landing zones, IaC, pipelines, images | Terraform, Bicep, PowerShell, containers |
| D | [Endpoint and digital workspace](endpoint-and-digital-workspace.md) | Device configuration, packages, remediation scripts, virtual desktop images | PowerShell, endpoint management, packaging tools |
| E | [Data, analytics and AI](data-analytics-ai.md) | Pipelines, notebooks, reports, models | SQL, Python, R, BI tools |
| F | [Low-code and citizen development](low-code.md) | Apps, flows, forms | Power Platform and similar |
| G | [Vendor-developed and configured systems](vendor-and-configured-systems.md) | Custom code and configuration in commercial products; contracted development | Varies by product |

## Applicability matrix

● core for this archetype  ○ applies in part  – usually not applicable

| Standard | A | B | C | D | E | F | G |
|---|---|---|---|---|---|---|---|
| SDS-01 Source control | ● | ● | ● | ● | ● | ○ | ● |
| SDS-02 Secrets | ● | ● | ● | ● | ● | ● | ● |
| SDS-03 Supply chain | ● | ○ | ● | ● | ● | ○ | ● |
| SDS-04 Secure coding | ● | ● | ○ | ○ | ● | ○ | ● |
| SDS-05 Design / threat modelling | ● | ● | ● | ○ | ● | ○ | ● |
| SDS-06 Security testing | ● | ● | ● | ○ | ○ | ○ | ● |
| SDS-07 Pipelines | ● | ● | ● | ● | ○ | ○ | ○ |
| SDS-08 IaC and cloud | ○ | ○ | ● | ○ | ○ | – | ○ |
| SDS-09 AuthN / AuthZ / crypto | ● | ● | ● | ○ | ○ | ○ | ● |
| SDS-10 Logging | ● | ● | ● | ● | ○ | ○ | ● |
| SDS-11 Vulnerability management | ● | ● | ● | ● | ● | ○ | ● |
| SDS-12 Health data and privacy | ● | ● | ○ | ○ | ● | ● | ● |
| SDS-13 AI tools and agents | ● | ● | ● | ● | ● | ● | ● |
| SDS-14 Vendor software | ○ | ○ | ○ | ○ | ○ | – | ● |
| SDS-15 Scripts and automation | ○ | ○ | ● | ● | ○ | – | ○ |
| SDS-16 Low-code | – | – | – | – | ○ | ● | ○ |
| SDS-17 AI-enabled systems | ○ | ○ | ○ | – | ● | ○ | ○ |

SDS-17 becomes **core** for any team, in any archetype, the moment its system calls an AI model or runs an agent.

The [minimum baseline](../02-standards/README.md#the-minimum-baseline) applies to everyone regardless of this matrix.

## Legacy and manual delivery

Not an archetype but a condition that can apply to any of them: unsupported tooling, offline builds, manual promotion, no pipeline. These teams cannot meet several standards as written, and pretending otherwise produces paper compliance. Until they migrate, ask for the equivalent outcome by hand:

- one authoritative copy of the source, even if it is not yet in a modern platform
- two-person review where feasible
- a recorded hash of what was deployed, and a witnessed promotion
- compensating controls recorded as an [exception](../05-templates/exception-request.md)
- a named migration owner and date

Apply more scrutiny to anything internet-facing, cross-organisation, highly privileged, holding sensitive data, or with credible clinical or availability impact.

## How to use an archetype page

1. Find your archetype(s).
2. Read "What matters most" — the five things to get right first.
3. Follow the links to the standards and guides.
4. Record your team's position in your [team profile](../01-discovery/team-profile-template.md).
