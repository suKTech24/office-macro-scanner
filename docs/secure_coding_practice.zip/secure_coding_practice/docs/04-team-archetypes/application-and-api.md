# Archetype A — Application and API engineering

**Who:** teams building and maintaining custom applications, portals, APIs and mobile apps, for clinicians, staff or the public.

**Why it matters:** these systems expose health information through interfaces that attackers can reach and probe directly.

## What matters most

1. **Authorisation on every request, for every record.** Broken access control is the most common serious defect in applications. ([SDS-09](../02-standards/SDS-09-authentication-authorisation-cryptography.md) R5)
2. **Use the organisation's identity provider.** No home-grown login. ([SDS-09](../02-standards/SDS-09-authentication-authorisation-cryptography.md) R1)
3. **Threat model before you build**, and again on significant change. ([SDS-05](../02-standards/SDS-05-secure-design-and-threat-modelling.md))
4. **The full pipeline on every pull request:** secrets, dependencies, static analysis; dynamic testing before major releases. ([SDS-06](../02-standards/SDS-06-security-testing.md))
5. **Log who accessed what.** Access to health information is attributable and reaches central monitoring. ([SDS-10](../02-standards/SDS-10-logging-and-monitoring.md))

## Typical risks to look for

- Record identifiers in URLs with no ownership check
- Secrets in configuration files
- Outdated frameworks and transitive dependencies
- Production data copied to test
- Verbose errors; missing security headers
- APIs without rate limiting or inventory (forgotten endpoints)

## Verification target

Use OWASP ASVS as the test reference: Level 1 for Tier 3, Level 2 for Tier 1–2 **[VERIFY with security architecture]**.

## Also read

[.NET](../03-guides/dotnet.md) · [JavaScript/TypeScript](../03-guides/javascript-typescript.md) · [Python](../03-guides/python.md) · [SQL](../03-guides/sql.md) · [Reference pipelines](../../pipelines/README.md)
