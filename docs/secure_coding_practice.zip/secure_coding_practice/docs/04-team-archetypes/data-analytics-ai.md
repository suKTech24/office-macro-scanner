# Archetype E — Data, analytics and AI

**Who:** teams building data pipelines, warehouses, reports, dashboards, statistical analyses and machine-learning models, including analysts in LHDs, pillars and registries who write SQL, Python or R.

**Why it matters:** this work handles health information in bulk. The main risk is not a clever exploit; it is data ending up somewhere it should not be.

## What matters most

1. **Work where the data lives.** Analyse in the approved platform; do not extract health information to laptops, personal drives or unapproved tools. ([SDS-12](../02-standards/SDS-12-health-data-and-privacy.md) R7)
2. **Code in source control, data and outputs out of it.** Strip notebook outputs; never commit extracts. ([SDS-01](../02-standards/SDS-01-source-control-and-repository-security.md), [SDS-12](../02-standards/SDS-12-health-data-and-privacy.md) R3)
3. **No credentials in notebooks or queries.** ([SDS-02](../02-standards/SDS-02-secrets-management.md))
4. **Packages and models are dependencies.** Install from approved sources; a downloaded model file can execute code when loaded. ([SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md))
5. **Never put health or personal information into AI tools not approved for it.** ([SDS-13](../02-standards/SDS-13-ai-assisted-development.md) R2)

## Typical risks to look for

- Extracts in email, shared drives and local folders
- Notebooks committed with patient rows in outputs
- Database credentials in connection cells
- Over-broad read access to whole warehouses
- Re-identification risk in "de-identified" data sets and small-cell outputs
- Unvetted packages and pre-trained models

## Building AI

When the work produces a model, an LLM feature or an agent, [SDS-17](../02-standards/SDS-17-ai-enabled-systems.md) applies: threat-model it with [MITRE ATLAS](../03-guides/ai-security-with-atlas.md) at concept stage, keep an AI bill of materials, and test it adversarially before release. Enterprise AI governance, detection and red teaming sit with the AI security program, which this standard links to.

## Also read

[Python guide](../03-guides/python.md) · [SQL guide](../03-guides/sql.md) · [SDS-12](../02-standards/SDS-12-health-data-and-privacy.md)
