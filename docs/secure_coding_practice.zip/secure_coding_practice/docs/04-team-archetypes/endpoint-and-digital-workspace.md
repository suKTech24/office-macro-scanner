# Archetype D — Endpoint and digital workspace

**Who:** teams managing desktops, laptops, mobile devices, virtual desktops, collaboration tools and the software deployed to them. You may not call yourselves developers, but you write and ship code: detection and remediation scripts, packaged applications, configuration profiles, images, logon scripts, automation runbooks.

**Why you are high risk:** your tooling runs code as SYSTEM on every device. One bad or malicious script is an organisation-wide incident. Attackers know this and target endpoint-management platforms and the people who administer them.

## What matters most

1. **Get scripts and packages into source control with review.** Nothing is typed or pasted into the console. ([SDS-01](../02-standards/SDS-01-source-control-and-repository-security.md), [SDS-15](../02-standards/SDS-15-scripts-and-automation.md) R1)
2. **No credentials in scripts or packages.** Not in install command lines, not in configuration profiles, not in task sequences. ([SDS-02](../02-standards/SDS-02-secrets-management.md))
3. **Sign what you deploy and verify what you repackage.** Signed scripts work with application control; vendor installers are checked by signature or hash from the official source. ([SDS-15](../02-standards/SDS-15-scripts-and-automation.md) R3, [SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md) R10)
4. **Two people for broad deployments, staged through rings.** A second approver in the platform for anything targeting all devices; test → pilot → broad with rollback. ([SDS-15](../02-standards/SDS-15-scripts-and-automation.md) R8, R9)
5. **Do not weaken the device.** Scripts never disable protection, bypass execution policy or add broad exclusions without an approved change. ([SDS-15](../02-standards/SDS-15-scripts-and-automation.md) R7)

## Typical risks to look for

- Local administrator or service account passwords embedded in scripts or packages
- Scripts that download from the internet and execute
- Packages built from installers of unknown origin
- Content edited directly in the management console with no history
- Wide role assignments in the management platform; no separation between author and deployer
- SYSTEM-context scripts writing to user-writable folders
- Old logon scripts and scheduled tasks nobody owns

## What the paved road should give you

- A script repository template: folder layout, PSScriptAnalyzer, Pester, signing and a release step that publishes to the management platform.
- A central signing service.
- A packaging checklist (source, hash, signature, silent-install parameters, detection rule, uninstall).
- Role design for the management platform with a publish-approval step.

## Also read

- [PowerShell guide](../03-guides/powershell.md)
- [Lightweight threat model for automation](../05-templates/threat-model-template.md#lightweight-version-for-scripts-and-automation)
- Essential Eight: application control, restrict administrative privileges, user application hardening, patch applications. Your work implements these for the organisation; your own tooling has to respect them too.

## Discovery questions specific to this archetype

See the endpoint section of the [engineering team interview guide](../01-discovery/interview-guides/04-engineering-team.md#extra-questions-by-archetype).
