# Archetype B — Integration and interoperability

**Who:** teams building interfaces between clinical and corporate systems: integration engine channels, HL7 v2 and FHIR mappings, file transfers, API mediation.

**Why it matters:** integration sits on the path of nearly all health information and holds credentials to many systems. It is trusted by both ends, so a flaw here crosses boundaries that other controls rely on.

## What matters most

1. **Interface code and configuration in source control**, exported from the engine and reviewed, not only living inside the tool. ([SDS-01](../02-standards/SDS-01-source-control-and-repository-security.md))
2. **Credentials and certificates in a vault, one per interface, with expiry tracked.** ([SDS-02](../02-standards/SDS-02-secrets-management.md), [SDS-09](../02-standards/SDS-09-authentication-authorisation-cryptography.md) R13)
3. **Treat every inbound message as untrusted.** Validate structure and content; do not pass fields into queries, commands or file paths unchecked. ([SDS-04](../02-standards/SDS-04-secure-coding.md) R1, R2)
4. **Keep message content out of logs and error queues** beyond what is needed, and protect and expire what is kept. ([SDS-10](../02-standards/SDS-10-logging-and-monitoring.md) R3, [SDS-12](../02-standards/SDS-12-health-data-and-privacy.md))
5. **Authenticate and encrypt every connection**, including internal ones. ([SDS-09](../02-standards/SDS-09-authentication-authorisation-cryptography.md) R3, R9)

## Test what can hurt a patient

Security testing alone is not enough for an interface that carries clinical information. With clinical and data custodian input, and using synthetic messages:

- test **duplicate**, **delayed**, **out-of-order** and **misrouted** messages, and confirm the receiving system handles each safely
- ask whether stale, missing or wrong-patient information could change a clinical decision
- rehearse downtime and the reconciliation afterwards
- record who can stop a rollout and how service is restored when rollback cannot undo data already sent

## Typical risks to look for

- Unencrypted, unauthenticated HL7 v2 over internal networks
- Shared service accounts across many interfaces
- Real patient messages used as test data
- Embedded scripts in channels that are never reviewed
- Dead-letter queues and file drops holding health information indefinitely
- FHIR APIs without scope or record-level authorisation

## Also read

[Threat model template](../05-templates/threat-model-template.md) · [SQL guide](../03-guides/sql.md) · an integration-specific guide is planned ([guides](../03-guides/README.md))
