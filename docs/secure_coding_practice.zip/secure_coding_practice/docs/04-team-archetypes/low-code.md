# Archetype F — Low-code and citizen development

**Who:** staff building apps, forms and automated flows on low-code platforms, often clinicians, administrators and analysts rather than IT, plus the platform team that governs them.

**Why it matters:** useful tools get built quickly, outside every traditional control, and can quietly become relied upon for patient care or hold health information.

## What matters most

1. **Build in the right environment for the data.** ([SDS-16](../02-standards/SDS-16-low-code.md) R1)
2. **Two owners, a purpose and a tier for everything shared.** ([SDS-16](../02-standards/SDS-16-low-code.md) R3)
3. **Do not run on a maker's personal privileged access.** ([SDS-16](../02-standards/SDS-16-low-code.md) R4)
4. **Share with named groups only.** ([SDS-16](../02-standards/SDS-16-low-code.md) R5)
5. **Made-up data for building and testing.** ([SDS-12](../02-standards/SDS-12-health-data-and-privacy.md) R1)

## Low-code AI agents

Agents built in low-code tools (for example Copilot Studio) read untrusted content and can send mail, change records and call connectors. Each one needs an owner in the AI register ([SDS-13](../02-standards/SDS-13-ai-assisted-development.md) R11), and anything shared beyond its maker falls under [SDS-17](../02-standards/SDS-17-ai-enabled-systems.md). Discovery has already found agents with no owner; those are disabled until someone takes ownership.

## For the program

Most control here is exercised by the **platform team** through environment strategy and data loss prevention policy, not by asking hundreds of makers to read standards. Makers get a two-page guide and a short awareness module; anything Tier 1–2 is handed to, or reviewed by, a professional team.

## Typical risks to look for

- Apps in the default environment holding patient data
- Flows that email or copy data to personal or external services
- HTTP-triggered flows with no authentication
- Orphaned apps whose maker has left
- Apps that have become clinically important without anyone deciding so

## Also read

[Power Platform guide](../03-guides/power-platform.md)
