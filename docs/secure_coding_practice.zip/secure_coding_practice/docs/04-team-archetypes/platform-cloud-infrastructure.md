# Archetype C — Platform, cloud and infrastructure

**Who:** teams that build landing zones, infrastructure as code, CI/CD platforms, container platforms, golden images and server automation.

**Why it matters:** you build what everyone else stands on. Your defaults become the organisation's defaults, and your pipelines and automation identities hold the broadest privilege.

## What matters most

1. **Secure the pipelines and their identities.** Federated short-lived credentials, least privilege per environment, pinned actions, protected agents. ([SDS-07](../02-standards/SDS-07-build-and-deployment-pipelines.md))
2. **Guardrails as policy, not documentation.** If it matters, the platform should refuse to deploy it wrong. ([SDS-08](../02-standards/SDS-08-infrastructure-as-code-and-cloud.md) R3)
3. **Hardened, versioned modules and templates** that other teams adopt because they are easier. ([SDS-08](../02-standards/SDS-08-infrastructure-as-code-and-cloud.md) R8)
4. **Protect state, images and registries.** They contain secrets and are supply-chain choke points. ([SDS-08](../02-standards/SDS-08-infrastructure-as-code-and-cloud.md) R7, [SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md) R9)
5. **No manual production changes.** Break-glass is logged and reconciled. ([SDS-08](../02-standards/SDS-08-infrastructure-as-code-and-cloud.md) R1)

## Your second role: paved-road provider

This archetype is both subject to the standards and the main way the standards scale. Expect to own: repository templates, [reference pipelines](../../pipelines/README.md), the package proxy, the signing service, the SBOM store and the policy guardrails. The program plan funds this work in Phase 3.

## Typical risks to look for

- Long-lived deployment secrets in pipeline variables
- Shared self-hosted build agents with broad network reach
- Over-privileged service principals
- State files in repositories or open storage
- Unpinned third-party actions and modules
- Portal changes drifting from code

## Also read

[IaC guide](../03-guides/infrastructure-as-code.md) · [PowerShell guide](../03-guides/powershell.md) · OWASP DSOMM for pipeline maturity
