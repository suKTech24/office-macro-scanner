# Archetype G — Vendor-developed and configured systems

**Who:** teams that own commercial clinical and corporate products (electronic medical records, pathology, imaging, ERP, ITSM) and the custom reports, scripts, extensions and integrations added to them; and teams managing suppliers who develop software for NSW Health.

**Why it matters:** NSW Health cannot see inside most vendor code, but is accountable for it, and the custom layer added on top is NSW Health's own code even when nobody treats it that way.

## What matters most

1. **Know what custom code exists.** Inventory extensions, scripts, reports and integrations added to each product, and put them in source control. ([SDS-14](../02-standards/SDS-14-vendor-and-third-party-software.md) R9, [SDS-01](../02-standards/SDS-01-source-control-and-repository-security.md))
2. **Get the contract right.** Secure development, evidence per release, vulnerability notification, right to test. ([SDS-14](../02-standards/SDS-14-vendor-and-third-party-software.md) R1–R5)
3. **Control supplier access.** Named identities, MFA, time-bound, logged. ([SDS-14](../02-standards/SDS-14-vendor-and-third-party-software.md) R6)
4. **Ask for an SBOM and act on it.** So that the next major library vulnerability can be answered from a list. ([SDS-03](../02-standards/SDS-03-dependencies-and-supply-chain.md) R7)
5. **No production data to vendors for testing** without the data custodian's approval and equivalent controls. ([SDS-12](../02-standards/SDS-12-health-data-and-privacy.md))

## Typical risks to look for

- Shared vendor support accounts with standing access
- Customisations nobody owns or can rebuild
- Vendors unable to say which components their product contains
- Patches delayed by vendor certification cycles, with no compensating controls recorded
- Database copies sent to vendors for troubleshooting

## Working within constraints

Where a vendor cannot meet a requirement, record an [exception](../05-templates/exception-request.md) with compensating controls (network isolation, monitoring, restricted access), and raise the gap at contract renewal. The exception register doubles as the list of asks for the next negotiation.

## Also read

[Supplier security questionnaire](../05-templates/supplier-security-questionnaire.md) · [Procurement interview guide](../01-discovery/interview-guides/06-procurement-and-vendors.md)
