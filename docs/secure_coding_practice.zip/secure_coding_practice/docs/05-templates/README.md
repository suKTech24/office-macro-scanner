# Templates

Copy these into your own repository or use them in the process they belong to.

| Template | Use when | Standard |
|---|---|---|
| [Security requirements checklist](security-requirements-checklist.md) | Starting a new system or significant change | SDS-05 |
| [Threat model](threat-model-template.md) | Designing Tier 1–2 systems; lightweight version for scripts | SDS-05 |
| [Secure code review checklist](secure-code-review-checklist.md) | Reviewing a pull request | SDS-04 |
| [Pull request template](pull-request-template.md) | Every product repository | SDS-01, SDS-04 |
| [Release security checklist](release-security-checklist.md) | Before a production release | SDS-06, SDS-07 |
| [SECURITY.md](SECURITY-template.md) | Only when a repository needs system-specific security detail; otherwise the organisation default applies | SDS-01 |
| [Exception request](exception-request.md) | A MUST cannot be met | Operating model |
| [Supplier security questionnaire](supplier-security-questionnaire.md) | Procuring or renewing developed software | SDS-14 |
| [Decision record](decision-record-template.md) | Recording a significant security decision | SDS-05 |
| [Standard template](standard-template.md) | Writing a new standard | Contributing |
