# Security — `<system or repository name>`

Most repositories do not need this file: the organisation default `SECURITY.md` in the `.github` repository applies automatically, and owner and risk tier go in the `README`. Use this template only when the repository needs system-specific detail, such as supported versions or a dedicated contact. A repository `SECURITY.md` replaces the default entirely, so keep the reporting channels below.

Copy to the root of your repository as `SECURITY.md` and fill in.

| | |
|---|---|
| **Owner team** | |
| **System owner** | |
| **Security champion** | |
| **Risk tier** | 1 / 2 / 3 |
| **Data handled** | |

## Reporting a security problem

Do not open a public issue or discuss in open channels.

- Suspected incident or exposed data: report to the Health Security Operations Centre through the SARA portal, by email to ehnsw-is-security-incidents@health.nsw.gov.au (business hours), or by phone to the State Wide Service Desk on 1300 28 55 33 (24 hours), as set out in PD2026_001 section 5.
- Vulnerability in this code: contact the owner team at **[insert]**, or the security champion.

Include what you found, where, and how to reproduce it. Do not access data beyond what is needed to show the problem.

## What to expect

We acknowledge reports within two business days and fix within the timeframes in the NSW Health vulnerability management standard (SDS-11).

## Supported versions

| Version | Supported |
|---|---|
| | |

## Security documentation

- Threat model: `docs/security/threat-model.md`
- Security requirements: `docs/security/security-requirements.md`
- Current exceptions: **[link to register entries]**
