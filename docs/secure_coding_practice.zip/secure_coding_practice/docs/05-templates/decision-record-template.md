# NNNN — Title of decision

| Status | Date | Deciders |
|---|---|---|
| Proposed / Accepted / Superseded by NNNN | | |

## Context

What situation or problem requires a decision? Include constraints.

## Options considered

1. Option A — summary, pros, cons
2. Option B — summary, pros, cons

## Decision

What was decided, in one or two sentences.

## Consequences

What becomes easier, what becomes harder, what risk is accepted and by whom, and what must be revisited and when.
