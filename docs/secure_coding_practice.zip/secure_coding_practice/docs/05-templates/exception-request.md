# Exception request

Use when a MUST requirement cannot be met by its due date. See the [exception process](../00-program/operating-model.md#exceptions). Do not include detail that would help an attacker; reference the risk register instead.

This form prepares and tracks the request. Where a policy or security standard is not met, PD2026_001 §3.2.6 also requires an **eHealth Information Security Exemption** lodged through the SARA portal, an entry in a risk register, and a validity of no more than one year. An exception here cannot waive a legal or policy obligation.

| Field | Value |
|---|---|
| System / repository | |
| Entity and team | |
| Risk tier | |
| Requirement (for example SDS-07-R4) | |
| Requested by | |
| Date | |

## Why the requirement cannot be met

What prevents compliance (technical constraint, vendor limitation, capacity, cost)?

## Scope

Affected organisations, environments and systems.

## Risk if left as is

What could happen, how likely, and who or what is affected? Include clinical and privacy impact where relevant. Give the rating from the NSW Health Risk Matrix and the risk register reference.

## Compensating controls

What reduces the risk in the meantime (isolation, monitoring, restricted access, manual checks)?

## Plan to comply

| Step | Owner | Date |
|---|---|---|
| | | |

## Duration requested

Expiry date (maximum 6 months for Tier 1, 12 months for Tier 2–3): ____

## Approval

| Role | Name | Decision | Date |
|---|---|---|---|
| Security champion (reviewed) | | | |
| Approver (Tier 3: team lead · Tier 2: program · Tier 1: cyber governance / system risk owner) | | | |

Register reference: ____

SARA exemption reference (if required): ____

Closure evidence (how it was shown the requirement is now met): ____
