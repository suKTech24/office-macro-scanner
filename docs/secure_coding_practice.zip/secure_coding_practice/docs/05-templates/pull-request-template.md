# Pull request template for product repositories

Copy to `.github/pull_request_template.md` (GitHub) or the equivalent in your platform. For low-code or configuration-only work, link an export or diff and the environment promotion record instead of code.

```markdown
## What and why

<!-- Work item, service ID, one or two sentences. -->

## What this changes

- [ ] Identity, permissions or roles
- [ ] Data collected, stored, logged or sent elsewhere
- [ ] Dependencies (new or upgraded)
- [ ] An external interface or integration
- [ ] A clinical workflow
- [ ] None of the above

<!-- If any box is ticked, describe it. Link the threat model update, assessment or approved exception. -->

## Evidence

- Tests, including a rejected-access or invalid-input case:
- Security check results (pipeline run):

## Release and recovery

- Deployment targets:
- What to watch after release:
- How to roll back, or what to do if rollback is not possible:

## AI assistance

- [ ] Significant parts were AI-generated, and I have read and understood them
```
