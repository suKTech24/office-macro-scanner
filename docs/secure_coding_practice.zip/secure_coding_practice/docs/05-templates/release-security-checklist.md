# Release security checklist

For production releases of Tier 1 and Tier 2 systems. Most items should be answered by pipeline evidence, not by hand. Attach to the change record.

| System | Version | Tier | Date | Release owner |
|---|---|---|---|---|
| | | | | |

## Evidence

- [ ] All changes merged through reviewed pull requests
- [ ] Secret scan: clean
- [ ] Dependency scan: no critical/high unresolved, or exception reference: ____
- [ ] Static analysis: no critical/high unresolved, or exception reference: ____
- [ ] IaC / container scan (if applicable): clean or triaged
- [ ] Dynamic or penetration testing done where required; findings tracked
- [ ] SBOM generated and stored with the artefact
- [ ] Artefact built by the pipeline, signed where applicable, and identical to the one tested

## Design and data

- [ ] Threat model current for this release
- [ ] No new data category, integration or exposure without design review
- [ ] No real patient or staff data used in testing

## Deployment

- [ ] Deployment by pipeline with approval from someone other than the author
- [ ] Debug settings, test accounts and sample data absent from production configuration
- [ ] Secrets sourced from the vault; none added to configuration
- [ ] Approved commit, configuration export or vendor version recorded, and traceable to the artefact digest or signature
- [ ] Rollback plan tested or documented, including data reconciliation where rollback cannot undo data effects
- [ ] Stop criteria defined, and a named operator who can halt the rollout
- [ ] Logging and alerting verified in production after release

## Sign-off

| Role | Name | Date |
|---|---|---|
| Tech lead | | |
| Security champion | | |
| System owner (Tier 1) | | |
