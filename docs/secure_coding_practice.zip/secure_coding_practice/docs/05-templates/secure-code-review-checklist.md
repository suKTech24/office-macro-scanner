# Secure code review checklist

For the human reviewer of a pull request. Tools check the mechanical things; you check intent and logic. Skip sections that do not apply.

## Always

- [ ] I understand what this change does and why
- [ ] No secrets, credentials, real hostnames or patient/staff data in code, tests, comments or commit messages
- [ ] Pipeline checks pass; any suppression of a finding has a reason I agree with
- [ ] New dependencies are necessary, real, maintained and from an approved source
- [ ] If AI-generated, the author can explain it

## Access control

- [ ] Every new endpoint, function or action has an authorisation check
- [ ] The check covers the specific record, not just the role
- [ ] Nothing relies on the client (browser, app) to enforce a rule

## Input and output

- [ ] Input from outside is validated for type, length, format and range
- [ ] Queries and commands are parameterised; nothing is built by joining strings with input
- [ ] Output is encoded by the framework; no raw HTML from untrusted data
- [ ] File paths and URLs from input are constrained

## Data

- [ ] Only the data needed is collected, returned and stored
- [ ] Sensitive data is not logged or placed in errors
- [ ] Encryption in transit is not disabled or bypassed

## Errors and logging

- [ ] Failures deny access rather than allow it
- [ ] Security-relevant actions are logged with who, what, when and outcome

## Scripts, IaC and pipelines

- [ ] Runs with the least privilege that works
- [ ] Nothing downloaded and executed without verification
- [ ] No security control is weakened
- [ ] Nothing is made public that should not be
- [ ] Pipeline changes do not expose secrets to untrusted code or widen deployment rights

## Tests

- [ ] Tests cover the denied and malformed cases, not only the happy path
