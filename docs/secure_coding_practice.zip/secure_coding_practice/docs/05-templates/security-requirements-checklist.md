# Security requirements checklist

Complete at the start of a new system or significant change. Fifteen minutes with the tech lead and product owner. Keep it in the repository under `docs/security/`.

| System | Change | Date | Completed by |
|---|---|---|---|
| | | | |

## 1. Classify

- [ ] Risk tier assigned (1 / 2 / 3) and recorded: ____
- [ ] Data handled: health information ☐ personal information ☐ credentials ☐ official-sensitive ☐ none ☐
- [ ] Could failure or tampering affect patient care? If yes, clinical safety engaged
- [ ] Could this be a medical device or clinical decision support? If yes, regulatory assessment requested
- [ ] Privacy impact assessment considered with the privacy office

## 2. Exposure

- [ ] Who are the users (staff, patients, public, other systems)?
- [ ] Internet-facing? ____
- [ ] Which systems does it integrate with, and in which direction does data flow?
- [ ] What privilege does it run with, and across how many devices or servers?

## 3. Requirements to capture as backlog items

- [ ] Authentication through the organisation's identity provider; MFA
- [ ] Roles and record-level authorisation defined
- [ ] Secrets approach (managed identity / vault)
- [ ] Data encryption in transit and at rest
- [ ] Security events to log; SIEM onboarding
- [ ] Data retention and disposal
- [ ] Synthetic test data available
- [ ] Hosting in an approved landing zone; data location requirements
- [ ] Availability and recovery expectations
- [ ] Third-party components and services assessed
- [ ] AI components or AI-assisted development involved

## 4. Assurance plan

- [ ] Threat model required (Tier 1–2)? Date planned: ____
- [ ] Security architecture review required (Tier 1)?
- [ ] Penetration test required (Tier 1)? Date planned: ____
- [ ] Pipeline security checks in place
