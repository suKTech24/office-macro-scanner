# SDS-NN Title

| Version | Status | Owner | Maps to |
|---|---|---|---|
| 0.1 | Draft / Ratified | | NSW CSP x.x · ISM · SSDF · other |

**Why:** two or three sentences on the risk this standard addresses, in plain language.

Scope note if needed: what this covers and what it does not.

## Requirements

| ID | Requirement | Tier | Verify |
|---|---|---|---|
| R1 | One statement using MUST / MUST NOT / SHOULD | All / T1 / T1–2 | How compliance is checked |

Rules for requirements:

- One requirement per row. If it contains "and", consider splitting it.
- Every MUST has a verification method, preferably automated.
- Avoid naming a product in the requirement; name it in the paved road.

## Paved road

What the program or platform provides so that meeting the requirements is the easy path: templates, pipeline steps, services, examples.

## Transition

For a new or changed MUST: date it takes effect (default 90 days after ratification).
