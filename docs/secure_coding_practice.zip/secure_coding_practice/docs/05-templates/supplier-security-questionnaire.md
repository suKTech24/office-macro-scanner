# Supplier security questionnaire — developed software

For suppliers who develop, customise or maintain software for NSW Health. Scale to the engagement: sections 1–3 for small purchases, all sections for Tier 1–2. Supports [SDS-14](../02-standards/SDS-14-vendor-and-third-party-software.md).

| Supplier | Product / service | Completed by | Date |
|---|---|---|---|
| | | | |

## 1. Secure development lifecycle

1. Describe your secure development lifecycle. Which framework is it aligned to (NIST SSDF, ASD ISM, Microsoft SDL, ISO/IEC 27001, other)?
2. How are developers trained in secure coding, and how often?
3. Is all code peer reviewed before release?
4. Do you perform threat modelling or security design review? When?

## 2. Testing and vulnerabilities

5. Which automated security tests run on each release (SAST, dependency scanning, secret scanning, DAST)?
6. How often is independent penetration testing performed? Will you share a summary?
7. What are your remediation timeframes by severity?
8. How will you notify NSW Health of vulnerabilities and security incidents, and how quickly?
9. Do you have a published vulnerability disclosure policy?

## 3. Access and data

10. How do your staff access NSW Health environments (identity, MFA, privileged access management)?
11. Where is development and support performed? Which countries can access NSW Health code or data?
12. Will NSW Health data be used in your development or test environments? How is it protected or de-identified?
13. How are secrets for NSW Health environments stored and rotated?

## 4. Supply chain

14. Can you provide an SBOM (SPDX or CycloneDX) with each release?
15. How do you select, track and update third-party and open-source components?
16. How are builds protected from tampering (build isolation, signing, provenance)?
17. Which subcontractors contribute to the software?

## 5. AI

18. Do you use AI coding tools on NSW Health work? Which, and what data do they receive?
19. Does the product include AI features? Describe the model, its provider and what data it processes.

## 6. Assurance and exit

20. Which certifications or independent assessments do you hold (ISO/IEC 27001, SOC 2, IRAP)?
21. Do you agree to NSW Health security testing the delivered software?
22. What are the arrangements for source code access or escrow?
23. How are code, data and credentials returned or destroyed at contract end?
