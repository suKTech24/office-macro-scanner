# Threat model — `<system name>`

Keep this file in the system's repository (`docs/security/threat-model.md`) and update it on significant change. Do not include exploit detail for unfixed issues; reference the tracker item instead.

| Tier | Owner | Participants | Date | Next review |
|---|---|---|---|---|
| | | | | |

## 1. What are we working on?

**Purpose:** one paragraph.

**Diagram:** a data-flow diagram showing users, processes, data stores, external systems and trust boundaries. Mermaid works in most repository viewers:

```mermaid
flowchart LR
    U[Clinician browser] -->|HTTPS, OIDC| W[Web app]
    subgraph Trust boundary: application zone
        W --> A[API]
        A --> D[(Database)]
    end
    A -->|FHIR, mTLS| E[External: integration engine]
```

**Assets:** what is worth protecting (data, credentials, availability, integrity of clinical information).

**Assumptions:** what you are relying on (for example "network segment is restricted", "identity provider enforces MFA").

## 2. What can go wrong?

Walk each element and data flow with STRIDE.

| Letter | Threat | Ask |
|---|---|---|
| S | Spoofing | Can someone pretend to be a user or system? |
| T | Tampering | Can data or code be changed in transit or at rest? |
| R | Repudiation | Could someone deny an action because we did not record it? |
| I | Information disclosure | Can data leak, including through logs and errors? |
| D | Denial of service | Can it be made unavailable when clinically needed? |
| E | Elevation of privilege | Can someone do more than they should? |

Also ask the health-specific questions: could this show the **wrong patient's** data? Could a clinician act on **altered or missing** information? What happens to care if this is **down for four hours**?

## 3. What are we going to do about it?

| ID | Element / flow | Threat | STRIDE | Risk (H/M/L) | Decision (mitigate / accept / avoid / transfer) | Control | Tracker ref | Owner |
|---|---|---|---|---|---|---|---|---|
| T1 | | | | | | | | |

Accepted risks need a named owner with authority for the tier.

## AI components

Complete this section if the system calls an AI model, retrieves content for a model, or runs an agent ([SDS-17](../02-standards/SDS-17-ai-enabled-systems.md)). Use the starter technique sets in the [ATLAS guide](../03-guides/ai-security-with-atlas.md#starter-technique-sets-atlas-202610).

| Question | Answer |
|---|---|
| Model(s), version and provider; where data is processed | |
| NSW AI Assessment Framework reference | |
| Could output inform a clinical decision? | |
| Every source of text the model reads that NSW Health did not write | |
| Tools the system or agent can call, and with whose permissions | |
| Actions that need human approval before they take effect | |
| Who can add or change retrieved or training content | |
| How it is switched off, and the fallback workflow | |

| ID | Component | ATLAS technique | Applies? | Existing control | Added control or ATLAS mitigation | Test that proves it | Owner |
|---|---|---|---|---|---|---|---|
| A1 | | AML.T0051.001 Indirect prompt injection | | | | | |
| A2 | | AML.T0053 AI Agent Tool Invocation | | | | | |
| A3 | | AML.T0070 RAG Poisoning | | | | | |

## 4. Did we do a good job?

- [ ] Diagram matches what is actually deployed
- [ ] Every trust boundary crossing has a threat considered
- [ ] Every threat has a decision and an owner
- [ ] Mitigations are in the backlog and have tests where possible
- [ ] AI components section completed, if the system uses AI
- [ ] Reviewed by security architecture (Tier 1)

---

## Lightweight version for scripts and automation

For a script, runbook, package or scheduled job. Ten minutes; keep the answers in the script's README or header.

| Question | Answer |
|---|---|
| What does it do, and on what scope (how many devices, servers, accounts)? | |
| What identity and privilege does it run with? Could it be lower? | |
| What inputs does it take, and who can influence them (parameters, files, registry, web content, device names)? | |
| What does it download, load or execute, and how is that verified? | |
| What secrets does it need, and how does it get them? | |
| What does it write, where, and who else can write there? | |
| What is the worst outcome if it runs wrongly, or runs something an attacker supplied? | |
| How is it staged and rolled back? | |
| Who can change it, and who can publish it? | |
| What does it log, and where? | |
