# Training

The ISM expects that developers have the cyber security knowledge and skills their tasks require (ISM-2121), and the NSW Cyber Security Policy requires awareness training (3.1). Generic annual awareness training does not meet the first. This page defines role-based learning.

## Learning paths

| Audience | Content | Format | Frequency |
|---|---|---|---|
| **Everyone who changes code** (all archetypes) | The minimum baseline; secrets; safe handling of health data; how to report; AI tool rules | 45-minute module | On joining, then annually |
| **Application and API developers** | OWASP Top 10 in the team's language; authorisation; hands-on labs | Half-day workshop or self-paced labs | On joining, refresh every 2 years |
| **Script and automation authors** (endpoint, infrastructure) | [PowerShell guide](../03-guides/powershell.md); privilege; signing; staged rollout | 90-minute workshop | On joining |
| **Platform and DevOps engineers** | Pipeline security; IaC misconfiguration; supply chain; identity federation | Half-day workshop | On joining, refresh every 2 years |
| **Data and analytics staff** | Data handling; notebooks; package and model risk | 60-minute module | On joining, then annually |
| **Everyone who uses AI tools for work** | Approved tools and the data rule (PD2026_001 §4.4); agent configuration is code; checking suggested packages; prompt injection through files and web pages; what to do with an unowned agent | 30-minute module | On joining, then annually |
| **Teams building AI-enabled systems** | [AI security with MITRE ATLAS](../03-guides/ai-security-with-atlas.md); threat-modelling an AI design; adversarial testing | Half-day workshop | Before the first AI build |
| **Low-code makers** | [Low-code guide](../03-guides/power-platform.md) | 30-minute module | Before building shared apps |
| **Tech leads and architects** | Threat modelling facilitation; risk tiers; exception process | One-day workshop | Once, refresh as standards change |
| **Security champions** | All of the relevant path plus [champion program](security-champions.md) | Ongoing | Monthly |
| **Product owners and managers** | What the standards ask of their teams; how to plan for it | 30-minute briefing | Once |

## Principles

- **Role-relevant.** A PowerShell author should never sit through a cross-site scripting lab.
- **Hands-on over slides.** People remember vulnerabilities they exploited and fixed.
- **Just in time.** Link guidance from tool findings and pull request templates, where the engineer is at the moment of need.
- **Tracked by role.** Completion feeds the [metrics](../07-metrics/README.md).

## Sources to draw on

OWASP Top 10, OWASP Cheat Sheet Series, OWASP Juice Shop and similar deliberately vulnerable applications for labs, vendor learning platforms already licensed **[VERIFY what NSW Health has]**, and internal incident and penetration-test lessons (anonymised).

PD2026_001 §3.4 requires all users to complete assigned mandatory cyber security coursework annually on **My Health Learning**, and requires continuing education. That platform is the natural delivery and tracking channel for the modules above.

**[VERIFY]** whether My Health Learning can assign coursework by a "writes code" role attribute, or whether that attribute needs creating.
