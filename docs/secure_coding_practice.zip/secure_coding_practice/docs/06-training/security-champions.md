# Security champions program

A champion is an engineer inside a team who is the first point of contact for security, with time and support to do it. Champions are how a small central program reaches every team in a federated organisation.

## What a champion does

- Helps the team apply the standards and choose sensible exceptions.
- Triages security tool findings with the team.
- Facilitates or arranges threat modelling.
- Brings the team's friction back to the program.
- Reviews security-relevant pull requests, or finds someone who can.

## What a champion is not

- Not accountable for the team's security; the team lead and system owner are.
- Not a gate. They advise; they do not approve releases alone.
- Not unpaid overtime.

## What the organisation commits

Research on champions programs in large enterprises shows they fail when champions are appointed and then left unsupported. So:

| Commitment | Detail |
|---|---|
| **Time** | About 10% of the champion's week, agreed with their manager in writing |
| **Training** | The role-based path plus threat-modelling facilitation |
| **Access** | A direct channel to the security engineering team with a response-time expectation |
| **Recognition** | Named in the team profile; reflected in performance and development plans |
| **Community** | Monthly community of practice across entities |
| **Rotation** | A 12-month term, renewable, so it is not a life sentence |

## Coverage target

One champion per team for Tier 1 owners; one per group of related teams otherwise. Small LHD teams may share a champion across the local ICT function, supported by an eHealth NSW buddy.

## Selection

Volunteers first. Look for curiosity and credibility with peers over existing security expertise.

## Community of practice

Monthly, one hour:

1. One team shows something they did (10 minutes)
2. One topic from the standards or a recent incident lesson (20 minutes)
3. Friction round: what is not working (20 minutes)
4. Changes coming to standards and tooling (10 minutes)

## Measuring the program

- Teams with a named, trained champion
- Champion retention at 12 months
- Issues and pull requests raised by champions against this repository
- Champion-reported time actually available
