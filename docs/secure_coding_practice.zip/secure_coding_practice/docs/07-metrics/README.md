# Metrics

A small set that shows whether the program is working. Collect automatically wherever possible. Targets are proposals to be set after the Phase 1 baseline.

## Principles

- Measure outcomes and adoption, not activity.
- Report by entity and archetype, never to rank individuals.
- A metric that teams can only improve by gaming it is dropped.

## Core metrics

| # | Metric | Source | Why it matters | Proposed target (12 months) |
|---|---|---|---|---|
| 1 | % of known code assets in approved source control | Inventory | Foundation for everything else | 95% Tier 1–2 |
| 2 | % of repositories meeting the [minimum baseline](../02-standards/README.md#the-minimum-baseline) | Platform APIs | Headline adoption figure | 90% Tier 1, 70% overall |
| 3 | % of repositories using the reference pipeline or equivalent checks | Pipeline scan | Paved road adoption | 80% Tier 1–2 |
| 4 | Secrets detected: blocked at push vs found after commit | Secret scanning | Shows prevention working | Post-commit trend down |
| 5 | Open critical/high vulnerabilities past due, by tier | Scanners, tracker | Real exposure | Zero past due for Tier 1 |
| 6 | Median time to remediate critical/high | Tracker | Responsiveness | Within SDS-11 timeframes |
| 7 | % of Tier 1–2 systems with a current threat model | Repo scan | Design assurance | 100% Tier 1 |
| 8 | % of Tier 1–2 releases with an SBOM | Pipeline artefacts | Supply-chain visibility | 90% |
| 9 | % of people who change code with current role-based training | Learning system | ISM-2121, NSW CSP 3.1 | 90% |
| 10 | Teams with a named, trained champion | Team profiles | Federated reach | 100% Tier 1 owners |
| 11 | Active exceptions: count, age, and by requirement | Exception register | Where standards or paved roads are failing | No expired exceptions |
| 12 | Average maturity score by function | Annual self-assessment | Direction of travel | +0.5 per year |
| 13 | Artefact traceability: sampled releases that can be traced from approved change to verified artefact / releases sampled | Release sampling | Proves what was deployed was what was reviewed | 100% of sampled Tier 1 releases |
| 14 | Recovery evidence: services with a current rollback or recovery rehearsal / services in scope | Team profiles | Clinical availability | 100% Tier 1 |
| 15 | AI register coverage: agents and AI integrations found / those with an owner and a decision | AI register | Shadow AI under control | 100%; no unowned agent active |
| 16 | AI-enabled systems with a current ATLAS threat model and pre-release adversarial test / AI-enabled systems | Repo scan, test reports | AI design assurance | 100% Tier 1 |

State the denominator for every ratio, and record when it changes. PD2026_001 §3.5 requires NSW Health organisations to collect and evaluate metrics on their security measures; this set supplies the software development part.

## Health checks on the program itself

- Findings dismissed as false positive (above 20% means tune the tools)
- Delivery friction: median and 90th-percentile duration of the security checks in the pipeline
- Median time for the program to answer a team's question
- Developer sentiment: one-question pulse each quarter ("Security guidance helps me deliver": agree / neutral / disagree)

## Reporting

| Audience | Frequency | Content |
|---|---|---|
| Teams | Continuous | Own dashboard |
| Working group and champions | Monthly | All metrics by archetype; friction themes |
| Executive cyber governance committee | Quarterly | One page: metrics 2, 5, 9, 11, top three risks, decisions needed |
| NSW CSP annual attestation | Annual | Evidence for requirements mapped in [policy alignment](../00-program/policy-alignment.md) |
