# Examples

Small, runnable, synthetic examples that show a requirement being met and tested. Nothing here contains real data or real system names.

| Example | Shows | Standard |
|---|---|---|
| [python/access_policy.py](python/access_policy.py) and [its tests](python/test_access_policy.py) | A record-level access decision that denies by default, with tests for the denied cases as well as the allowed one | [SDS-09](../docs/02-standards/SDS-09-authentication-authorisation-cryptography.md) R5, [SDS-06](../docs/02-standards/SDS-06-security-testing.md) R7 |
| [service-walkthroughs.md](service-walkthroughs.md) | Three synthetic services to dry-run discovery interviews before meeting real teams | [Discovery](../docs/01-discovery/README.md) |

Run the tests from the repository root with Python 3.10 or newer. No third-party packages are needed.

```sh
python -m unittest discover -s examples/python -p "test_*.py" -v
```

Add an example when a requirement is easier to show than to describe. Keep each one small enough to read in a minute, and include the negative tests.
