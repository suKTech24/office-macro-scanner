"""Synthetic example. The caller supplies trusted identity and resource attributes."""


def can_read_record(
    *,
    user_org: str,
    record_org: str,
    authenticated: bool,
    scopes: frozenset[str],
) -> bool:
    """Allow a read only within the caller's organisation and authorised scope."""
    return bool(
        authenticated
        and user_org
        and user_org == record_org
        and "record:read" in scopes
    )
