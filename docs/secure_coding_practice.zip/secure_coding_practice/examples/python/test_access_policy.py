import unittest

from access_policy import can_read_record


class RecordAccessTests(unittest.TestCase):
    def test_only_authenticated_readers_in_the_same_organisation_have_access(self):
        cases = [
            ("example-a", "example-a", True, {"record:read"}, True),
            ("example-a", "example-b", True, {"record:read"}, False),
            ("example-a", "example-a", False, {"record:read"}, False),
            ("example-a", "example-a", True, {"record:write"}, False),
            ("", "", True, {"record:read"}, False),
        ]
        for user_org, record_org, authenticated, scopes, expected in cases:
            with self.subTest(user_org=user_org, record_org=record_org,
                              authenticated=authenticated, scopes=scopes):
                result = can_read_record(
                    user_org=user_org,
                    record_org=record_org,
                    authenticated=authenticated,
                    scopes=frozenset(scopes),
                )
                self.assertEqual(result, expected)


if __name__ == "__main__":
    unittest.main()
