# Synthetic service walkthroughs

Three invented services for practising the [change walkthrough](../docs/01-discovery/change-walkthrough.md) before meeting real teams. They cover three different delivery mechanisms so you can see how the same questions produce comparable answers.

| Service | The change | Standards in play | Who verifies what |
|---|---|---|---|
| **EX-01 eHealth endpoint package** | The team reviews a PowerShell package, signs the approved artefact, tests it on a lab ring, then promotes it to a broader ring | SDS-01, SDS-02, SDS-07, SDS-15 | Endpoint lead verifies the approved change and the signature. Operations confirms the test ring and proves withdrawal or uninstall before the rollout widens |
| **EX-02 LHD clinical interface** | The team changes results routing from a source system through a shared gateway to a local receiver, using synthetic messages | SDS-05, SDS-06, SDS-07, SDS-10, SDS-12 | The platform team provides gateway configuration evidence (an inherited control). The LHD team owns route validation. A clinical contact confirms handling of delayed and duplicate messages and rehearses downtime reconciliation |
| **EX-03 Specialty network supplier SaaS** | The vendor updates hosted software. Local administrators review tenant configuration and integration permissions | SDS-02, SDS-10, SDS-11, SDS-14 | The supplier owner links the version notice and notification terms. Local operations verifies integration and logging after the update. The product owner confirms an alternative workflow because the vendor cannot roll back |

## Example gap

EX-01 can identify the signed package but cannot trace it to the reviewed source change.

- **Requirement:** SDS-07-R10, and metric 13 (artefact traceability)
- **Action:** add a release record containing source revision, approved change, signed artefact digest and target ring
- **Owner:** endpoint release owner
- **Accept when:** a second operator traces one synthetic release end to end using only the record

The same gap is the example row in the [gap backlog template](../docs/01-discovery/gap-backlog-template.csv).
