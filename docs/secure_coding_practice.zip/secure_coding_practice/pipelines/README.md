# Reference pipelines

Starting points that implement the automated checks in [SDS-06](../docs/02-standards/SDS-06-security-testing.md), [SDS-03](../docs/02-standards/SDS-03-dependencies-and-supply-chain.md) and [SDS-13](../docs/02-standards/SDS-13-ai-assisted-development.md).

> **Samples, not yet run in an NSW Health environment.** Tools named here are widely used open-source options chosen so the samples run without licences. Replace them with whatever NSW Health already licenses once discovery confirms it (decision record in `decisions/`).

On GitHub, prefer the organisation's **workflow templates** in the `.github` repository (CodeQL, dependency review, IaC scan, PowerShell lint), and the AI configuration check that ships in the [template repository](../template-repo/README.md). The GitHub sample here shows the same checks together in one file.

| Platform | File |
|---|---|
| GitHub Actions | [github-actions/secure-ci.yml](github-actions/secure-ci.yml) |
| Azure DevOps | [azure-devops/secure-ci.yml](azure-devops/secure-ci.yml) |

## Pinning

Every action is pinned to a full commit SHA and every container image to a digest. Tool versions are exact, and were chosen on 2026-11-13 to be at least two weeks old ([SDS-07](../docs/02-standards/SDS-07-build-and-deployment-pipelines.md) R6).

Version tags such as `@v2`, `@master` or `:latest` are not safe. In March 2026 attackers force-pushed almost all release tags of `aquasecurity/trivy-action` to a credential stealer (CVE-2026-33634), so every pipeline that referenced a tag ran it. Trivy has been removed from these samples. Keep pins current through Dependabot or reviewed pull requests, never by switching back to tags.

## What the pipeline checks

| Check | GitHub sample | Azure DevOps sample | Standard |
|---|---|---|---|
| Secret scanning | GitHub secret scanning with push protection (organisation setting, not a job) | Gitleaks | SDS-02 R2 |
| Dependency vulnerabilities | Dependency review (pull requests) | OSV-Scanner | SDS-03 R3 |
| Static analysis | Semgrep (or the CodeQL workflow template) | Semgrep | SDS-06 R1 |
| IaC and configuration | Checkov | Checkov | SDS-08 R2 |
| PowerShell analysis | PSScriptAnalyzer | PSScriptAnalyzer | SDS-15 R11 |
| AI configuration | `scripts/check_ai_config.py` | `scripts/check_ai_config.py` | SDS-13 R15, R16 |
| SBOM | Syft via `anchore/sbom-action` (CycloneDX) | Syft (CycloneDX) | SDS-03 R7 |

## Rollout order

1. Run in report-only mode (`continue-on-error` / `continueOnError`) for two to four weeks.
2. Tune rules and record suppressions in code.
3. Enforce blocking on new critical and high findings for Tier 1–2.
4. Move the checks into shared templates and organisation rulesets so teams reference one maintained copy instead of copying the file.

## Not covered by these samples

Build, unit test, signing, container image build and deployment are stack-specific. Deployment templates with federated identity and environment approvals are a Phase 3 deliverable. Adversarial testing of AI-enabled systems ([SDS-17](../docs/02-standards/SDS-17-ai-enabled-systems.md) R17) runs before release, not on every pull request.
