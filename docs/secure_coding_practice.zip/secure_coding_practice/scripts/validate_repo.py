"""Check this repository's Markdown links and that the standards index is complete.

Run from anywhere:  python scripts/validate_repo.py
No third-party packages are required.
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FENCED_BLOCK = re.compile(r"```.*?```", re.DOTALL)
LINK = re.compile(r"\]\(([^)\s]+)\)")


def broken_links() -> list[str]:
    errors = []
    for document in ROOT.rglob("*.md"):
        text = FENCED_BLOCK.sub("", document.read_text(encoding="utf-8"))
        for target in LINK.findall(text):
            if target.startswith(("https://", "http://", "mailto:", "#")):
                continue
            path = target.split("#", 1)[0]
            if not (document.parent / path).exists():
                errors.append(f"{document.relative_to(ROOT)}: missing {target}")
    return errors


def unindexed_standards() -> list[str]:
    standards = ROOT / "docs" / "02-standards"
    index = (standards / "README.md").read_text(encoding="utf-8")
    return [
        f"docs/02-standards/README.md: {file.name} is not listed in the index"
        for file in sorted(standards.glob("SDS-*.md"))
        if file.name not in index
    ]


def main() -> int:
    errors = broken_links() + unindexed_standards()
    if errors:
        print("\n".join(errors))
        return 1
    count = len(list((ROOT / "docs" / "02-standards").glob("SDS-*.md")))
    print(f"Links valid; {count} standards indexed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
