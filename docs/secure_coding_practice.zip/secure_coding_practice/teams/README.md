# Teams

One folder per onboarded team, grouped by entity. This is how the statewide baseline ties back to each part of NSW Health.

```text
teams/
├── _template/                      Copy this to start
│   ├── profile.md
│   └── onboarding-checklist.md
├── ehealth-nsw/
│   └── <team>/
├── lhd-<name>/                     For example lhd-western-sydney/
│   ├── local-profile.md            Optional: entity-wide additions (stricter rules, local approvers, local tooling)
│   └── <team>/
├── schn/                           Sydney Children's Hospitals Network
├── justice-health/
├── cancer-institute-nsw/
└── nsw-health-pathology/
```

Folders for entities are created as they onboard; the names above are examples.

## What goes here

- `profile.md` — the reviewed [team profile](../docs/01-discovery/team-profile-template.md).
- `onboarding-checklist.md` — progress against the baseline.
- `local-profile.md` (per entity, optional) — local additions. An entity may tighten a requirement or name local approvers. It may not relax a MUST; that needs an [exception](../docs/05-templates/exception-request.md).

## What does not go here

Vulnerabilities, findings, credentials, network details, or anything that describes how to attack a system. Those live in the restricted risk and vulnerability systems.

## Onboarding steps

1. Open a "Team onboarding" issue.
2. Discovery session with the program (60–90 minutes).
3. Copy `_template/` to `teams/<entity>/<team>/` and complete the profile.
4. Work through the onboarding checklist with your champion.
5. Pull request; program reviews; merged.
6. Re-attest annually.
