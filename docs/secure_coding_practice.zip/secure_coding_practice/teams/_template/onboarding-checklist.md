# Onboarding checklist — `<team name>`

| Entity | Team | Champion | Started | Baseline met |
|---|---|---|---|---|
| | | | | |

## 1. Get set up

- [ ] Discovery session held; [profile](profile.md) completed and reviewed by the team
- [ ] Archetype(s) confirmed: ____
- [ ] Security champion named, time agreed with their manager
- [ ] Each system has an owner and a risk tier

## 2. Minimum baseline

- [ ] All code, scripts and configuration in approved source control
- [ ] Access by corporate identity with MFA; no shared accounts; access granted to groups
- [ ] Default branch protected; second-person review required
- [ ] Secret scanning with push protection on; existing secrets found, rotated and removed
- [ ] Dependencies from approved sources; dependency scanning on
- [ ] Production deployment by pipeline or controlled tool
- [ ] No real patient or staff data in development or test
- [ ] Each repository created from, or aligned to, the template repository: `README` with owner and tier, `CODEOWNERS`, Copilot files
- [ ] Vulnerability reporting route in place (organisation default `SECURITY.md`, or the repository's own)
- [ ] Vulnerability backlog exists with owners and due dates
- [ ] Everyone who changes code has completed the role-based training

## 3. Tier and archetype requirements

- [ ] Applicable standards identified from the [archetype matrix](../../docs/04-team-archetypes/README.md#applicability-matrix)
- [ ] Reference pipeline (or equivalent checks) running on every pull request
- [ ] Threat model done for Tier 1–2 systems
- [ ] Security logging reaching central monitoring for Tier 1–2
- [ ] SBOM generated per release for Tier 1–2
- [ ] Signing in place for scripts and artefacts where required

## 4. Gaps

| Requirement | Gap | Plan or exception reference | Due |
|---|---|---|---|
| | | | |

## 5. Sign-off

| Role | Name | Date |
|---|---|---|
| Team lead | | |
| Security champion | | |
| Program | | |

Next attestation due: ____
