# Team profile — `<team name>`

Copy the contents of [docs/01-discovery/team-profile-template.md](../../docs/01-discovery/team-profile-template.md) into this file and complete it with the team.

Do not record vulnerabilities, credentials or system weaknesses here.
