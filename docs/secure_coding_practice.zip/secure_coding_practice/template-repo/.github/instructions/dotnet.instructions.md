---
applyTo: "**/*.cs,**/*.csproj,**/*.cshtml,**/*.razor"
---

# .NET rules (NSW Health SDS-04, SDS-09)

- Use EF Core LINQ or parameterised commands. Never concatenate input into SQL, and never pass concatenated strings to `FromSqlRaw` or `ExecuteSqlRaw`.
- Keep secrets out of `appsettings.json` and source. Use user secrets locally and a vault configuration provider with managed identity when deployed. Prefer identity-based connection strings with no password.
- Authenticate through the organisation's identity provider with OpenID Connect. Require authorisation by default with a fallback policy, and check access to the specific record with resource-based authorisation.
- Bind requests to dedicated request models with validation, not to entities.
- Do not use `BinaryFormatter`, `NetDataContractSerializer`, `LosFormatter`, or Newtonsoft `TypeNameHandling` other than `None`.
- Use `RandomNumberGenerator` for tokens, not `System.Random`. Do not use MD5, SHA-1 or DES for security.
- Do not disable certificate validation in `HttpClientHandler`.
- Set `DtdProcessing = Prohibit` when reading untrusted XML.
- Pass process arguments with `ProcessStartInfo.ArgumentList`, not a concatenated string.
- Do not use `Html.Raw` on untrusted data. Keep antiforgery validation on. Configure CORS with explicit origins.
- Log with `ILogger` message templates, without secrets or health information. Return problem details without stack traces.
- Enable nullable reference types, analysers and NuGet auditing, and commit `packages.lock.json`.
