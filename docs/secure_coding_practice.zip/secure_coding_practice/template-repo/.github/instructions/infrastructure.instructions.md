---
applyTo: "**/*.tf,**/*.bicep,**/Dockerfile,**/*.yml,**/*.yaml"
---

# Infrastructure and pipeline rules (NSW Health SDS-07, SDS-08)

## Infrastructure as code

- Private by default: no public network access, public IPs or anonymous access unless the request explicitly needs it. If it does, say that the threat model must record it.
- Enable encryption at rest, require TLS 1.2 or later, and enable diagnostic logging on every resource.
- Scope role assignments to the resource. No wildcard actions and no owner-level roles for workloads. Use managed identities instead of keys or passwords.
- Never put secrets in variables, outputs, parameter files or state. Mark sensitive values as sensitive and reference the vault.
- Pin provider, module and image versions. Use the organisation's approved modules where they exist.
- Add tags for owner, system, risk tier, data classification and environment.

## Containers

- Use approved base images, run as a non-root user, and do not copy secrets or use them as build arguments.

## Pipelines

- Set the minimum `permissions` on every workflow and job.
- Pin third-party actions and tasks to a full commit SHA or digest.
- Authenticate to cloud targets with workload identity federation, not stored long-lived secrets.
- Never expose secrets to jobs triggered by forks or other untrusted input.
- Keep production deployment behind an environment with approval from someone other than the author.
- Do not add `continue-on-error` to a security check, or remove one, without saying so clearly in your response.
