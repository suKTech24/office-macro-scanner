---
applyTo: "**/*.ps1,**/*.psm1,**/*.psd1"
---

# PowerShell rules (NSW Health SDS-15)

- Start scripts with a comment header giving purpose, owner, the context it runs in (SYSTEM, user, service account), risk tier and repository, then `Set-StrictMode -Version Latest` and `$ErrorActionPreference = 'Stop'`.
- Take credentials as `[PSCredential]`, never as string parameters. Do not use `ConvertTo-SecureString -AsPlainText` with a literal. Prefer a managed identity or a vault lookup at run time.
- Do not use `Invoke-Expression`, `iex`, or command strings built from input. Call cmdlets with named parameters and splatting.
- Validate parameters with `[ValidateSet()]`, `[ValidatePattern()]` or `[ValidateRange()]`. Use `-LiteralPath` for paths that come from input.
- Do not download and run content. Install modules from the approved internal repository with `-RequiredVersion`. Verify installers with `Get-FileHash` and `Get-AuthenticodeSignature` before use.
- Do not weaken the device: no `Set-ExecutionPolicy Bypass`, no `-SkipCertificateCheck`, no disabling of Defender, firewall, UAC or logging, no broad antivirus exclusions.
- Run with the least privilege that works. Do not write files from a SYSTEM-context script into user-writable locations.
- Wrap work in `try`/`catch`/`finally`, exit non-zero on failure, log start, target and outcome, and remove temporary files.
- Never write secrets with `Write-Host`, `Write-Verbose`, `Write-Output` or transcripts.
- Code must pass PSScriptAnalyzer with no errors. Suggest Pester tests for anything reused or deployed broadly.
- For anything deployed to many devices, mention signing, staged rings and a rollback or uninstall step.
