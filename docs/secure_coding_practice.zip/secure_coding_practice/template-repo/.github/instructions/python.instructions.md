---
applyTo: "**/*.py,**/*.ipynb"
---

# Python rules (NSW Health SDS-04)

- Use parameterised queries. Never format SQL with f-strings, `%` or `+`.
- Call `subprocess` with a list of arguments. Do not use `shell=True` with any variable input.
- Do not use `pickle`, `marshal`, `shelve` or `joblib.load` on data you did not create. Use `yaml.safe_load`, never `yaml.load`. Use `defusedxml` for untrusted XML.
- Do not use `eval` or `exec` on input. Use `ast.literal_eval` for literals.
- Use `secrets` for tokens, not `random`. Do not use MD5 or SHA-1 for security purposes.
- Never pass `verify=False` to HTTP clients. Always set a `timeout`.
- Use `tempfile.NamedTemporaryFile` or `mkstemp`, not `mktemp`. Extract archives with `filter="data"`.
- Read secrets from the vault or injected environment at run time. Never commit `.env` files or put credentials in notebook cells.
- Validate request bodies with a schema (Pydantic or serializers). Authorise per object on the server.
- Log with the `logging` module using parameters, without secrets or health information.
- In notebooks, do not embed data extracts, and remind the author to strip outputs before committing.
- Loading a model file can execute code. Prefer safe formats and trusted, verified sources.
- Pin dependencies with a lock file, and do not suggest packages you are not sure exist.
