---
name: repo-security-setup
description: Check a repository against the NSW Health minimum secure development baseline and add the missing files. Use when setting up a new repository, onboarding an existing one, or when asked whether a repository meets the baseline.
---

# Repository security setup

Bring a repository up to the minimum baseline. Add files; do not change platform settings, rotate credentials or rewrite history yourself. Report those as actions for a person.

## What comes from where

- **Organisation `.github` repository** (applies automatically, do not copy): `SECURITY.md`, the pull request template, issue templates, and workflow templates offered under Actions → New workflow.
- **Template repository** (each repository needs its own copy): `README` with owner and risk tier, `.github/CODEOWNERS`, `.github/dependabot.yml`, `.gitignore`, Copilot instructions and skills, `scripts/check_ai_config.py` and its workflow.

Only add a repository `SECURITY.md` if the system needs specific security detail. It replaces the organisation default entirely, so it must repeat the reporting channels.

## Steps

1. **Inspect.** List what exists from both lists above, plus lock files and pipeline definitions.
2. **Look for problems already in the repository.**
   - Files that should not be committed: `.env`, key and certificate files, state files, data extracts, notebook outputs.
   - Anything that looks like a credential, including in MCP configuration. If found, do not print the value. Tell the developer it must be treated as compromised and rotated first, then reported through the security incident channel in `SECURITY.md`, before any history clean-up.
   - Anything that looks like real patient or staff data.
   - AI use: run `python scripts/check_ai_config.py` if present, and list the AI SDKs, endpoints, model files and MCP servers it reports so they can be matched to the AI register.
3. **Add what is missing**, asking for facts you cannot infer (owner team, system owner, risk tier, data handled):
   - `README` section stating owner team, system owner, risk tier and data classification.
   - `.github/CODEOWNERS` with the owning group, and a stricter owner for `.github/`, agent instruction files and pipeline files.
   - `.gitignore` entries for secrets, state, build output, local environment files and local AI tool settings.
   - The AI configuration check script and workflow, if the repository does not have them.
   - Dependency update configuration, and a lock file if the ecosystem supports one.
   - Security checks from the organisation workflow templates that match the repository's languages (CodeQL, dependency review, IaC scan, PowerShell lint). Name them for the developer to add from Actions → New workflow, starting in report-only mode.
4. **Report** using the format below.

## Report format

A table of the ten baseline items with a status of met, added now, or needs a person:

1. All code, scripts and configuration are in approved source control
2. Access is by corporate identity with MFA; no shared accounts
3. Default branch protected; second-person review required
4. No secrets in code; secret scanning with push protection on
5. Dependencies from approved sources and scanned
6. Production deployment by pipeline, not from a workstation
7. No real patient or staff data in development or test
8. Owner and risk tier in the `README`; vulnerability reporting route (organisation default `SECURITY.md` counts)
9. Vulnerabilities tracked with owners and due dates
10. Contributors have completed secure development training

Items 2, 3, part of 4, 6, 9 and 10 cannot be verified from the files. List them as "needs a person" with the exact setting or record to check.

Then list any AI use found, and whether each item is on the approved list or needs registering.

Finish with the files you created or changed, so the developer can review them in a pull request.
