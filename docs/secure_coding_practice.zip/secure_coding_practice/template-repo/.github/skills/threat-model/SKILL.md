---
name: threat-model
description: Create or update a threat model for an NSW Health system, service, script or automation. Use when starting a new system, making a significant change, or when asked what could go wrong with a design.
---

# Threat model

Produce a draft for the team to review and own. A threat model written only by an assistant is a starting point; the team must confirm the diagram and decide each threat.

## Steps

1. **Understand the system.** Read the README, entry points, configuration, infrastructure and pipeline files. Identify users, processes, data stores, external systems, identities and where trust changes.
2. **Ask what you cannot read from the code.** Risk tier, what data it holds, who uses it, whether failure could affect patient care, and what privilege it runs with. Do not guess these.
3. **Choose the format.** Use the short form for a script, runbook, package or scheduled job. Use the full form for applications, APIs, integrations and platforms.
4. **Write the file** to `docs/security/threat-model.md`, or update the existing one, keeping earlier decisions.

## Full form

1. **What are we working on?** Purpose in one paragraph, a Mermaid data-flow diagram with trust boundaries, the assets worth protecting, and assumptions.
2. **What can go wrong?** For each element and data flow, consider spoofing, tampering, repudiation, information disclosure, denial of service and elevation of privilege. Also ask the health questions: could this show the wrong patient's data, could a clinician act on altered, stale or missing information, and what happens to care if this is down for four hours?
3. **What are we going to do about it?** A table with: ID, element or flow, threat, category, proposed risk level, decision (mitigate, accept, avoid, transfer), control, tracker reference, owner. Leave decision and owner blank for the team; propose, do not decide.
4. **Did we do a good job?** A checklist: diagram matches deployment, every boundary crossing considered, every threat has a decision and owner, mitigations are in the backlog.

## AI components

If the system calls an AI model, retrieves content for one, or runs an agent, add an "AI components" section using MITRE ATLAS.

1. Ask what you cannot read from the code: whether output could inform a clinical decision, the NSW AI Assessment Framework reference, and which actions need human approval.
2. List every source of text the model reads that NSW Health did not write, and every tool it can call with whose permissions.
3. Consider at least these ATLAS techniques, and add others that fit the design:
   - all AI systems: AML.T0051 LLM Prompt Injection (direct and indirect), AML.T0054 LLM Jailbreak, AML.T0069.002 System Prompt, AML.T0077 LLM Response Rendering, AML.T0034 Cost Harvesting
   - retrieval over documents: AML.T0070 RAG Poisoning, AML.T0066 Retrieval Content Crafting, AML.T0085.000 Data from AI Services: RAG Databases
   - agents with tools: AML.T0053 AI Agent Tool Invocation, AML.T0086 Exfiltration via AI Agent Tool Invocation, AML.T0080 AI Agent Context Poisoning, AML.T0110 AI Agent Tool Poisoning
   - models and training: AML.T0010.003 Supply Chain Compromise: Model Repository, AML.T0011.000 Unsafe AI Artifacts, AML.T0020 Training Data Poisoning
4. For each, record whether the design prevents it, the control or ATLAS mitigation to add (for example AML.M0029 Human In-the-Loop, AML.M0030 Restrict AI Agent Tool Invocation on Untrusted Data), and the test that will prove it.

ATLAS changes monthly. Say that the technique list should be checked against the current release at atlas.mitre.org, and never invent a technique ID: if unsure, describe the attack in words.

## Short form for scripts and automation

Answer each in one or two lines:

- What does it do, and on how many devices, servers or accounts?
- What identity and privilege does it run with, and could it be lower?
- What inputs does it take, and who can influence them?
- What does it download, load or execute, and how is that verified?
- What secrets does it need, and how does it get them?
- What does it write, where, and who else can write there?
- What is the worst outcome if it runs wrongly or runs something an attacker supplied?
- How is it staged and rolled back?
- Who can change it, and who can publish it?
- What does it log, and where?

## Rules

- Mark anything you inferred rather than read as an assumption.
- Do not write exploit detail for unfixed weaknesses into the file. Describe the threat and reference a tracker item.
- Formal risk ratings use the NSW Health Risk Matrix and are the team's to assign.
- Say when the change looks significant enough to need security architecture review: a new external interface, a change to authentication or authorisation, a new category of data, a new hosting or trust boundary, an AI component (including a change of model, provider, prompts, tools or retrieval sources), or a change in who can deploy.
