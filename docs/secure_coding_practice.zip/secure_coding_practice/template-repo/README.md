# Repository name

> **After creating your repository from this template:** fill in the table below, replace the team in `.github/CODEOWNERS`, delete the instruction files in `.github/instructions/` for languages you do not use, and add the security workflows for your languages from **Actions → New workflow** (look for the organisation's section). Then delete this note.

One or two sentences on what this system does and who uses it.

## Ownership and risk

| | |
|---|---|
| Owner team | |
| System owner | |
| Security champion | |
| Risk tier | 1 / 2 / 3 (see the NSW Health secure development operating model) |
| Data classification | for example: health information, personal information, official |
| Uses AI models or agents | No / Yes: list them, and link the AI register entry |

## Security

- To report a vulnerability or a suspected incident, follow `SECURITY.md`. If this repository has no `SECURITY.md` of its own, GitHub shows the organisation default.
- Threat model: `docs/security/threat-model.md` (required for Tier 1 and Tier 2).
- Secrets are never stored in this repository. Read them at run time from the approved vault.
- This repository includes GitHub Copilot instructions and skills (`.github/`) that apply the NSW Health secure development standards. They guide the assistant; the pipeline checks and human review still decide what merges.

## Getting started

How to build, test and run locally.
