"""AI configuration check (NSW Health SDS-13 and SDS-17).

Deterministic checks for what AI tools read and use in this repository.

Fails (exit code 1) on:
  * hidden or direction-changing Unicode characters in AI agent configuration
    files (instructions, prompts, skills, agent settings). Invisible characters
    can carry instructions a human reviewer cannot see.
    MITRE ATLAS AML.T0081 Modify AI Agent Configuration, AML.T0068 LLM Prompt
    Obfuscation.
  * credentials written in plain text in MCP server configuration.
    ATLAS AML.T0083 Credentials from AI Agent Configuration.

Reports, without failing:
  * AI SDKs declared in dependency manifests, AI service endpoints referenced in
    code or configuration, and model files. Use this to keep the AI bill of
    materials current and to find AI use nobody has registered (shadow AI).
    ATLAS AML.M0023 Maintain an AI Bill of Materials.
  * model files in formats that can run code when loaded (pickle based).
    ATLAS AML.T0011.000 Unsafe AI Artifacts.
  * MCP servers configured in the repository, to confirm against the approved
    list. ATLAS AML.T0010.005 Supply Chain Compromise: AI Agent Tool.

Usage:  python scripts/check_ai_config.py [--root PATH]
Python 3.10+, standard library only.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

SKIP_DIRS = {
    ".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build",
    ".terraform", ".tox", ".mypy_cache", ".pytest_cache", "bin", "obj",
}
SELF_NAMES = {"check_ai_config.py", "test_check_ai_config.py"}
MAX_TEXT_BYTES = 2_000_000

# Files that AI coding agents read as instructions or configuration.
AGENT_CONFIG_NAMES = {
    "AGENTS.md", "CLAUDE.md", "GEMINI.md", "SKILL.md", "copilot-instructions.md",
    ".cursorrules", ".windsurfrules", ".clinerules", ".aider.conf.yml",
}
AGENT_CONFIG_SUFFIXES = (
    ".instructions.md", ".prompt.md", ".chatmode.md", ".agent.md",
)
AGENT_CONFIG_DIRS = (
    ".github/instructions", ".github/prompts", ".github/skills", ".github/agents",
    ".github/chatmodes", ".cursor/rules", ".claude", ".gemini", ".windsurf",
)
MCP_CONFIG_NAMES = {"mcp.json", ".mcp.json"}

# Invisible or direction-changing characters. A byte order mark at the very
# start of a file is allowed.
HIDDEN_CHARS = {
    **{cp: "bidirectional control" for cp in range(0x202A, 0x202F)},
    **{cp: "bidirectional isolate" for cp in range(0x2066, 0x206A)},
    0x200B: "zero width space", 0x200C: "zero width non-joiner",
    0x200D: "zero width joiner", 0x2060: "word joiner", 0xFEFF: "zero width no-break space",
    0x00AD: "soft hyphen", 0x180E: "Mongolian vowel separator",
}
TAG_RANGE = range(0xE0000, 0xE0080)  # Unicode tag characters: invisible ASCII
VARIATION_SELECTORS_SUPPLEMENT = range(0xE0100, 0xE01F0)

SECRET_WORDS = {
    "token", "secret", "password", "passwd", "pwd", "apikey", "authorization", "auth",
    "bearer", "credential", "credentials", "pat", "privatekey", "clientsecret",
}
WORD = re.compile(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+")
SCHEME = re.compile(r"^\s*(Bearer|Basic|Token)\s+", re.I)
REFERENCE = re.compile(r"^\s*(\$\{[^}]+\}|\$[A-Za-z_][A-Za-z0-9_]*|%[A-Za-z_][A-Za-z0-9_]*%|<[^>]+>|\*+|)\s*$")


def is_secret_key(key: str) -> bool:
    """True if a configuration key name looks like it holds a credential."""
    words = [w.lower() for w in WORD.findall(key)]
    joined_pairs = {a + b for a, b in zip(words, words[1:])}
    return bool((set(words) | joined_pairs) & SECRET_WORDS)


def is_reference(value: str) -> bool:
    """True if a value points to a secret held elsewhere rather than containing it."""
    return bool(REFERENCE.match(SCHEME.sub("", value)))

AI_PACKAGES = {
    "pypi": {
        "openai", "anthropic", "google-genai", "google-generativeai", "google-cloud-aiplatform",
        "vertexai", "mistralai", "cohere", "groq", "ollama", "litellm", "langchain",
        "langchain-core", "langchain-community", "langchain-openai", "langchain-anthropic",
        "langgraph", "llama-index", "llama-index-core", "llama-cpp-python", "transformers",
        "huggingface-hub", "sentence-transformers", "torch", "tensorflow", "keras", "onnxruntime",
        "vllm", "crewai", "autogen-agentchat", "pyautogen", "semantic-kernel", "mcp", "fastmcp",
        "snowflake-ml-python", "azure-ai-inference", "azure-ai-projects", "boto3-bedrock",
        "dspy", "instructor", "pydantic-ai",
    },
    "npm": {
        "openai", "@anthropic-ai/sdk", "@google/genai", "@google/generative-ai", "@mistralai/mistralai",
        "cohere-ai", "groq-sdk", "ollama", "ai", "langchain", "@langchain/core", "@langchain/openai",
        "@langchain/anthropic", "llamaindex", "@modelcontextprotocol/sdk", "@aws-sdk/client-bedrock-runtime",
        "@azure/openai", "@azure-rest/ai-inference", "@huggingface/inference", "@xenova/transformers",
        "@openai/agents",
    },
    "nuget": {
        "azure.ai.openai", "openai", "anthropic", "microsoft.semantickernel", "microsoft.extensions.ai",
        "microsoft.extensions.ai.openai", "ollamasharp", "modelcontextprotocol", "azure.ai.inference",
        "awssdk.bedrockruntime", "google.cloud.aiplatform.v1",
    },
}
AI_ENDPOINTS = {
    "api.openai.com": "OpenAI", "openai.azure.com": "Azure OpenAI",
    "cognitiveservices.azure.com": "Azure AI services", "services.ai.azure.com": "Azure AI Foundry",
    "api.anthropic.com": "Anthropic", "generativelanguage.googleapis.com": "Google Gemini",
    "aiplatform.googleapis.com": "Google Vertex AI", "bedrock-runtime": "Amazon Bedrock",
    "api.mistral.ai": "Mistral", "api.cohere.com": "Cohere", "api.cohere.ai": "Cohere",
    "api.groq.com": "Groq", "api.perplexity.ai": "Perplexity", "api.x.ai": "xAI",
    "api.deepseek.com": "DeepSeek", "openrouter.ai": "OpenRouter", "api-inference.huggingface.co": "Hugging Face",
    "router.huggingface.co": "Hugging Face", "api.together.xyz": "Together AI",
    "localhost:11434": "Ollama (local)", "127.0.0.1:11434": "Ollama (local)",
    "snowflakecomputing.com/api/v2/cortex": "Snowflake Cortex",
}
PICKLE_MODEL_SUFFIXES = {".pkl", ".pickle", ".pt", ".pth", ".joblib", ".ckpt", ".npy"}
OTHER_MODEL_SUFFIXES = {".safetensors", ".onnx", ".gguf", ".h5", ".keras", ".tflite", ".mlmodel"}
TEXT_SUFFIXES = {
    ".py", ".ipynb", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".cs", ".java", ".kt", ".go",
    ".ps1", ".psm1", ".sh", ".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".env.example",
    ".config", ".tf", ".bicep", ".sql", ".md", ".txt", ".xml", ".csproj", ".fsproj", ".vbproj", ".props",
}


@dataclass
class Report:
    failures: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    inventory: dict[str, set[str]] = field(default_factory=dict)

    def note(self, category: str, item: str) -> None:
        self.inventory.setdefault(category, set()).add(item)


def iter_files(root: Path):
    for path in root.rglob("*"):
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts[:-1]):
            continue
        if path.is_file() and path.name not in SELF_NAMES:
            yield path


def rel(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def is_agent_config(path: Path, root: Path) -> bool:
    r = rel(path, root)
    return (
        path.name in AGENT_CONFIG_NAMES
        or path.name.endswith(AGENT_CONFIG_SUFFIXES)
        or any(r == d or r.startswith(d + "/") for d in AGENT_CONFIG_DIRS)
    )


def is_mcp_config(path: Path, root: Path) -> bool:
    return path.name in MCP_CONFIG_NAMES or rel(path, root).endswith((".vscode/mcp.json", ".cursor/mcp.json"))


def read_text(path: Path) -> str | None:
    try:
        if path.stat().st_size > MAX_TEXT_BYTES:
            return None
        return path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return None


def hidden_char_name(cp: int) -> str | None:
    if cp in HIDDEN_CHARS:
        return HIDDEN_CHARS[cp]
    if cp in TAG_RANGE:
        return "Unicode tag character"
    if cp in VARIATION_SELECTORS_SUPPLEMENT:
        return "variation selector"
    return None


def check_hidden_characters(path: Path, text: str, root: Path, report: Report) -> None:
    for line_no, line in enumerate(text.splitlines(), start=1):
        for col, ch in enumerate(line, start=1):
            if line_no == 1 and col == 1 and ch == "﻿":
                continue
            name = hidden_char_name(ord(ch))
            if name:
                report.failures.append(
                    f"{rel(path, root)}:{line_no}:{col}: hidden character U+{ord(ch):04X} ({name}) "
                    "in AI agent configuration. Remove it, then review the file for instructions you could not see."
                )


def walk_json(node, trail=()):
    if isinstance(node, dict):
        for key, value in node.items():
            yield from walk_json(value, trail + (str(key),))
    elif isinstance(node, list):
        for i, value in enumerate(node):
            yield from walk_json(value, trail + (str(i),))
    else:
        yield trail, node


def check_mcp_config(path: Path, text: str, root: Path, report: Report) -> None:
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        report.warnings.append(f"{rel(path, root)}: MCP configuration is not plain JSON; review it by hand.")
        return
    servers = {}
    if isinstance(data, dict):
        servers = data.get("servers") or data.get("mcpServers") or {}
    if isinstance(servers, dict):
        for name, cfg in servers.items():
            target = ""
            if isinstance(cfg, dict):
                target = cfg.get("url") or " ".join([str(cfg.get("command", ""))] + [str(a) for a in cfg.get("args", [])])
            report.note("MCP servers", f"{name}: {target.strip()} ({rel(path, root)})")
    for trail, value in walk_json(data):
        if not isinstance(value, str) or not trail:
            continue
        key = trail[-1]
        literal_secret = is_secret_key(key) and not is_reference(value)
        literal_scheme = bool(SCHEME.match(value)) and not is_reference(value)
        if literal_secret or literal_scheme:
            report.failures.append(
                f"{rel(path, root)}: '{'.'.join(trail)}' holds a literal credential. "
                "Use an input variable or environment reference instead, and rotate the exposed value."
            )


def requirement_names(text: str) -> set[str]:
    names = set()
    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        if not line or line.startswith(("-", "--")):
            continue
        m = re.match(r"([A-Za-z0-9][A-Za-z0-9._-]*)", line)
        if m:
            names.add(m.group(1).lower().replace("_", "-"))
    return names


def pyproject_names(text: str) -> set[str]:
    return {m.lower().replace("_", "-") for m in re.findall(r'["\']([A-Za-z0-9][A-Za-z0-9._-]*)\s*(?:\[[^\]]*\])?\s*[<>=!~;"\']', text)}


def inventory_manifest(path: Path, text: str, root: Path, report: Report) -> None:
    name = path.name.lower()
    found: set[str] = set()
    if name.startswith("requirements") and name.endswith(".txt"):
        found = requirement_names(text) & AI_PACKAGES["pypi"]
    elif name == "pyproject.toml":
        found = pyproject_names(text) & AI_PACKAGES["pypi"]
    elif name == "package.json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return
        deps = set()
        for section in ("dependencies", "devDependencies", "optionalDependencies", "peerDependencies"):
            deps |= set((data.get(section) or {}).keys())
        found = deps & AI_PACKAGES["npm"]
    elif name.endswith(".csproj") or name in {"packages.config", "directory.packages.props"}:
        refs = {m.lower() for m in re.findall(r'(?:Include|id)="([^"]+)"', text)}
        found = refs & AI_PACKAGES["nuget"]
    for pkg in sorted(found):
        report.note("AI SDKs and frameworks", f"{pkg} ({rel(path, root)})")


def inventory_endpoints(path: Path, text: str, root: Path, report: Report) -> None:
    lowered = text.lower()
    for host, provider in AI_ENDPOINTS.items():
        if host in lowered:
            report.note("AI service endpoints", f"{provider} [{host}] ({rel(path, root)})")


def check(root: Path) -> Report:
    report = Report()
    for path in iter_files(root):
        suffix = path.suffix.lower()
        if suffix in PICKLE_MODEL_SUFFIXES:
            report.warnings.append(
                f"{rel(path, root)}: pickle-based model or data file. Loading it can run code. "
                "Prefer safetensors or ONNX, and load only verified files."
            )
            report.note("Model files", rel(path, root))
            continue
        if suffix in OTHER_MODEL_SUFFIXES:
            report.note("Model files", rel(path, root))
            continue
        agent_cfg = is_agent_config(path, root)
        mcp_cfg = is_mcp_config(path, root)
        is_text = agent_cfg or mcp_cfg or suffix in TEXT_SUFFIXES or path.name in {"Dockerfile", ".env.example"}
        if not is_text:
            continue
        text = read_text(path)
        if text is None:
            continue
        if agent_cfg:
            report.note("AI agent configuration files", rel(path, root))
            check_hidden_characters(path, text, root, report)
        if mcp_cfg:
            check_hidden_characters(path, text, root, report)
            check_mcp_config(path, text, root, report)
        inventory_manifest(path, text, root, report)
        if suffix != ".md":
            inventory_endpoints(path, text, root, report)
    if report.inventory.get("AI agent configuration files") and not any(
        (root / p).is_file() for p in ("CODEOWNERS", ".github/CODEOWNERS", "docs/CODEOWNERS")
    ):
        report.warnings.append(
            "AI agent configuration files exist but there is no CODEOWNERS file. "
            "Changes to them change how AI tools behave and should need an owner's review."
        )
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--root", default=".", help="repository root to scan (default: current directory)")
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()
    report = check(root)

    if report.inventory:
        print("AI inventory (keep the AI bill of materials and the AI register current):")
        for category in sorted(report.inventory):
            print(f"  {category}:")
            for item in sorted(report.inventory[category]):
                print(f"    - {item}")
    else:
        print("AI inventory: nothing found.")
    for warning in report.warnings:
        print(f"WARNING: {warning}")
    for failure in report.failures:
        print(f"ERROR: {failure}")
    print(f"{len(report.failures)} error(s), {len(report.warnings)} warning(s).")
    return 1 if report.failures else 0


if __name__ == "__main__":
    sys.exit(main())
